<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
try {
    $route = request_route();
    if (str_starts_with($route, '/panel')) { require __DIR__ . '/app/admin.php'; }
    else { require __DIR__ . '/app/site.php'; }
} catch (Throwable $exception) {
    log_failure($exception);
    $status = http_response_code();
    if ($status < 400) http_response_code($exception instanceof InvalidArgumentException ? 422 : 500);
    view('error', ['message'=>$exception instanceof InvalidArgumentException || $status===419 ? $exception->getMessage() : 'İşlem tamamlanamadı. Lütfen tekrar deneyin.']);
}
