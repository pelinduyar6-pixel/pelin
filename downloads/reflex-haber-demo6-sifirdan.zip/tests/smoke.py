"""Disposable installation test. Run only against a NEW local test database.
DEMO6_TEST_PASSWORD must contain the password to set on the test admin account.
Usage: python3 tests/smoke.py http://127.0.0.1:8110 mysql
"""
import urllib.request, urllib.parse, urllib.error, http.cookiejar, re, os, sys, json, datetime, pathlib
BASE=sys.argv[1].rstrip('/')
DRIVER=sys.argv[2] if len(sys.argv)>2 else 'sqlite'
PASSWORD=os.environ['DEMO6_TEST_PASSWORD']
jar=http.cookiejar.CookieJar()
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def request(path, data=None, token=None, file=None, opener=client):
    endpoint=(urllib.parse.urlsplit(BASE).scheme+'://'+urllib.parse.urlsplit(BASE).netloc+path) if path.startswith('/') else BASE+'/'+path
    headers={}
    if data is not None:
        data=dict(data)
        if token is not None:data['csrf']=token
        if file:
            boundary='reflex6TestBoundary8b64f7'
            chunks=[]
            for key,value in data.items():chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
            key,filename,content=file
            chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"; filename="{filename}"\r\nContent-Type: image/jpeg\r\n\r\n'.encode()+content+b'\r\n')
            chunks.append(f'--{boundary}--\r\n'.encode());payload=b''.join(chunks)
            headers['Content-Type']='multipart/form-data; boundary='+boundary
        else:payload=urllib.parse.urlencode(data).encode()
    else:payload=None
    try:
        with opener.open(urllib.request.Request(endpoint,data=payload,headers=headers),timeout=30) as r:return r.status,r.read().decode('utf-8','replace'),r.url
    except urllib.error.HTTPError as r:return r.code,r.read().decode('utf-8','replace'),r.url
def route(path,**query):return 'index.php?'+urllib.parse.urlencode({'route':path,**query})
def get(path):
    status,body,_=request(route(path));assert status==200,(path,status);return body
def csrf(body):
    match=re.search(r'name="csrf" value="([a-f0-9]+)"',body);assert match,'CSRF token missing';return match[1]
def check(ok,label):assert ok,label;print('PASS:',label)
status,body,_=request('kurulum.php')
if 'name="admin_password"' in body:
    install={'driver':DRIVER,'site_url':BASE,'admin_name':'Test Yönetici','admin_email':'test-admin@example.invalid','admin_password':PASSWORD,'demo':'1'}
    if DRIVER=='mysql':install.update(db_host='127.0.0.1',db_port='3307',db_name='reflex_demo6_new_test',db_user='reflex_test',db_password=os.environ['DEMO6_TEST_DB_PASSWORD'])
    status,body,_=request('kurulum.php',install,csrf(body));check(status==200 and 'Kurulum tamamlandı' in body,'Browser installer completed')
home=get('/');check('headline-carousel' in home and 'Üst manşet' in home and 'SON DAKİKA' in home,'Seeded reference layout renders')
guest=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
status,body,location=request(route('/panel/haberler'),opener=guest);check('/panel/giris' in urllib.parse.unquote(location),'Admin pages require login')
login=get('/panel/giris');status,body,location=request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':'wrong-password'},csrf(login));check('E-posta veya şifre hatalı' in body,'Incorrect password rejected')
status,body,location=request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(body));check('Dashboard' in body and 'admin-sidebar' in body,'Admin login succeeds')
for p in ['/panel/haberler','/panel/haberler/yeni','/panel/yazarlar','/panel/kategoriler','/panel/reklamlar','/panel/sayfalar','/panel/yorumlar','/panel/ayarlar','/panel/hesabim']:
    get(p)
check(True,'All admin modules render')
form=get('/panel/haberler/yeni');token=csrf(form)
cat=re.search(r'name="category_id">.*?value="(\d+)"',form,re.S).group(1)
author=re.search(r'name="author_id">.*?value="(\d+)"',form,re.S).group(1)
news={'title':'Test Türkçe Haber ŞĞİ','slug':'test-turkce-haber','summary':'Test haber özeti','body':'<p>Güvenli metin</p><script>alert(1)</script><img src="x" onerror="alert(2)"><a href="javascript:alert(3)">link</a>','category_id':cat,'author_id':author,'status':'draft','kind':'article','published_at':'','allow_comments':'1','is_headline':'1','is_top':'1'}
status,body,_=request(route('/panel/haberler/yeni'),news,'invalid');check(status==419,'Invalid CSRF cannot create a news item')
image=pathlib.Path(__file__).parents[1]/'assets/v6/demo/bogaz-5-2-400x225.jpg'
status,body,_=request(route('/panel/haberler/yeni'),news,token,file=('image_file','test.jpg',image.read_bytes()));check(status==200 and 'Kayıt kaydedildi' in body,'Draft creation and image upload succeed')
match=re.search(r'id=(\d+)"[^>]*>Düzenle',body);assert match;newsid=match[1]
status,body,_=request(route('/haber/test-turkce-haber'),opener=guest);check(status==404,'Draft news is hidden from visitors')
edit=request(route('/panel/haberler/duzenle',id=newsid))[1]
check('onerror' not in edit and '&lt;script' not in edit and 'javascript:alert' not in edit,'Unsafe article HTML is removed')
uploaded=re.search(r'class="image-preview" src="([^"]+)"',edit).group(1)
status,_,_=request(uploaded);check(status==200,'Uploaded image is served')
news['status']='published';news['body']='<p>Yayımlanan test içeriği</p>'
status,body,_=request(route('/panel/haberler/duzenle',id=newsid),news,csrf(edit));check(status==200 and 'Kayıt kaydedildi' in body,'Draft can be published')
article=get('/haber/test-turkce-haber');check('Yayımlanan test içeriği' in article,'Published article renders')
search=request(route('/arama',q='Test Türkçe'))[1];check('Test Türkçe Haber ŞĞİ' in search,'Turkish title search works')
status,body,_=request(route('/haber/test-turkce-haber'),{'name':'Ziyaretçi','body':'Deneme yorumu','website':''},csrf(article));check('Yorumunuz alındı' in body,'Visitor comments enter moderation')
check('Deneme yorumu' not in get('/haber/test-turkce-haber'),'Pending comments are hidden')
comments=get('/panel/yorumlar');commentid=re.search(r'id=(\d+)"[^>]*>\s*<input type="hidden" name="csrf"',comments).group(1)
status,body,_=request(route('/panel/yorumlar',id=commentid),{'status':'approved'},csrf(comments));check(status==200 and 'Deneme yorumu' in get('/haber/test-turkce-haber'),'Moderator approval publishes a comment')
news['status']='scheduled';news['published_at']=(datetime.datetime.now()+datetime.timedelta(days=2)).strftime('%Y-%m-%dT%H:%M')
edit=request(route('/panel/haberler/duzenle',id=newsid))[1];request(route('/panel/haberler/duzenle',id=newsid),news,csrf(edit))
check(request(route('/haber/test-turkce-haber'),opener=guest)[0]==404,'Future scheduled article stays hidden')
record_tests=[('kategoriler',{'name':'Test Kategori','slug':'test-kategori','sort_order':'99'}),('yazarlar',{'name':'Test Yazar','email':'test-author@example.invalid','slug':'test-yazar','role':'author','new_password':PASSWORD,'bio':'Test biyografi','active':'1','public_profile':'1'}),('sayfalar',{'title':'Test Sayfa','slug':'test-sayfa','body':'<p>Test sayfa içeriği</p>','active':'1'})]
for module,data in record_tests:
    form=get('/panel/'+module+'/yeni');status,body,_=request(route('/panel/'+module+'/yeni'),data,csrf(form));check(status==200 and 'Kayıt kaydedildi' in body,module+' create')
check('Test sayfa içeriği' in get('/sayfa/test-sayfa'),'Static pages render')
adform=get('/panel/reklamlar/yeni');status,body,_=request(route('/panel/reklamlar/yeni'),{'name':'Test Reklam','placement':'sidebar','target_url':'https://example.com','active':'1'},csrf(adform),file=('image_file','ad.jpg',image.read_bytes()));check(status==200 and 'Kayıt kaydedildi' in body,'Advertisement upload succeeds')
check('REKLAM' in get('/') and 'https://example.com' in get('/'),'Advertisement renders at its chosen position')
check('https://example.com' not in get('/foto-galeri'),'Routes do not display misplaced sidebar ads')
for p in ['/foto-galeri','/video-galeri','/yazarlar','/kategori/gundem','/son-haberler','/sayfa/hakkimizda']:get(p)
check(True,'Visitor routes render')
status,body,_=request('kurulum.php');check('name="admin_password"' not in body,'Installer is locked after completion')
records=get('/panel/haberler');status,body,_=request(route('/panel/haberler/sil',id=newsid),{},csrf(records));check(status==200 and 'Kayıt silindi' in body,'News deletion succeeds')
check(request(route('/haber/test-turkce-haber'),opener=guest)[0]==404,'Deleted news cannot be viewed')
status,body,_=request(route('/panel/cikis'),{},csrf(body));check('Panel Girişi' in body,'Logout succeeds')
print('HTTP smoke test completed:',DRIVER)
