<?php
declare(strict_types=1);
require_once __DIR__ . '/core.php';
date_default_timezone_set('Europe/Istanbul');
if (!is_file(ROOT . '/storage/site.php')) { header('Location: ' . base_path() . '/kurulum.php'); exit; }
$config = require ROOT . '/storage/site.php';
if (!is_dir(ROOT . '/storage/sessions')) @mkdir(ROOT . '/storage/sessions', 0775, true);
session_save_path(ROOT . '/storage/sessions');
session_name('reflex6_session');
session_set_cookie_params(['lifetime'=>0,'path'=>base_path() . '/','secure'=>strtolower((string)parse_url($config['site_url'],PHP_URL_SCHEME))==='https','httponly'=>true,'samesite'=>'Lax']);
session_start();
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');
try {
    Database::connection();
    Database::query("UPDATE rh6_news SET status = 'published' WHERE status = 'scheduled' AND published_at IS NOT NULL AND published_at <= ?", [date('Y-m-d H:i:s')]);
} catch (Throwable $exception) {
    log_failure($exception); http_response_code(503);
    echo '<!doctype html><html lang="tr"><meta charset="utf-8"><title>Reflex Haber</title><body><h1>Siteye şu anda ulaşılamıyor</h1><p>Veritabanı bağlantısı doğrulanamadı. Hosting veritabanı ayarlarını kontrol edin.</p></body></html>'; exit;
}
