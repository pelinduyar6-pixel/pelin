<?php
declare(strict_types=1);
function create_schema(PDO $pdo, string $driver): void {
    $id = $driver === 'sqlite' ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT UNSIGNED AUTO_INCREMENT PRIMARY KEY';
    $tail = $driver === 'sqlite' ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $tables = [
        'users' => "id $id, name VARCHAR(150) NOT NULL, slug VARCHAR(190) NOT NULL UNIQUE, email VARCHAR(190) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, role VARCHAR(20) NOT NULL DEFAULT 'author', active INTEGER NOT NULL DEFAULT 1, public_profile INTEGER NOT NULL DEFAULT 0, bio TEXT, image VARCHAR(1000), is_demo INTEGER NOT NULL DEFAULT 0",
        'categories' => "id $id, name VARCHAR(100) NOT NULL, slug VARCHAR(190) NOT NULL UNIQUE, sort_order INTEGER NOT NULL DEFAULT 0",
        'news' => "id $id, title VARCHAR(255) NOT NULL, slug VARCHAR(190) NOT NULL UNIQUE, summary TEXT, body TEXT, image VARCHAR(1000), category_id INTEGER, author_id INTEGER, status VARCHAR(20) NOT NULL DEFAULT 'draft', kind VARCHAR(20) NOT NULL DEFAULT 'article', video_url VARCHAR(1000), gallery TEXT, published_at VARCHAR(19), created_at VARCHAR(19) NOT NULL, updated_at VARCHAR(19) NOT NULL, is_breaking INTEGER NOT NULL DEFAULT 0, is_headline INTEGER NOT NULL DEFAULT 0, is_top INTEGER NOT NULL DEFAULT 0, is_featured INTEGER NOT NULL DEFAULT 0, is_box INTEGER NOT NULL DEFAULT 0, allow_comments INTEGER NOT NULL DEFAULT 1, seo_title VARCHAR(255), seo_description TEXT, views INTEGER NOT NULL DEFAULT 0, is_demo INTEGER NOT NULL DEFAULT 0",
        'ads' => "id $id, name VARCHAR(150) NOT NULL, image VARCHAR(1000), target_url VARCHAR(1000), placement VARCHAR(30) NOT NULL, active INTEGER NOT NULL DEFAULT 1",
        'pages' => "id $id, title VARCHAR(150) NOT NULL, slug VARCHAR(190) NOT NULL UNIQUE, body TEXT, active INTEGER NOT NULL DEFAULT 1",
        'settings' => "id $id, name VARCHAR(100) NOT NULL UNIQUE, value TEXT",
        'comments' => "id $id, news_id INTEGER NOT NULL, name VARCHAR(100) NOT NULL, body TEXT NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', created_at VARCHAR(19) NOT NULL"
    ];
    foreach ($tables as $name=>$columns) $pdo->exec('CREATE TABLE IF NOT EXISTS rh6_' . $name . ' (' . $columns . ')' . $tail);
}
function seed_site(string $adminName, string $email, string $password, bool $demo): void {
    Database::save('users', ['name'=>$adminName,'slug'=>'yonetici','email'=>$email,'password'=>password_hash($password,PASSWORD_DEFAULT),'role'=>'admin','active'=>1,'public_profile'=>0,'bio'=>'','image'=>'','is_demo'=>0]);
    $settings = ['site_name'=>'REFLEX HABER','tagline'=>'Güncel, hızlı, güvenilir','description'=>'Türkiye ve dünyadan haberler, ekonomi, spor ve yaşam.','weather_city'=>'BURSA','weather_value'=>'12.9°','weather_enabled'=>$demo?'1':'0','market_enabled'=>'0','market_usd'=>'','market_eur'=>'','market_gold'=>'','facebook'=>'','instagram'=>'','youtube'=>'','contact_email'=>$email,'footer_text'=>'Reflex Haber · Tüm hakları saklıdır.','demo_notice'=>$demo?'1':'0'];
    foreach ($settings as $name=>$value) Database::save('settings',compact('name','value'));
    $cats=[];
    foreach (['Gündem','Ekonomi','Politika','Dünya','Spor','Magazin','Sağlık','Teknoloji','Yaşam','Kültür Sanat'] as $i=>$name) $cats[$name]=Database::save('categories',['name'=>$name,'slug'=>slugify($name),'sort_order'=>$i]);
    foreach (['Hakkımızda','İletişim','Gizlilik Politikası'] as $title) Database::save('pages',['title'=>$title,'slug'=>slugify($title),'body'=>'<p>Bu sayfanın içeriğini yönetim panelindeki Sayfalar bölümünden düzenleyebilirsiniz.</p>','active'=>1]);
    if (!$demo) return;
    $authors=[];
    foreach (['Deniz Aksoy','Ece Yılmaz','Mert Kaya','Selin Aydın','Can Demir'] as $i=>$name) $authors[]=Database::save('users',['name'=>$name,'slug'=>slugify($name),'email'=>'demo'.($i+1).'@example.invalid','password'=>password_hash(bin2hex(random_bytes(32)),PASSWORD_DEFAULT),'role'=>'author','active'=>1,'public_profile'=>1,'bio'=>'Gündeme ve hayata dair değerlendirmeler. Bu profil örnek içeriktir.','image'=>'y'.(5-$i).'.jpg','is_demo'=>1]);
    $items=[
        ['Meclis gündeminde bu hafta neler var?','Politika','tbmm-5-2-400x225.jpg','top'],
        ['Şehir içi ulaşım için yeni düzenlemeler','Gündem','yol-5-2-400x225.jpg','top'],
        ['Ekonomide haftanın öne çıkan başlıkları','Ekonomi','enf-5-2-400x225.jpg','top'],
        ['Futbolda gözler hafta sonu karşılaşmalarında','Spor','futbol-5-2-400x225.jpg','top'],
        ['İstanbul Boğazı’nda yeni bir gün','Gündem','bogaz-5-2.jpg','headline'],
        ['Siyasette gündem ve değerlendirmeler','Politika','mhp-5-2.jpg','headline'],
        ['Yağışlı hava için hazırlıklar sürüyor','Gündem','yagmur1-5-2.jpg','headline'],
        ['Türkiye’nin yakın tarihine bir bakış','Politika','sdemirel-5-2.jpg','headline'],
        ['Tribünlerde büyük heyecan','Spor','tribun-5-2.jpg','headline'],
        ['Teknolojide yeni gelişmeler','Teknoloji','google-5-2.jpg','headline'],
        ['Okyanusların geleceği konuşuluyor','Dünya','okyanus-5-2.jpg','headline'],
        ['Dijital güvenlik için temel öneriler','Teknoloji','hackkk-5-2.jpg','headline'],
        ['İhracatta yeni pazar arayışları','Ekonomi','ihr1-5-2-400x225.jpg','box'],
        ['Hava ulaşımında yoğun günler','Gündem','hava-5-2-400x225.jpg','box'],
        ['Boğaz kıyısında yaşam','Yaşam','bogaz-5-2-400x225.jpg','box'],
        ['Trafikte güvenli sürüşün önemi','Gündem','drift-5-2-400x225.jpg','box'],
        ['Kentlerde yağışa karşı alınan önlemler','Gündem','sel-5-2-400x225.jpg','featured'],
        ['Bilim dünyasından uzay araştırmaları','Teknoloji','nasa-5-2.jpg','featured'],
        ['Tarımda yeni sezon hazırlıkları','Ekonomi','tarla-5-2.jpg','featured'],
        ['Piyasalarda haftalık değerlendirme','Ekonomi','dolar-1-5-2-400x225.jpg',''],
        ['Avrupa’dan günlük gelişmeler','Dünya','isvicre-5-2-400x225.jpg',''],
        ['Basketbolda sezon heyecanı','Spor','basket-5-2-400x225.jpg',''],
        ['Sağlıklı yaşam için hareket','Sağlık','kosu-5-2-400x225.jpg',''],
        ['Sanat dünyasında yeni etkinlikler','Kültür Sanat','theatre-5-2.jpg',''],
        ['Sosyal medyada dijital alışkanlıklar','Teknoloji','sosyal-5-2.jpg',''],
        ['Kültür ve yaşamdan kareler','Yaşam','ev-5-2-400x225.jpg','gallery'],
        ['Spor gündemine bakış','Spor','futbol-5-2-400x225.jpg','video']
    ];
    foreach ($items as $i=>[$title,$category,$image,$position]) {
        $date=date('Y-m-d H:i:s',time()-$i*600);
        Database::save('news',['title'=>$title,'slug'=>slugify($title),'summary'=>'Günün öne çıkan gelişmelerine ve gündemdeki başlıklara yakından bakıyoruz.','body'=>'<p><strong>Örnek haber içeriği.</strong> Bu yazı, site tasarımını göstermek için hazırlanmıştır; gerçek bir haber yayını değildir.</p><p>Kendi haberlerinizi yönetim panelindeki Haber Yönetimi bölümünden ekleyebilirsiniz. Başlığı, görseli, kategoriyi ve yayın konumlarını düzenleyerek ana sayfayı oluşturabilirsiniz.</p>','image'=>$image,'category_id'=>$cats[$category],'author_id'=>$authors[$i%5],'status'=>'published','kind'=>in_array($position,['gallery','video'])?$position:'article','video_url'=>'','gallery'=>$position==='gallery'?json_encode(['bogaz-5-2.jpg','tarla-5-2.jpg']):'[]','published_at'=>$date,'created_at'=>$date,'updated_at'=>$date,'is_breaking'=>$position==='headline'?1:0,'is_headline'=>($position==='headline'||$i>=18)?1:0,'is_top'=>$position==='top'?1:0,'is_featured'=>($position==='featured'||($i>=19&&$i<=24))?1:0,'is_box'=>$position==='box'?1:0,'allow_comments'=>1,'seo_title'=>'','seo_description'=>'','is_demo'=>1]);
    }
}
