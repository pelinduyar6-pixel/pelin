</main><footer class="admin-bottom">Reflex Haber · Demo 6 · Yönetim</footer></div><script><?=inline_asset('admin.js')?></script></body></html>
