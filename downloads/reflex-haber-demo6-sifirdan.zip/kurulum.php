<?php
declare(strict_types=1);
require __DIR__.'/app/core.php';
require __DIR__.'/app/install.php';
date_default_timezone_set('Europe/Istanbul');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
if (is_file(ROOT.'/storage/site.php')) { header('Location: '.url('/panel/giris'),true,303); exit; }
@mkdir(ROOT.'/storage/sessions',0750,true);
session_save_path(ROOT.'/storage/sessions');
session_name('reflex6_install');
session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Lax','cookie_path'=>base_path().'/','cookie_secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off']);
$checks=['PHP 8.1 veya üzeri'=>PHP_VERSION_ID>=80100,'PDO veritabanı sürücüsü'=>class_exists('PDO')&&(extension_loaded('pdo_mysql')||extension_loaded('pdo_sqlite')),'DOM, Fileinfo ve Mbstring'=>extension_loaded('dom')&&extension_loaded('fileinfo')&&extension_loaded('mbstring'),'storage klasörü yazılabilir'=>is_writable(ROOT.'/storage'),'uploads klasörü yazılabilir'=>is_writable(ROOT.'/uploads'),'Tasarım dosyaları mevcut'=>is_file(ROOT.'/assets/v6/site.css')&&is_file(ROOT.'/assets/v6/admin.css')];
$error=''; $done=false;
if (is_post()) {
    $lock=null;
    try {
        verify_csrf();
        if (in_array(false,$checks,true)) throw new InvalidArgumentException('Önce aşağıdaki sunucu kontrollerini tamamlayın.');
        $lock=fopen(ROOT.'/storage/install.lock','c');
        if (!$lock||!flock($lock,LOCK_EX|LOCK_NB)) throw new InvalidArgumentException('Kurulum devam ediyor. Biraz sonra tekrar deneyin.');
        if (is_file(ROOT.'/storage/site.php')) throw new InvalidArgumentException('Bu site zaten kurulmuş.');
        $driver=text_input('driver',10,true);
        if (!in_array($driver,['mysql','sqlite'],true)) throw new InvalidArgumentException('Geçerli veritabanı türünü seçin.');
        $db=$driver==='sqlite'?['driver'=>'sqlite','path'=>ROOT.'/storage/site.sqlite']:['driver'=>'mysql','host'=>text_input('db_host',150,true),'port'=>integer_input('db_port',3306),'database'=>text_input('db_name',100,true),'username'=>text_input('db_user',100,true),'password'=>(string)($_POST['db_password']??'')];
        if ($driver==='mysql' && (!preg_match('/^[a-zA-Z0-9_.:-]+$/',$db['host']) || !preg_match('/^[a-zA-Z0-9_\-]+$/',$db['database']) || $db['port']<1 || $db['port']>65535)) throw new InvalidArgumentException('Veritabanı adresi, portu veya adı geçersiz.');
        $siteUrl=rtrim(url_input('site_url'),'/');
        if (!$siteUrl||parse_url($siteUrl,PHP_URL_QUERY)||parse_url($siteUrl,PHP_URL_FRAGMENT)) throw new InvalidArgumentException('Site adresini klasör yolu dahil, sorgu parametresi olmadan girin.');
        $name=text_input('admin_name',150,true); $email=text_input('admin_email',190,true);
        $password=password_input('admin_password',true);
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Geçerli yönetici e-postası girin.');
        if (strlen($password)<12 || strlen($password)>72) throw new InvalidArgumentException('Yönetici şifresi 12–72 bayt uzunluğunda olmalı.');
        $pdo=Database::connect($db); Database::use($pdo); create_schema($pdo,$driver);
        if ((int)Database::scalar('SELECT COUNT(*) FROM rh6_users')>0) throw new InvalidArgumentException('Bu veritabanında Reflex 6 kurulumu var. Yeni ve boş bir veritabanı kullanın.');
        $pdo->beginTransaction();
        try {
            seed_site($name,$email,$password,isset($_POST['demo']));
            $config='<?php return '.var_export(['site_url'=>$siteUrl,'db'=>$db],true).';'.PHP_EOL;
            $temp=ROOT.'/storage/.config-'.bin2hex(random_bytes(8)).'.php';
            if (file_put_contents($temp,$config,LOCK_EX)===false) throw new RuntimeException('Configuration write failed');
            chmod($temp,0600);
            $pdo->commit();
            if (!rename($temp,ROOT.'/storage/site.php')) throw new RuntimeException('Configuration save failed');
        } catch (Throwable $exception) { if ($pdo->inTransaction()) $pdo->rollBack(); if (isset($temp)) @unlink($temp); throw $exception; }
        $done=true; session_regenerate_id(true);
    } catch (Throwable $exception) {
        log_failure($exception);
        $error=$exception instanceof InvalidArgumentException||http_response_code()===419?$exception->getMessage():'Veritabanına bağlanılamadı veya kurulum tamamlanamadı. Sunucudaki veritabanı bilgilerini ve klasör izinlerini kontrol edin.';
    } finally { if (is_resource($lock)) { flock($lock,LOCK_UN); fclose($lock); } }
}
$defaultUrl=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost').base_path();
?><!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reflex Haber Kurulum</title><style> *{box-sizing:border-box}body{margin:0;background:#eef1f5;font:16px/1.5 system-ui;color:#172638}main{max-width:760px;margin:40px auto;background:white;border-radius:16px;padding:32px}h1{margin:0;color:#ed1735}h2{font-size:20px}.checks{padding:16px;background:#f5f7fa;border-radius:10px}.ok{color:#13764b}.bad,.error{color:#b31229}.error{padding:14px;background:#fff0f2}label{display:block;font-weight:600;margin:16px 0 6px}input,select{width:100%;padding:12px;border:1px solid #c8d0dc;border-radius:7px;font:inherit}input[type=checkbox]{width:auto}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}button,.button{display:inline-block;margin-top:24px;background:#ed1735;color:white;padding:13px 22px;border:0;border-radius:7px;font:inherit;text-decoration:none;cursor:pointer}small{color:#5c6878}a{color:#bd1730}@media(max-width:600px){main{margin:12px;padding:20px}.grid{grid-template-columns:1fr}}</style><main><h1>REFLEX HABER</h1><h2>Demo 6 · Yeni kurulum</h2>
<?php if ($done): ?><p>Kurulum tamamlandı. Yönetim paneline belirlediğiniz e-posta ve şifreyle girebilirsiniz.</p><a class="button" href="<?=e(url('/panel/giris'))?>">Panele giriş</a> <a href="<?=e(url('/'))?>">Siteyi aç</a>
<?php else: ?><p>Dosyaları yeni bir klasöre yükleyin. MySQL veritabanını hosting panelinden oluşturup kullanıcıya yetki verin. Kurulum, <strong>rh6_</strong> tablolarını oluşturur.</p><div class="checks"><?php foreach($checks as $label=>$ok): ?><div class="<?=$ok?'ok':'bad'?>"><?=$ok?'✓':'✕'?> <?=e($label)?></div><?php endforeach ?></div><?php if($error):?><p class="error"><?=e($error)?></p><?php endif ?>
<form method="post" autocomplete="off"><?=csrf_field()?><label>Site adresi (varsa alt klasör dahil)</label><input name="site_url" type="url" value="<?=e($_POST['site_url']??$defaultUrl)?>" required>
<label>Veritabanı türü</label><select name="driver" id="driver"><option value="mysql">MySQL / MariaDB (hosting)</option><?php if(extension_loaded('pdo_sqlite')):?><option value="sqlite" <?=($_POST['driver']??'')==='sqlite'?'selected':''?>>SQLite (yerel deneme)</option><?php endif ?></select>
<div id="mysql-fields"><div class="grid"><div><label>Veritabanı sunucusu</label><input name="db_host" value="<?=e($_POST['db_host']??'localhost')?>"></div><div><label>Port</label><input name="db_port" type="number" value="<?=e($_POST['db_port']??3306)?>"></div></div><div class="grid"><div><label>Veritabanı adı</label><input name="db_name" value="<?=e($_POST['db_name']??'')?>"></div><div><label>Veritabanı kullanıcı adı</label><input name="db_user" value="<?=e($_POST['db_user']??'')?>"></div></div><label>Veritabanı şifresi</label><input name="db_password" type="password" autocomplete="new-password"></div>
<h2>Yönetici hesabı</h2><label>Adınız</label><input name="admin_name" required maxlength="150" value="<?=e($_POST['admin_name']??'')?>"><label>E-posta</label><input type="email" name="admin_email" required value="<?=e($_POST['admin_email']??'')?>"><label>Şifre</label><input type="password" name="admin_password" minlength="12" maxlength="72" required autocomplete="new-password"><small>En az 12 karakter. Bu şifreyi panel girişinde kullanacaksınız.</small><label><input type="checkbox" name="demo" <?=!is_post()||isset($_POST['demo'])?'checked':''?>> Tasarımı göstermek için örnek haberleri ve görselleri ekle</label><small>Örnek içerikler panelden tek işlemle kaldırılabilir.</small><br><button <?=in_array(false,$checks,true)?'disabled':''?>>Kurulumu tamamla</button></form><script>const d=document.getElementById('driver');function toggle(){document.getElementById('mysql-fields').hidden=d.value==='sqlite'}d.addEventListener('change',toggle);toggle();</script><?php endif ?></main></html>
