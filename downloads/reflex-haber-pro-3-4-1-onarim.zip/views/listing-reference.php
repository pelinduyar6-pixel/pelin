<?php
$edition=active_theme();$profile=theme_catalog()[$edition]['category_profile'];
$categoryPopular=news_rows('AND n.category_id=? AND n.kind=?',[$category['id'],'article'],5,0,'popular');
$heroIds=$categoryHero?array_column($categoryHero,'id'):[];
$remaining=array_values(array_filter($items,fn($n)=>!in_array($n['id'],$heroIds,true)));
show_ad('listing_top');
?>
<nav class="breadcrumb"><a href="<?=e(url('/'))?>">Ana Sayfa</a> / <?=e($heading)?></nav>
<section class="reference-archive ref-<?=e($profile)?>" data-category-profile="<?=e($profile)?>" data-category-id="<?=(int)$category['id']?>">
    <div class="reference-archive-heading"><h1><?=e($heading)?></h1><span><?=number_format($total)?> haber</span></div>
    <div class="reference-archive-columns">
        <div class="reference-archive-main">
            <?php if($categoryHero)view('hero',['heroItems'=>$categoryHero,'heroClass'=>'category-page-hero']);?>
            <?php if($remaining):?><div class="listing-grid"><?php foreach($remaining as $item):view('card',['item'=>$item]);endforeach ?></div><?php endif ?>
            <?php if(!$items):?><p class="empty">Bu kategoride henüz yayımlanmış haber bulunmuyor.</p><?php endif ?>
            <?php pagination($pageNumber,$pages,$route);?>
        </div>
        <?php if($categoryPopular||$sidebarLatest):?>
        <aside class="right-column reference-archive-aside">
            <?php show_ad('sidebar');if($categoryPopular):?><section class="side-block"><h2><?=e($category['name'])?> · Çok okunanlar</h2><?php foreach($categoryPopular as $item):?><a class="compact-story" href="<?=e(news_link($item))?>"><img src="<?=e(media($item['image']))?>" alt="" loading="lazy"><h3><?=e($item['title'])?></h3></a><?php endforeach ?></section><?php endif;show_ad('sidebar_mid');?>
            <?php if($sidebarLatest):?><section class="side-block"><h2>Son haberler</h2><?php foreach($sidebarLatest as $item):?><a class="compact-story" href="<?=e(news_link($item))?>"><img src="<?=e(media($item['image']))?>" alt="" loading="lazy"><h3><?=e($item['title'])?></h3></a><?php endforeach ?></section><?php endif;show_ad('sidebar_bottom');?>
        </aside>
        <?php endif ?>
    </div>
</section>
