<?php
$edition=active_theme();$profile=theme_catalog()[$edition]['category_profile'];$blocks=[];
foreach(homepage_categories($categories) as $category){
    if(!$category['home_enabled'])continue;
    $stories=news_rows('AND n.category_id=? AND n.kind=?',[$category['id'],'article'],6);
    if($stories)$blocks[]=['category'=>$category,'stories'=>$stories];
}
$slugs=array_column(array_column($blocks,'category'),'slug');
$paired=$edition==='8'&&in_array('teknoloji',$slugs,true)&&in_array('saglik',$slugs,true);
if(!$blocks)return;
?>
<div class="reference-category-collection" data-reference-edition="<?=e($edition)?>">
<?php foreach($blocks as $block):$category=$block['category'];$slug=$category['slug'];$stories=$block['stories'];
$layout=$category['home_layout']==='auto'?$profile:match($category['home_layout']){'editorial'=>'flow','showcase'=>'esen','mosaic'=>'wind',default=>'regional'};
$mode=match($layout){'regional'=>'cards-four','flow'=>$slug==='spor'?'cards-three':'lead-four','wind'=>'feature-grid',default=>match($slug){'gundem','turkiye-gundemi','ekonomi'=>'cards-three','teknoloji','saglik'=>'story-list',default=>'double-lead'}};
$limit=match($mode){'cards-four'=>4,'lead-four'=>5,default=>6};$stories=array_slice($stories,0,$limit);
$tone=match($slug){'spor'=>'#20b36a','magazin'=>'#9425dc','saglik'=>'#05a3c7','teknoloji'=>'#e75421','ekonomi'=>'#1260db','politika'=>'#e40024',default=>'#e51b36'};
?>
<section class="portal-section lively-category reference-category category-<?=e($slug)?> ref-<?=e($layout)?> <?=$paired&&in_array($slug,['teknoloji','saglik'],true)?'category-half':''?>" style="--section-color:<?=$tone?>" data-section="category" data-category="<?=e($slug)?>" data-layout="<?=e($layout)?>" data-category-id="<?=(int)$category['id']?>">
    <div class="portal-heading"><h2><?=e($category['name'])?> haberleri</h2><a href="<?=e(url('/kategori/'.$slug))?>">Tümü »</a></div>
    <div class="reference-category-grid mode-<?=e($mode)?> count-<?=count($stories)?>">
        <?php foreach($stories as $i=>$item):$lead=($mode==='lead-four'||$mode==='feature-grid')?$i===0:($mode==='double-lead'&&$i<2);?>
        <a class="reference-category-story <?=$lead?'is-lead':''?>" href="<?=e(news_link($item))?>">
            <div class="reference-category-image"><img src="<?=e(media($item['image']))?>" alt="" loading="lazy" width="640" height="360"><span><?=e($category['name'])?></span></div>
            <div class="reference-category-text"><h3><?=e($item['title'])?></h3><?php if($lead&&$mode==='lead-four'&&!empty($item['summary'])):?><p><?=e(mb_substr($item['summary'],0,180))?></p><?php endif ?></div>
        </a>
        <?php endforeach ?>
    </div>
    <?php if($slug==='spor'&&setting('sports_enabled')==='1'):?><div class="reference-category-league"><?php view('league-table');?></div><?php endif ?>
</section>
<?php if($slug==='ekonomi')show_ad('home_section_2');endforeach ?>
</div>
