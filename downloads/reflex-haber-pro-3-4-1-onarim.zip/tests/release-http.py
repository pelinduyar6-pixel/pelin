"""Detect a partial update and enforce admin-only diagnostics; disposable localhost."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
assert urllib.parse.urlsplit(BASE).hostname in ['127.0.0.1','localhost']
root=Path(sys.argv[3]).resolve();assert str(root).startswith('/workspace/reflex-')
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
report=get('/panel/sistem-kontrolu');check('Güncelleme dosyaları eksiksiz' in report and 'Paket sürümü: 3.4.1-r1' in report,'Complete uploaded package is verified by admin diagnostics')
stylesheet=root/'assets/v6/edition-admin.css';original=stylesheet.read_bytes()
try:
    stylesheet.write_bytes(b'/* Stale uploaded stylesheet fixture */')
    report=get('/panel/sistem-kontrolu');check('Güncelleme paketinden farklı' in report and 'assets/v6/edition-admin.css' in report,'Mixed-version CSS is reported on the panel')
    stylesheet.unlink();report=get('/panel/sistem-kontrolu');check('Eksik veya okunamıyor' in report and 'assets/v6/edition-admin.css' in report,'Missing uploaded pagination CSS is reported')
finally:stylesheet.write_bytes(original)
check('Güncelleme dosyaları eksiksiz' in get('/panel/sistem-kontrolu'),'Replacing the correct file clears the diagnostic')
reader=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
login=request(route('/panel/giris'),opener=reader)[1];request(route('/panel/giris'),{'email':'test-editor@example.invalid','password':PASSWORD},csrf(login),opener=reader)
check(request(route('/panel/sistem-kontrolu'),opener=reader)[0]==403,'Editor cannot open administrator system diagnostics')
check('name="reflex-version" content="3.4.1-r1"' in get('/'),'Public HTML identifies the loaded release without exposing settings')
print('Release HTTP checks completed:',DRIVER)
