const {chromium}=require('playwright'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const base=process.argv[2],root=process.argv[3];if(!/^http:\/\/(127\.0\.0\.1|localhost):/.test(base)||!['/workspace/reflex-v341r1-test','/workspace/reflex-v341r1-mysql'].includes(root))throw Error('Disposable localhost fixture required');
 const probe=action=>JSON.parse(cp.execFileSync('/workspace/reflex-tools/php',[root+'/tests/reference-categories-probe.php',root,action],{encoding:'utf8'}));
 const before=probe('state');probe('seed');
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),admin=await browser.newPage(),reader=await browser.newPage();
 const route=p=>base+'/index.php?'+new URLSearchParams({route:p}),errors=[];reader.on('pageerror',e=>errors.push(e.message));
 const check=(ok,label)=>{if(!ok)throw Error(label);console.log('PASS',label)};
 let originalTheme,originalCategories;
 try{
  await admin.goto(route('/panel/giris'));await admin.locator('[name=email]').fill('test-admin@example.invalid');await admin.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD);await admin.getByRole('button',{name:'Giriş yap'}).click();await admin.waitForURL(/route=%2Fpanel$/);
  await admin.goto(route('/panel/tema'));originalTheme=await admin.locator('form:has([name=theme_style])').evaluate(f=>Object.fromEntries(new FormData(f)));
  await admin.goto(route('/panel/ogeler'));originalCategories=await admin.locator('form:has([name=home_show_headline])').evaluate(f=>Object.fromEntries(new FormData(f)));
  const out='/workspace/outputs/reflex-v341r1';fs.mkdirSync(out,{recursive:true});
  for(const [theme,profile] of [['5','regional'],['6','flow'],['7','wind'],['8','esen']]){
   await admin.request.post(route('/panel/tema'),{form:{...originalTheme,theme_style:theme,slider_autoplay:''}});
   await reader.setViewportSize({width:1440,height:1000});await reader.goto(route('/'));await reader.evaluate(()=>document.fonts.ready);
   check(await reader.locator('.reference-category[data-layout="'+profile+'"]').count()>0,'Theme '+theme+' uses its own automatic category profile '+profile);
   const category=reader.locator('.reference-category').first();check(await category.locator('.reference-category-story').count()>=4,'Theme '+theme+' renders the complete populated category block');
   const href=await category.locator('.portal-heading a').getAttribute('href');
   await category.screenshot({path:out+'/tema-'+theme+'-kategori.png'});
   for(const width of [1440,768,390,320]){
    await reader.setViewportSize({width,height:1000});await reader.goto(route('/'));check(await reader.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Home category blocks fit '+theme+'/'+width);
    check(await reader.locator('.reference-category .reference-category-story').evaluateAll(items=>items.every(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.left>=-1&&r.right<=innerWidth+1})),'Category cards have usable bounds '+theme+'/'+width);
    await reader.goto(new URL(href,base).href);check(await reader.locator('.reference-archive').getAttribute('data-category-profile')===profile,'Category route uses '+profile+' '+width);
    check(await reader.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Category archive fits '+theme+'/'+width);
    const visible=await reader.locator('.reference-archive-main a.hero-slide:not([hidden]),.reference-archive-main .news-card>a').evaluateAll(items=>items.map(e=>e.href));check(visible.length===new Set(visible).size,'Visible hero and list do not duplicate a story '+theme+'/'+width);
    const article=await reader.locator('.hero-slide').first().getAttribute('href');await reader.goto(new URL(article,base).href);check(await reader.locator('.article h1').count()===1&&await reader.locator('.article-sidebar .compact-story').count()>0,'Article content and sidebar remain functional '+theme+'/'+width);
    check(await reader.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Article fits '+theme+'/'+width);
   }
   const hidden={...originalCategories};Object.keys(hidden).filter(k=>k.startsWith('home_category[')&&k.endsWith('[enabled]')).slice(0,1).forEach(k=>delete hidden[k]);
   await admin.request.post(route('/panel/ogeler'),{form:hidden});await reader.goto(route('/'));check(await reader.locator('.reference-category').count()===(await reader.locator('.reference-category-collection').count()?Object.keys(hidden).filter(k=>k.startsWith('home_category[')&&k.endsWith('[enabled]')).length:0),'Theme '+theme+' respects category visibility from the panel');
   await admin.request.post(route('/panel/ogeler'),{form:originalCategories});
  }
  check(JSON.stringify(probe('state'))===JSON.stringify(before),'Changing themes preserves category IDs and existing users/passwords');
  check(errors.length===0,'No category or article browser errors');
 }finally{
  if(originalTheme)await admin.request.post(route('/panel/tema'),{form:originalTheme});if(originalCategories)await admin.request.post(route('/panel/ogeler'),{form:originalCategories});probe('clean');await browser.close();
 }
})().catch(e=>{console.error(e);process.exit(1)});
