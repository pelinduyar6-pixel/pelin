<?php
// Fault injection is allowed only on explicitly named disposable local fixtures.
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit(1);
$root=realpath($argv[1]??'');
if(!$root||!preg_match('~^/workspace/reflex-v341-(?:panel-test|fresh-mysql)$~D',$root))exit(1);
$config=require $root.'/storage/site.php';
if(!in_array(parse_url($config['site_url'],PHP_URL_HOST),['127.0.0.1','localhost'],true))exit(1);
if(($config['db']['driver']??'mysql')==='mysql'&&($config['db']['host']!=='127.0.0.1'||$config['db']['database']!=='reflex_v341_cpanel'))exit(1);
require $root.'/app/core.php';require $root.'/app/pro.php';
$input=json_decode(stream_get_contents(STDIN),true,512,JSON_THROW_ON_ERROR);
$pdo=Database::connection();$driver=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME);$result=[];
if($input['action']==='state'){
    foreach(['news','users','categories','settings','ads','news_sources'] as $table)$result[$table]=Database::rows('SELECT * FROM rh6_'.$table.' ORDER BY id');
    $result['schema']=PRO_VERSION;
}elseif($input['action']==='fault'){
    $table=$input['table'];if(!in_array($table,['live_visitors','live_views','daily_stats','contacts','news'],true))exit(1);
    $indices=$driver==='sqlite'?Database::rows("SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name=? AND sql IS NOT NULL",['rh6_'.$table]):[];
    if($driver==='sqlite')foreach(Database::rows("SELECT name FROM sqlite_master WHERE type='index' AND tbl_name=? AND sql IS NOT NULL",['rh6_'.$table]) as $index)$pdo->exec('DROP INDEX '.$index['name']);
    $pdo->exec('ALTER TABLE rh6_'.$table.' RENAME TO rh6_panel_probe_saved');$result=$indices;
}elseif($input['action']==='restore'){
    $table=$input['table'];if(!in_array($table,['live_visitors','live_views','daily_stats','contacts','news'],true))exit(1);
    $pdo->exec('DROP TABLE IF EXISTS rh6_'.$table);$pdo->exec('ALTER TABLE rh6_panel_probe_saved RENAME TO rh6_'.$table);
    foreach($input['indices'] as $index)$pdo->exec($index['sql']);
}elseif($input['action']==='column-fault'){
    $pdo->exec('ALTER TABLE rh6_news RENAME COLUMN focus_keyword TO panel_probe_saved_keyword');
}elseif($input['action']==='column-restore'){
    $pdo->exec('ALTER TABLE rh6_news DROP COLUMN focus_keyword');$pdo->exec('ALTER TABLE rh6_news RENAME COLUMN panel_probe_saved_keyword TO focus_keyword');
}elseif($input['action']==='missing'){
    $result=pro_schema_missing();
}elseif($input['action']==='log'){
    $result=['reference'=>log_failure(new RuntimeException('password=DO_NOT_LOG_PASSWORD sk-proj-DO_NOT_LOG_API_KEY visitor@example.invalid https://private.invalid/?token=DO_NOT_LOG_TOKEN'))];
}
echo json_encode($result,JSON_THROW_ON_ERROR|JSON_INVALID_UTF8_SUBSTITUTE);
