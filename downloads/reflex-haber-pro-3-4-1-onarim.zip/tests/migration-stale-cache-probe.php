<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit(1);
$root=realpath($argv[1]??'');if($root!=='/workspace/reflex-v341r1-opcache')exit(1);
$config=require $root.'/storage/site.php';if($config['site_url']!=='http://127.0.0.1:8195'||$config['db']['driver']!=='sqlite'||realpath(dirname($config['db']['path']))!==$root.'/storage')exit(1);
require $root.'/app/core.php';require $root.'/app/pro.php';
$input=json_decode(stream_get_contents(STDIN),true,512,JSON_THROW_ON_ERROR);
if($input['action']==='seed'){
 $id=bin2hex(random_bytes(16));$dir=migration_dir($id);mkdir($dir,0700);
 $sql="CREATE TABLE old_news (`id` INT,`title` TEXT,`body` TEXT,`image` TEXT); INSERT INTO old_news VALUES (1,'Eski aktarım haberi','<p>Korunacak içerik</p>','uploads/cover.jpg');";
 file_put_contents($dir.'/source.sql',$sql);$tables=migration_parse_sql($dir.'/source.sql',$dir);
 $mapping=migration_validate_mapping(['tables'=>$tables],['news_table'=>'old_news','id'=>'id','title'=>'title','body'=>'body','image'=>'image']);
 $photoDir=$root.'/uploads/migration/'.$id;mkdir($photoDir,0755,true);copy($root.'/assets/v6/demo/bogaz-5-2-400x225.jpg',$photoDir.'/cover.jpg');
 $job=['id'=>$id,'owner'=>1,'created_at'=>date('Y-m-d H:i:s'),'filename'=>'retained.sql','hash'=>hash('sha256',$sql),'tables'=>$tables,'stage'=>'preview','mapping'=>$mapping,'images'=>['uploads/cover.jpg'=>'uploads/migration/'.$id.'/cover.jpg'],'targets'=>[],'cursor'=>0,'imported'=>0,'duplicates'=>0,'skipped'=>0,'missing_images'=>0];
 migration_store($job);file_put_contents($dir.'/'.$tables['old_news']['file'],"{\"body\":\"truncated legacy\n{\"id\":\"1\"}\n");echo json_encode(['job'=>$id]);
}elseif($input['action']==='state'){
 $job=migration_load($input['job'],1);$result=array_intersect_key($job,array_flip(['hash','images','mapping','targets','cursor','imported','duplicates','skipped','missing_images']));
 $result['source']=hash_file('sha256',migration_dir($job['id']).'/source.sql');$result['photo']=hash_file('sha256',$root.'/'.reset($job['images']));echo json_encode($result,JSON_THROW_ON_ERROR);
}else exit(1);
