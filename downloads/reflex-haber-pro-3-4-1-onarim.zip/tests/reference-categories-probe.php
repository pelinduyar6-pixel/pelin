<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit(1);
$root=realpath($argv[1]??'');
if(!in_array($root,['/workspace/reflex-v341r1-test','/workspace/reflex-v341r1-mysql'],true))exit(1);
$config=require $root.'/storage/site.php';
if(parse_url($config['site_url'],PHP_URL_HOST)!=='127.0.0.1')exit(1);
if($config['db']['driver']==='mysql'&&$config['db']['database']!=='reflex_v341r1_cpanel')exit(1);
require $root.'/app/core.php';require $root.'/app/pro.php';
$action=$argv[2]??'';
if($action==='seed'){
    $template=Database::row("SELECT * FROM rh6_news WHERE status='published' ORDER BY id LIMIT 1");$ids=[];
    foreach(Database::rows('SELECT * FROM rh6_categories ORDER BY id') as $category){
        $count=(int)Database::scalar("SELECT COUNT(*) FROM rh6_news WHERE category_id=? AND status='published'",[$category['id']]);
        for($i=$count;$i<6;$i++){
            $data=$template;unset($data['id']);$data['title']=$category['name'].' · Gündemdeki gelişmeler '.($i+1);$data['slug']='reference-category-fixture-'.$category['id'].'-'.$i;
            $data['category_id']=$category['id'];$data['body']='<p>Yerel test içerik düzeni.</p>';$data['summary']='Günün gelişmeleri ve kategorinin öne çıkan haberleri.';$data['published_at']=date('Y-m-d H:i:s');
            $data['is_headline']=$data['is_top']=$data['is_featured']=$data['is_breaking']=$data['is_box']=0;$data['migration_key']=null;
            $ids[]=Database::save('news',$data);
        }
    }
    echo json_encode($ids,JSON_THROW_ON_ERROR);
}elseif($action==='state'){
    $out=[];foreach(['categories','users'] as $table)$out[$table]=hash('sha256',json_encode(Database::rows('SELECT * FROM rh6_'.$table.' ORDER BY id'),JSON_THROW_ON_ERROR));
    echo json_encode($out,JSON_THROW_ON_ERROR);
}elseif($action==='clean'){
    Database::query("DELETE FROM rh6_news WHERE slug LIKE 'reference-category-fixture-%'");echo '{}';
}else exit(1);
