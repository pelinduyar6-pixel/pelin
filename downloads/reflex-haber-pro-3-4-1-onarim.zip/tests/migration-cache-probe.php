<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit(1);
$root=realpath($argv[1]??'');
if(!in_array($root,['/workspace/reflex-v341r1-test','/workspace/reflex-v341r1-mysql'],true))exit(1);
$config=require $root.'/storage/site.php';
if(parse_url($config['site_url'],PHP_URL_HOST)!=='127.0.0.1')exit(1);
if($config['db']['driver']==='mysql'&&$config['db']['database']!=='reflex_v341r1_cpanel')exit(1);
require $root.'/app/core.php';require $root.'/app/pro.php';
$input=json_decode(stream_get_contents(STDIN),true,512,JSON_THROW_ON_ERROR);
$job=migration_load($input['job'],1);
if($input['action']==='corrupt'){
    unset($job['cache_format']);$table=$job['mapping']['news_table'];
    file_put_contents(migration_dir($job['id']).'/'.$job['tables'][$table]['file'],"{\"body\":\"legacy truncated row\n{\"id\":\"1000\"}\n");migration_store($job);
}
$result=array_intersect_key($job,array_flip(['hash','images','mapping','targets','owner','stage','cursor','imported','duplicates','category_map']));
$result['drafts']=(int)Database::scalar('SELECT COUNT(*) FROM rh6_news WHERE migration_key IN ('.implode(',',array_fill(0,18,'?')).') AND status=?',[...array_map(fn($i)=>hash('sha256',$job['hash'].'|old_news|'.$i),range(0,17)),'draft']);
echo json_encode($result,JSON_THROW_ON_ERROR);
