"""Reproduce the supplied legacy trace with OPcache timestamps disabled, then install the actual repair ZIP."""
from pathlib import Path
from zipfile import ZipFile
import subprocess,hashlib,sqlite3
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
assert BASE=='http://127.0.0.1:8195'
root=Path('/workspace/reflex-v341r1-opcache');archive=Path('/workspace/outputs/reflex-haber-pro-3-4-1-onarim.zip')
def probe(action,job=None):
 r=subprocess.run(['/workspace/reflex-tools/php',str(root/'tests/migration-stale-cache-probe.php'),str(root)],input=json.dumps({'action':action,'job':job}),text=True,capture_output=True,check=True);return json.loads(r.stdout)
def state():
 with sqlite3.connect(root/'storage/site.sqlite') as db:
  db.row_factory=sqlite3.Row
  return {t:[dict(r) for r in db.execute('SELECT * FROM rh6_'+t+(' WHERE name!=\'app_schema\'' if t=='settings' else '')+' ORDER BY id')] for t in ['news','users','categories','news_sources','ads','settings']}
before=state();config_hash=hashlib.sha256((root/'storage/site.php').read_bytes()).hexdigest();job=probe('seed')['job'];receipts=probe('state',job)
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
check(get('/panel/tema').count('name="theme_style"')==4,'Stale four-theme screen is cached before the update')
status,body,_=request(route('/panel/tasima',job=job));check(status==500,'Legacy truncated preview reproduces the supplied migration failure')
entry=json.loads((root/'storage/logs/app.log').read_text().splitlines()[-1]);check(entry['type']=='JsonException' and str(entry['code'])=='3' and any(t['file'].endswith('admin-migration.php') and t['line']==42 for t in entry['trace']),'Exception type/code and old dispatcher line match 920c0e9b24ee')
sentinel=root/'cache-sentinel.php';assert not sentinel.exists();sentinel.write_text("<?php echo 'sentinel-cached-before';")
check(request('cache-sentinel.php')[1]=='sentinel-cached-before','Unrelated non-manifest script is cached for isolation check')
try:
 sentinel.write_text("<?php echo 'sentinel-changed-on-disk';")
 with ZipFile(archive) as z:z.extractall(root)
 check(request(route('/panel/tasima',job=job))[0]==500,'Correct disk ZIP alone still fails when PHP uses cached old code')
 check(get('/panel/tema').count('name="theme_style"')==4,'Cached old theme screen still exposes four options after extraction')
 report=request('reflex-panel-kurtarma-341r1.php')[1];check('Diskteki 3.4.1-r1 dosyaları eksiksiz' in report and '8 / 8 tema' in report,'Independent fresh utility verifies the actual disk version and all eight themes')
 token=csrf(report)
 guest=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 check(request('reflex-panel-kurtarma-341r1.php',{'csrf':token},opener=guest)[0]==403,'Anonymous cache invalidation denied')
 check(request('reflex-panel-kurtarma-341r1.php',{'csrf':'invalid'})[0]==403,'Invalid CSRF cannot invalidate code')
 status,body,_=request('reflex-panel-kurtarma-341r1.php',{'csrf':token});check(status==200 and re.search(r'Bu sitenin [1-9]\d* PHP dosyası için önbellek yenilendi',body),'Authenticated refresh actually invalidates this site package PHP')
 check(request('cache-sentinel.php')[1]=='sentinel-cached-before','Unrelated cached script is untouched')
 check(get('/panel/tema').count('name="theme_style"')==8,'All eight themes appear in the running panel after refresh')
 page=request(route('/panel/tasima',job=job))[1];check('SQL incelemesine devam et' in page,'Same failing job opens retained-SQL recovery after refresh')
 status,result,_=request(route('/panel/tasima/incele'),{'job':job},csrf(page));assert status==200 and json.loads(result)['done'];page=request(route('/panel/tasima',job=job))[1];check('Haber önizlemesi' in page and 'Eski aktarım haberi' in page and 'uploads/migration/' in page,'Existing SQL and image return to preview without another upload')
 check(probe('state',job)==receipts,'Source SQL/image/mapping/receipts are preserved byte-for-byte')
 check(state()==before and hashlib.sha256((root/'storage/site.php').read_bytes()).hexdigest()==config_hash,'Existing accounts/passwords/news/category IDs/settings/private config remain unchanged')
 check('name="reflex-version" content="3.4.1-r1"' in get('/'),'Running application identifies the repair release')
finally:sentinel.unlink(missing_ok=True)
print('Stale migration/theme PHP cache recovery completed')
