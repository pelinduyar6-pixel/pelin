<?php
declare(strict_types=1);

/** One catalog for the panel, validation and public routing. */
function theme_catalog(): array {
    return [
        '1'=>['name'=>'Demo 6','hint'=>'Klasik manşet ve sağ haber sütunu','layout'=>'editorial'],
        '2'=>['name'=>'Demo 8','hint'=>'Ortada manşet, iki yanda haber kartları','layout'=>'showcase'],
        '3'=>['name'=>'Demo 5','hint'=>'Kırmızı menü ve geniş manşet','layout'=>'mosaic'],
        '4'=>['name'=>'Demo 1','hint'=>'Vitrin banner ve beşli haber şeridi','layout'=>'compact'],
        '5'=>['name'=>'Medyabar','hint'=>'Yerel yayın akışı ve dörtlü kategori kartları','layout'=>'editorial','category_profile'=>'regional','reference'=>'https://medyabar.com/'],
        '6'=>['name'=>'İmza Gazetesi','hint'=>'Büyük haber + dört kart; sporda üç sütun','layout'=>'editorial','category_profile'=>'flow','reference'=>'https://www.imzagazetesi.com/'],
        '7'=>['name'=>'Kulga','hint'=>'Büyük vitrin, küçük haberler ve kategori akışı','layout'=>'mosaic','category_profile'=>'wind','reference'=>'https://www.kulga.web.tr/'],
        '8'=>['name'=>'EsenHaber Demo 3','hint'=>'Kategoriye göre üçlü kartlar, çift manşet ve listeler','layout'=>'showcase','category_profile'=>'esen','reference'=>'https://esenhaber.cizoglubilisim.com/demo3/'],
    ];
}

function active_theme(): string {
    $theme=setting('theme_style','1');
    return array_key_exists($theme,theme_catalog())?$theme:'1';
}
