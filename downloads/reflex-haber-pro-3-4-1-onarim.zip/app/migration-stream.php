<?php
declare(strict_types=1);
/* Read a dump a row at a time, including one arbitrarily long extended INSERT. */
final class MigrationReader {
    private $handle;private string $buffer='';private int $index=0;private int $offset;
    public function __construct(string $path,int $offset=0){$this->handle=fopen($path,'rb');if(!$this->handle)throw new RuntimeException('SQL okunamıyor.');fseek($this->handle,$offset);$this->offset=$offset;}
    public function peek(int $ahead=0):string {while($this->index+$ahead>=strlen($this->buffer)&&!feof($this->handle)){$this->buffer=substr($this->buffer,$this->index);$this->index=0;$this->buffer.=fread($this->handle,65536);}return $this->buffer[$this->index+$ahead]??'';}
    public function take():string {$c=$this->peek();if($c!==''){$this->index++;$this->offset++;}return $c;}
    public function offset():int{return $this->offset;}
    public function __destruct(){fclose($this->handle);}
}
function migration_file_units(string $path,int $offset=0,string $insert=''):Generator {
    $r=new MigrationReader($path,$offset);$buffer='';$quote='';$depth=0;$tuple=false;$needTuple=false;
    if($offset===0&&$r->peek()==="\xEF"&&$r->peek(1)==="\xBB"&&$r->peek(2)==="\xBF"){$r->take();$r->take();$r->take();}
    while(($c=$r->take())!==''){
        if($quote!==''){
            $buffer.=$c;
            if($c==='\\'){$next=$r->take();if($next==='')throw new InvalidArgumentException('SQL metni kapanmamış.');$buffer.=$next;}
            elseif($c===$quote){if($r->peek()===$quote)$buffer.=$r->take();else $quote='';}
            continue;
        }
        if(($c==='-'&&$r->peek()==='-'&&ctype_space($r->peek(1)?:' '))||$c==='#') {while(($x=$r->take())!==''&&$x!=="\n"){}$buffer.=' ';continue;}
        if($c==='/'&&$r->peek()==='*'){$r->take();$closed=false;while(($x=$r->take())!==''){if($x==='*'&&$r->peek()==='/'){$r->take();$closed=true;break;}}if(!$closed)throw new InvalidArgumentException('SQL yorumu kapanmamış.');$buffer.=' ';continue;}
        if($insert!==''&&!$tuple){
            if(ctype_space($c))continue;
            if($c===','&&!$needTuple){$needTuple=true;continue;}
            if($c===';'&&!$needTuple){$insert='';$buffer='';continue;}
            if($c==='('&&$needTuple){$tuple=true;$depth=1;$buffer='(';continue;}
            throw new InvalidArgumentException('INSERT sonunda yalnızca VALUES kayıtları desteklenir.');
        }
        if(in_array($c,["'",'"','`'],true)){$quote=$c;$buffer.=$c;continue;}
        if(!$tuple&&$c==='('&&preg_match('/^\s*INSERT\s+(?:IGNORE\s+)?INTO\s+`?[a-zA-Z_][a-zA-Z0-9_$]*`?\s*(?:\([^)]*\))?\s*VALUES\s*$/isD',$buffer)){$insert=trim($buffer);$buffer='(';$tuple=true;$depth=1;continue;}
        if($tuple){$buffer.=$c;if($c==='(')$depth++;elseif($c===')'&&--$depth===0){yield ['statement'=>$insert.' '.$buffer,'offset'=>$r->offset(),'insert'=>$insert];$buffer='';$tuple=false;$needTuple=false;}continue;}
        if($c===';'){if(trim($buffer)!=='')yield ['statement'=>trim($buffer),'offset'=>$r->offset(),'insert'=>''];$buffer='';}else $buffer.=$c;
    }
    if($quote!==''||$tuple||$needTuple)throw new InvalidArgumentException('SQL dosyası eksik veya kapanmamış bir kayıt içeriyor.');
    if($insert===''&&trim($buffer)!=='')yield ['statement'=>trim($buffer),'offset'=>$r->offset(),'insert'=>''];
    return $r->offset();
}
function migration_parse_statement(string $statement,string $directory,array &$tables):void {
    if(!mb_check_encoding($statement,'UTF-8'))throw new InvalidArgumentException('SQL dosyasını UTF-8 olarak dışa aktarın.');
    if(preg_match('/^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(`?[a-zA-Z_][a-zA-Z0-9_$]*`?)\s*\((.*)\)\s*.*$/isD',$statement,$m)){
        $table=migration_identifier($m[1]);$columns=[];
        foreach(preg_split('/,\s*(?:\r?\n|(?=`?[a-zA-Z_][a-zA-Z0-9_$]*`?\s+))/',$m[2]) as $definition)if(preg_match('/^\s*(`?[a-zA-Z_][a-zA-Z0-9_$]*`?)\s+(?:tinyint|smallint|mediumint|bigint|int|integer|varchar|char|text|tinytext|mediumtext|longtext|datetime|timestamp|date|time|decimal|float|double|enum|set|boolean|bool|blob|json|varbinary|binary)\b/i',$definition,$c))$columns[]=migration_identifier($c[1]);
        $tables[$table]??=['columns'=>$columns,'count'=>0,'bytes'=>0,'file'=>hash('sha256',$table).'.jsonl'];if(!$tables[$table]['columns'])$tables[$table]['columns']=$columns;
    }elseif(preg_match('/^INSERT\s+(?:IGNORE\s+)?INTO\s+(`?[a-zA-Z_][a-zA-Z0-9_$]*`?)\s*(?:\(([^)]*)\))?\s*VALUES\s*(.*)$/isD',$statement,$m)){
        $table=migration_identifier($m[1]);$columns=trim($m[2]??'')!==''?array_map('migration_identifier',explode(',',$m[2])):($tables[$table]['columns']??[]);
        if(!$columns||count(array_unique($columns))!==count($columns))throw new InvalidArgumentException('Tablo alanları okunamadı: '.$table.'. CREATE TABLE veya alan adlı INSERT kullanın.');
        $tables[$table]??=['columns'=>$columns,'count'=>0,'bytes'=>0,'file'=>hash('sha256',$table).'.jsonl'];$file=$directory.'/'.$tables[$table]['file'];$h=fopen($file,'ab');if(!$h)throw new RuntimeException('Aktarım verileri yazılamadı.');chmod($file,0600);
        // An append stream starts with a logical offset of zero. Seek to the real
        // end before using ftell() as a checkpoint across analysis requests.
        try{if(fseek($h,0,SEEK_END)!==0)throw new RuntimeException('Aktarım kayıtlarının sonu okunamadı.');foreach(migration_literals($m[3]) as $values){if(count($values)!==count($columns))throw new InvalidArgumentException('Alan ve değer sayısı uyuşmuyor: '.$table);$line=json_encode(array_combine($columns,$values),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)."\n";if(fwrite($h,$line)!==strlen($line))throw new RuntimeException('Aktarım verileri yazılamadı. Disk alanını kontrol edin.');$tables[$table]['count']++;}$tables[$table]['bytes']=ftell($h);$tables[$table]['columns']=array_values(array_unique([...$tables[$table]['columns'],...$columns]));}finally{fclose($h);}
    }elseif(preg_match('/^(?:INSERT|REPLACE|COPY)\b/i',$statement))throw new InvalidArgumentException('Bu döküm biçimi desteklenmiyor. MySQL INSERT VALUES biçimini kullanın.');
}
function migration_analyze(array $job):array {
    if($job['stage']!=='analyzing')return $job;
    $dir=migration_dir($job['id']);$tables=$job['tables'];
    // Recover a request lost between writes and publication of the checkpoint.
    $known=[];foreach($tables as $t){$known[]=$t['file'];if(is_file($dir.'/'.$t['file'])){$h=fopen($dir.'/'.$t['file'],'c+b');ftruncate($h,$t['bytes']??0);fclose($h);}}
    foreach(glob($dir.'/*.jsonl')?:[] as $file)if(!in_array(basename($file),$known,true))unlink($file);
    $units=migration_file_units($dir.'/source.sql',$job['parse_offset']??0,$job['parse_insert']??'');$started=microtime(true);$count=0;$complete=true;
    foreach($units as $u){migration_parse_statement($u['statement'],$dir,$tables);$job['parse_offset']=$u['offset'];$job['parse_insert']=$u['insert'];if(++$count>=1000||microtime(true)-$started>1.5){$complete=false;break;}}
    $job['tables']=$tables;
    if($complete){$job['tables']=array_filter($tables,fn($t)=>$t['count']>0);if(!$job['tables'])throw new InvalidArgumentException('SQL yalnızca tablo şeması içeriyor veya INSERT kaydı yok. Eski sitenizin veri içeren SQL yedeğini seçin.');$job['parse_offset']=filesize($dir.'/source.sql');$job['stage']=$job['resume_stage']??'mapping';unset($job['parse_insert'],$job['resume_stage']);}
    migration_store($job);return $job;
}
