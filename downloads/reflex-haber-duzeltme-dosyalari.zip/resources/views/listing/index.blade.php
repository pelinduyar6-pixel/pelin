@extends('layouts.site')
@section('title', $title.' | Reflex Haber')
@section('content')
<main class="container home">
    <div class="section-head"><h2>{{ $title }}</h2><a href="{{ route('home') }}">ANA SAYFA →</a></div>
    <div class="newsgrid">
        @forelse($news as $n)
            <a class="news-card" href="{{ route('news.show', $n) }}">
                <img src="{{ $n->image ?: asset('assets/img/news-placeholder.svg') }}" alt="" loading="lazy">
                <small>{{ $n->category?->name }} • {{ $n->published_at?->format('d.m.Y H:i') }}</small>
                <b>{{ $n->title }}</b><p>{{ $n->spot }}</p>
            </a>
        @empty
            <p class="empty-state">Bu bölümde henüz haber bulunmuyor.</p>
        @endforelse
    </div>
    {{ $news->links() }}
</main>
@endsection
