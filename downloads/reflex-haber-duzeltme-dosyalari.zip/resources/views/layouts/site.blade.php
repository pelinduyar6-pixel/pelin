<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>@yield('title', 'Reflex Haber — Son Dakika Haberleri')</title>
    <meta name="description" content="@yield('description', 'Türkiye ve dünyadan son dakika haberleri')">
    <meta name="robots" content="@yield('robots', 'index,follow')">
    <link rel="stylesheet" href="{{ asset('assets/css/reflex.css') }}">
    <script src="{{ asset('assets/js/reflex.js') }}" defer></script>
</head>
<body>
<a class="skip-link" href="#main-content">İçeriğe geç</a>
<div class="utility"><div class="container utility-in">
    <span>GÜNCEL, HIZLI, GÜVENİLİR</span>
    <div class="utility-links"><a href="{{ route('home') }}">Ana Sayfa</a><a href="{{ route('gallery') }}">Foto Galeri</a><a href="{{ route('video') }}">Video</a><a href="{{ route('authors.index') }}">Yazarlar</a></div>
</div></div>
<header class="masthead"><div class="container mast">
    <button class="mobile-menu" data-menu-toggle aria-controls="main-navigation" aria-expanded="false" aria-label="Menüyü aç">☰</button>
    <a class="brand" href="{{ route('home') }}" aria-label="Reflex Haber ana sayfa"><strong>REFLEX</strong><span>HABER</span></a>
    <div class="mast-date"><b>{{ now()->translatedFormat('d F Y') }}</b><span>{{ now()->translatedFormat('l') }}</span></div>
    <form class="search" action="{{ route('search') }}" role="search"><label class="sr-only" for="site-search">Haber ara</label><input id="site-search" name="q" value="{{ request('q') }}" placeholder="Haber, yazar veya konu ara…"><button aria-label="Ara">⌕</button></form>
    <a class="live-pill" href="{{ route('search') }}">● SON HABERLER</a>
</div></header>
<nav class="mainnav" id="main-navigation" aria-label="Ana menü"><div class="container nav-in">
    <a class="home-icon" href="{{ route('home') }}" aria-label="Ana sayfa">⌂</a>
    @foreach(\App\Models\Category::where('active', true)->orderBy('sort_order')->take(12)->get() as $c)
        <a href="{{ route('category.show', $c) }}">{{ mb_strtoupper($c->name, 'UTF-8') }}</a>
    @endforeach
    <a href="{{ route('authors.index') }}">YAZARLAR</a>
</div></nav>
<div class="services"><div class="container services-in">
    <a href="{{ route('search', ['q' => 'Nöbetçi Eczane']) }}">✚ Nöbetçi Eczaneler</a>
    <a href="{{ route('search', ['q' => 'Hava Durumu']) }}">☁ Hava Durumu</a>
    <a href="{{ route('search', ['q' => 'Namaz Vakitleri']) }}">☾ Namaz Vakitleri</a>
    <a href="{{ route('search', ['q' => 'Spor']) }}">⚽ Spor Haberleri</a>
    <a class="whatsapp" href="{{ route('authors.index') }}">✎ Köşe Yazıları</a>
</div></div>
<div id="main-content">@yield('content')</div>
<footer class="footer"><div class="container footer-grid">
    <div><a class="brand footer-brand" href="{{ route('home') }}"><strong>REFLEX</strong><span>HABER</span></a><p>Türkiye’den ve dünyadan son dakika haberleri.</p></div>
    <div><h4>KATEGORİLER</h4>@foreach(\App\Models\Category::where('active', true)->orderBy('sort_order')->take(5)->get() as $c)<a href="{{ route('category.show', $c) }}">{{ $c->name }}</a>@endforeach</div>
    <div><h4>KEŞFET</h4><a href="{{ route('search') }}">Son Haberler</a><a href="{{ route('authors.index') }}">Yazarlar</a><a href="{{ route('gallery') }}">Foto Galeri</a><a href="{{ route('video') }}">Video Haberler</a></div>
    <div><h4>GÜNDEMİ TAKİP EDİN</h4><p>Gelişmeleri, analizleri ve köşe yazılarını keşfedin.</p><a class="footer-cta" href="{{ route('search') }}">TÜM HABERLER →</a></div>
</div><div class="footer-bottom">© {{ date('Y') }} Reflex Haber • Tüm hakları saklıdır.</div></footer>
</body>
</html>
