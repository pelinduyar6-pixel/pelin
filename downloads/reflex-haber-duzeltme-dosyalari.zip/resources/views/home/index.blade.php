@extends('layouts.site')
@section('content')
@if($breaking->isNotEmpty())
<div class="ticker"><div class="container ticker-in"><b>⚡ SON DAKİKA</b><div class="ticker-scroll">@foreach($breaking as $n)<a href="{{ route('news.show', $n) }}">{{ $n->title }}</a>@endforeach</div></div></div>
@endif
<main class="container home">
@if($top->isNotEmpty())
<section class="headline-cards" aria-label="Sürmanşet haberleri">
    @foreach($top as $n)<a class="headline-card" href="{{ route('news.show', $n) }}"><img src="{{ $n->image ?: asset('assets/img/news-placeholder.svg') }}" alt=""><div><small>{{ $n->category?->name }}</small><h2>{{ $n->title }}</h2></div></a>@endforeach
</section>
@endif
<section class="hero-area">
    <div class="hero-main" data-headline-slider aria-label="Manşet haberleri">
        @forelse($headlines as $n)
        <a href="{{ route('news.show', $n) }}" class="hero-story" data-slide @if(!$loop->first) hidden @endif>
            <img class="hero-image" src="{{ $n->image ?: asset('assets/img/news-placeholder.svg') }}" alt="">
            <div><small>{{ $n->category?->name ?: 'GÜNCEL' }}</small><h1>{{ $n->title }}</h1><p>{{ $n->spot }}</p></div>
        </a>
        @empty
        <div class="hero-empty"><span class="hero-eyebrow">REFLEX HABER</span><h1>Haberin merkezinde,<br>gündemin yanında.</h1><p>Türkiye’den ve dünyadan gelişmeler.</p><a href="{{ route('authors.index') }}">Yazarlarımızı keşfedin →</a></div>
        @endforelse
        @if($headlines->count() > 1)
        <div class="slider-controls"><button data-slide-prev aria-label="Önceki haber">‹</button><div class="slider-dots">@foreach($headlines as $n)<button data-slide-to="{{ $loop->index }}" aria-label="{{ $loop->iteration }}. manşet" aria-pressed="{{ $loop->first ? 'true' : 'false' }}">{{ $loop->iteration }}</button>@endforeach</div><button data-slide-next aria-label="Sonraki haber">›</button></div>
        @endif
    </div>
    <aside class="news-feed"><div class="feed-title"><span class="status-dot"></span> HABER AKIŞI <a href="{{ route('search') }}">TÜMÜ →</a></div>
        @forelse($latest->take(5) as $n)<a class="feed-item" href="{{ route('news.show', $n) }}"><time>{{ $n->published_at?->format('H:i') ?: '—' }}</time><div><small>{{ $n->category?->name }}</small><b>{{ $n->title }}</b></div></a>@empty<p class="empty-state">Yeni haberler burada listelenecek.</p>@endforelse
    </aside>
</section>
<nav class="topic-strip" aria-label="Haber kategorileri"><b>GÜNDEMİ KEŞFET</b>@foreach($categories->take(5) as $c)<a href="{{ route('category.show', $c) }}">{{ $c->name }} <span>↗</span></a>@endforeach</nav>
<section class="content-grid">
    <div class="primary">
        <div class="section-head"><h2>GÜNÜN ÖNE ÇIKANLARI</h2><a href="{{ route('search') }}">TÜM HABERLER →</a></div>
        <div class="featured-grid">@forelse($featured->take(4) as $n)<a class="mosaic-card" href="{{ route('news.show', $n) }}"><img src="{{ $n->image ?: asset('assets/img/news-placeholder.svg') }}" alt="" loading="lazy"><div><small>{{ $n->category?->name }}</small><h3>{{ $n->title }}</h3></div></a>@empty<p class="empty-state">Henüz yayımlanmış haber bulunmuyor.</p>@endforelse</div>
        <div class="section-head"><h2>SON HABERLER</h2><a href="{{ route('search') }}">TÜM HABERLER →</a></div>
        <div class="list-news">@foreach($latest->take(8) as $n)<a href="{{ route('news.show', $n) }}"><img src="{{ $n->image ?: asset('assets/img/news-placeholder.svg') }}" alt="" loading="lazy"><div><small>{{ $n->category?->name }} • {{ $n->published_at?->format('H:i') }}</small><h3>{{ $n->title }}</h3><p>{{ $n->spot }}</p></div></a>@endforeach</div>
    </div>
    <aside class="sidebar">
        <div class="side-box"><div class="box-head">GÜNÜN ÖNE ÇIKANLARI</div>@foreach($featured->take(5) as $n)<a class="rank" href="{{ route('news.show', $n) }}"><b>{{ $loop->iteration }}</b><span>{{ $n->title }}</span></a>@endforeach</div>
        <div class="side-box"><div class="box-head">YAZARLAR <a href="{{ route('authors.index') }}">TÜMÜ →</a></div>@foreach($authors as $a)<a class="author-mini" href="{{ route('author.show', $a) }}"><img src="{{ $a->photo ?: asset('assets/img/avatar.svg') }}" alt="" loading="lazy"><span><b>{{ $a->name }}</b><small>{{ $a->title ?: 'Köşe Yazarı' }}</small></span></a>@endforeach</div>
        <div class="ad-slot"><small>REKLAM</small><span>REKLAM ALANI</span><small>300 × 250</small></div>
    </aside>
</section>
@if($sections['Spor']->isNotEmpty())
<section class="dark-section" id="spor"><div class="section-head light"><h2>SPOR</h2><a href="{{ route('search', ['q' => 'Spor']) }}">TÜMÜ →</a></div><div class="sport-grid">@foreach($sections['Spor'] as $n)<a href="{{ route('news.show', $n) }}"><img src="{{ $n->image ?: asset('assets/img/news-placeholder.svg') }}" alt="" loading="lazy"><b>{{ $n->title }}</b></a>@endforeach</div></section>
@endif
<div class="three-cols">@foreach(['Ekonomi','Teknoloji','Magazin'] as $name)@if($sections[$name]->isNotEmpty())<section><div class="section-head"><h2>{{ mb_strtoupper($name, 'UTF-8') }}</h2></div>@foreach($sections[$name] as $n)<a class="compact" href="{{ route('news.show', $n) }}"><img src="{{ $n->image ?: asset('assets/img/news-placeholder.svg') }}" alt="" loading="lazy"><b>{{ $n->title }}</b></a>@endforeach</section>@endif @endforeach</div>
@if($gallery->isNotEmpty())
<section class="gallery-section"><div class="section-head"><h2>FOTO GALERİ</h2><a href="{{ route('gallery') }}">TÜMÜ →</a></div><div class="gallery-grid">@foreach($gallery as $n)<a href="{{ route('news.show', $n) }}"><img class="hero-image" src="{{ $n->image ?: asset('assets/img/news-placeholder.svg') }}" alt="" loading="lazy"><b>{{ $n->title }}</b></a>@endforeach</div></section>
@endif
</main>
@endsection
