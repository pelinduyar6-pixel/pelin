"""HTTP regression checks. Run write checks only against a disposable test database.

REFLEX_TEST_BASE_URL defaults to http://127.0.0.1:8086.
Optional panel checks use REFLEX_TEST_ADMIN_EMAIL and REFLEX_TEST_ADMIN_PASSWORD.
Set REFLEX_TEST_WRITES=1 to enable category, author and article CRUD checks.
"""

import html
import os
import re
import unittest
import uuid
from http.cookiejar import CookieJar
from urllib.error import HTTPError
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPCookieProcessor, Request, build_opener


BASE = os.environ.get("REFLEX_TEST_BASE_URL", "http://127.0.0.1:8086").rstrip("/")


class Client:
    def __init__(self):
        self.opener = build_opener(HTTPCookieProcessor(CookieJar()))

    def request(self, path, data=None, referer=None):
        headers = {"Referer": BASE + (referer or path)}
        request = Request(BASE + path, data=urlencode(data).encode() if data is not None else None, headers=headers)
        try:
            response = self.opener.open(request, timeout=20)
        except HTTPError as error:
            response = error
        return response.code, response.read().decode("utf-8", errors="replace"), urlsplit(response.url).path

    def token(self, path):
        status, body, _ = self.request(path)
        if status != 200:
            raise AssertionError(f"Cannot get form: {path}, HTTP {status}")
        match = re.search(r'name="_token"[^>]*value="([^"]+)"', body)
        if not match:
            raise AssertionError(f"CSRF token missing: {path}")
        return html.unescape(match.group(1))

    def submit(self, path, data, form):
        return self.request(path, {"_token": self.token(form), **data}, form)


class PublicChecks(unittest.TestCase):
    def setUp(self):
        self.client = Client()

    def test_home(self):
        status, body, _ = self.client.request("/")
        self.assertEqual(status, 200)
        self.assertIn("HABER AKIŞI", body)
        self.assertIn('id="main-navigation"', body)

    def test_authors(self):
        status, body, _ = self.client.request("/yazarlar")
        self.assertEqual(status, 200)
        self.assertIn("YAZARLAR", body)

    def test_login_form(self):
        self.assertTrue(self.client.token("/panel/giris"))

    def test_search(self):
        status, body, _ = self.client.request("/arama?q=regression")
        self.assertEqual(status, 200)
        self.assertIn("Arama: regression", body)

    def test_gallery(self):
        self.assertEqual(self.client.request("/galeri")[0], 200)

    def test_video(self):
        self.assertEqual(self.client.request("/video")[0], 200)

    def test_assets(self):
        for path, expected in [("/assets/css/reflex.css", "headline-cards"), ("/assets/js/reflex.js", "data-headline-slider"), ("/assets/img/news-placeholder.svg", "<svg")]:
            with self.subTest(path=path):
                status, body, _ = self.client.request(path)
                self.assertEqual(status, 200)
                self.assertIn(expected, body)


@unittest.skipUnless(os.environ.get("REFLEX_TEST_ADMIN_EMAIL") and os.environ.get("REFLEX_TEST_ADMIN_PASSWORD"), "Panel test credentials not supplied")
class PanelChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = Client()
        status, _, destination = cls.client.submit("/panel/giris", {"email": os.environ["REFLEX_TEST_ADMIN_EMAIL"], "password": os.environ["REFLEX_TEST_ADMIN_PASSWORD"]}, "/panel/giris")
        if status != 200 or destination != "/panel":
            raise AssertionError(f"Panel login failed: HTTP {status}, {destination}")

    def test_panel_screens(self):
        for path in ("/panel", "/panel/haberler", "/panel/haberler/create", "/panel/yazarlar", "/panel/yazarlar/create", "/panel/kategoriler", "/panel/reklamlar", "/panel/ajans-merkezi", "/panel/botlar", "/panel/ai-merkezi", "/panel/sosyal-medya", "/panel/ozel-kodlar", "/panel/ayarlar"):
            with self.subTest(path=path):
                status, body, destination = self.client.request(path)
                self.assertEqual(status, 200)
                self.assertEqual(destination, path)
                self.assertIn("Reflex Haber Yönetim Paneli", body)

    @unittest.skipUnless(os.environ.get("REFLEX_TEST_WRITES") == "1", "Write tests disabled")
    def test_author_without_password_and_long_website(self):
        marker = uuid.uuid4().hex[:10]
        name = "Regression Author " + marker
        data = {"name": name, "email": marker + "@example.test", "role": "author", "active": "1", "website": "https://example.test/" + "a" * 300}
        status, body, _ = self.client.submit("/panel/yazarlar", data, "/panel/yazarlar/create")
        self.assertEqual(status, 200)
        self.assertIn(name, body)
        status, public, _ = self.client.request("/yazarlar")
        match = re.search(r'href="[^"]*/yazar/([^"/]+)"[^>]*>(?:(?!</a>).)*?<h3>' + re.escape(name) + r"</h3>", public, re.S)
        self.assertIsNotNone(match)
        status, profile, _ = self.client.request("/yazar/" + match.group(1))
        self.assertEqual(status, 200)
        self.assertIn(name, profile)

    @unittest.skipUnless(os.environ.get("REFLEX_TEST_WRITES") == "1", "Write tests disabled")
    def test_duplicate_category_names_without_slug(self):
        name = "Regression " + uuid.uuid4().hex[:10]
        for _ in range(2):
            status, body, _ = self.client.submit("/panel/kategoriler", {"name": name, "active": "1", "show_home": "1"}, "/panel/kategoriler")
            self.assertEqual(status, 200)
        rows = re.findall(r"<tr><td>" + re.escape(name) + r"</td><td>([^<]+)</td>", body)
        self.assertEqual(len(rows), 2)
        self.assertEqual(len(set(rows)), 2)

    @unittest.skipUnless(os.environ.get("REFLEX_TEST_WRITES") == "1", "Write tests disabled")
    def test_article_optional_slug_robots_and_publication(self):
        marker = uuid.uuid4().hex[:10]
        title = "Regression article " + marker
        slug = "regression-article-" + marker
        data = {"title": title, "body": "<p>Regression content</p>", "status": "draft", "robots": "index,follow", "image": "https://example.test/" + "a" * 300}
        status, body, _ = self.client.submit("/panel/haberler", data, "/panel/haberler/create")
        self.assertEqual(status, 200)
        self.assertIn(title, body)
        row = re.search(r"<tr><td>" + re.escape(title) + r"</td>.*?/panel/haberler/(\d+)/edit", body, re.S)
        self.assertIsNotNone(row)
        article_id = row.group(1)
        edit = "/panel/haberler/" + article_id + "/edit"
        self.assertEqual(self.client.request("/haber/" + slug)[0], 404)
        data.update({"_method": "PUT", "status": "published"})
        status, _, _ = self.client.submit("/panel/haberler/" + article_id, data, edit)
        self.assertEqual(status, 200)
        status, article, _ = self.client.request("/haber/" + slug)
        self.assertEqual(status, 200)
        self.assertIn("Regression content", article)
        data["published_at"] = "2099-01-01 12:00:00"
        self.assertEqual(self.client.submit("/panel/haberler/" + article_id, data, edit)[0], 200)
        self.assertEqual(self.client.request("/haber/" + slug)[0], 404)


if __name__ == "__main__":
    unittest.main(verbosity=2)
