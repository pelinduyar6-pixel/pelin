<?php

namespace Database\Seeders;

use App\Models\{Category, Setting, User};
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $email = trim((string) env('NEWS_ADMIN_EMAIL', ''));
        $password = (string) env('NEWS_ADMIN_PASSWORD', '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new \RuntimeException('İlk yönetici için .env içinde geçerli NEWS_ADMIN_EMAIL tanımlayın.');
        }
        $user = User::where('email', $email)->first();
        if (!$user) {
            if (strlen($password) < 10) throw new \RuntimeException('İlk yönetici için .env içinde en az 10 karakter NEWS_ADMIN_PASSWORD tanımlayın.');
            $user = User::create(['name' => 'Reflex Admin', 'email' => $email, 'password' => Hash::make($password), 'role' => 'admin', 'active' => true]);
        }
        if (empty($user->slug)) $user->update(['slug' => (Str::slug($user->name) ?: 'yazar').'-'.$user->id]);
        $names = ['Gündem','Türkiye','Dünya','Ekonomi','Spor','Magazin','Teknoloji','Sağlık','Yerel','Yaşam','Kültür-Sanat'];
        foreach ($names as $i => $name) Category::firstOrCreate(['slug' => Str::slug($name)], ['name' => $name, 'sort_order' => $i + 1, 'active' => true, 'show_home' => true]);
        Setting::firstOrCreate(['key' => 'site_name'], ['group' => 'general', 'value' => 'Reflex Haber', 'type' => 'text']);
        Setting::firstOrCreate(['key' => 'tagline'], ['group' => 'general', 'value' => 'Doğru Haber, Güçlü Yorum', 'type' => 'text']);
    }
}
