<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('users')) return;
        foreach (['photo','website','twitter','facebook','instagram','linkedin'] as $column) {
            Schema::table('users', fn (Blueprint $table) => $table->string($column, 500)->nullable()->change());
        }
        foreach (DB::table('users')->where(fn ($q) => $q->whereNull('slug')->orWhere('slug', '')->orWhere('slug', '0'))->get(['id','name']) as $author) {
            $base = substr(Str::slug($author->name) ?: 'yazar', 0, 200).'-'.$author->id;
            $slug = $base;
            $suffix = 2;
            while (DB::table('users')->where('slug', $slug)->where('id', '!=', $author->id)->exists()) $slug = $base.'-'.$suffix++;
            DB::table('users')->where('id', $author->id)->update(['slug' => $slug]);
        }
        DB::table('users')->whereNull('sort_order')->update(['sort_order' => 0]);
    }
    public function down(): void {}
};
