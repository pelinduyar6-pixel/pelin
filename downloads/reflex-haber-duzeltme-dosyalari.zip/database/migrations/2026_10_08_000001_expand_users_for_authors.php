<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('users')) return;
        foreach (['slug','photo','title','phone','website','twitter','facebook','instagram','linkedin','bio','short_bio','sort_order'] as $column) {
            if (Schema::hasColumn('users', $column)) continue;
            Schema::table('users', function (Blueprint $table) use ($column) {
                if ($column === 'sort_order') {
                    $table->unsignedInteger($column)->default(0);
                } elseif (in_array($column, ['bio', 'short_bio'])) {
                    $table->text($column)->nullable();
                } else {
                    $length = in_array($column, ['photo','website','twitter','facebook','instagram','linkedin']) ? 500 : 255;
                    $table->string($column, $length)->nullable();
                }
            });
        }
        foreach (DB::table('users')->whereNull('slug')->get(['id','name']) as $author) {
            DB::table('users')->where('id', $author->id)->update(['slug' => (Str::slug($author->name) ?: 'yazar').'-'.$author->id]);
        }
    }
    public function down(): void {}
};
