<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('news')) return;
        foreach (['image', 'video_url', 'source_url', 'canonical_url'] as $column) {
            if (Schema::hasColumn('news', $column)) {
                Schema::table('news', fn (Blueprint $table) => $table->string($column, 500)->nullable()->change());
            }
        }
    }
    public function down(): void {}
};
