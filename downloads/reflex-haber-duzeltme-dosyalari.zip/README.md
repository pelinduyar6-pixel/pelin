# Reflex Haber — Sunucu hatası düzeltmesi ve portal arayüzü

Bu paket Laravel 13.17.0 kullanır. **PHP 8.3 veya üzeri** gerekir; yerel doğrulama PHP 8.4.24 ve MariaDB 11.8 üzerinde yapıldı. Composer `vendor` bağımlılıkları ZIP içinde bulunur; hostingde Composer çalıştırmak zorunlu değildir.

## Mevcut sunucuya yükleme

1. Sunucu dosyalarının ve veritabanının yedeğini alın.
2. Hosting panelinden alan adının **web PHP sürümünü** 8.3 veya 8.4 yapın. CLI sürümü tek başına yeterli değildir.
3. ZIP dosyalarını mevcut proje ana dizinine yükleyin. **Mevcut `.env` dosyanızı koruyun.** Gerçek `.env` bu pakete dahil edilmedi. Mevcut yüklenmiş resimleri koruyun.
4. `https://ALAN-ADINIZ/kurulum.php` adresini açıp **Sistemi Kur / Onar** düğmesine basın. Bu sürüm eski `installer.lock` kaydına rağmen bir defa çalışabilir; yeni kilidi `storage/app/installer-v4.lock` dosyasıdır.
5. Onarım başarılıysa `kurulum.php` ve `public/kurulum.php` dosyalarını sunucudan silin.
6. Ana sayfayı, `/yazarlar`, `/panel/giris` ve panelden haber ekleme ekranını kontrol edin. Gerekirse tarayıcı önbelleğini yenileyin.

Document root için `/public` önerilir. Ana dizini document root kullanan Apache hostingler için kök `index.php` ve `.htaccess` de pakettedir. Kökten çalıştırmada `/assets` ve `/storage` public konumlarına yönlendirilir. Nginx kullanılıyorsa `.htaccess` çalışmaz; document root `/public` olmalı ve standart Laravel `try_files $uri $uri/ /index.php?$query_string;` kuralı tanımlanmalıdır.

## PHP ve ortam gereksinimleri

- MySQL/MariaDB ve doğru `DB_HOST`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` ayarları.
- PHP eklentileri: Ctype, Fileinfo, Filter, Hash, Iconv, Mbstring, OpenSSL, PDO, PDO_MySQL, Session, Tokenizer, DOM, XML ve SimpleXML. Dış servisler için cURL da önerilir.
- `APP_KEY` geçerli bir 32 bayt anahtar olmalı. Mevcut geçerli anahtar değiştirilmemeli. Gönderilen ortam dosyasının anahtar biçimi geçerliydi.
- HTTPS sitede `APP_URL=https://...` kullanılmalı. `SESSION_DRIVER=file` artık gerçekten dikkate alınır; `storage/framework/sessions` yazılabilir olmalı. `cookie` sürücüsü de kullanılabilir. `SESSION_SECURE_COOKIE` ayarı `.env` üzerinden değiştirilebilir; belirtilmezse `APP_URL` protokolüne göre belirlenir.
- `storage` ve `bootstrap/cache` klasörleri PHP kullanıcısı tarafından yazılabilir olmalı. Genel dosyalar 0644, klasörler 0755; yazılabilir çalışma klasörleri için uygun kullanıcı/grup ile 0775 yeterlidir. Geniş 0777 izinleri gerekmez.
- `APP_DEBUG=false` üretimde korunmalı. Kurulum ekranı eksik PHP sürümü, eklenti ve anahtar sorunlarını bildirir.

Kurulum aracının bütün görevleri mevcut veritabanında eksik alanları eklemek, gerekli alan uzunluklarını artırmak, boş/geçersiz yazar bağlantılarını tamamlamak ve önbelleği temizlemektir. Mevcut haberler ve kullanıcı şifreleri silinmez/değiştirilmez. `.env` dosyasına yazılmaz.

## Düzeltilen hatalar

- Orijinal tarayıcı kurulumu `users.sort_order` ve yazar profil alanlarını oluşturmadan başarı bildiriyordu. Bu durumda ana sayfa ve yazarlar sayfası `SQLSTATE[42S22]` ile HTTP 500 veriyordu. Aynı hata yerelde üretildi ve onarım sonrası 200 yanıtı doğrulandı.
- Yazar migration'ı metin alanlarına yanlışlıkla `0` varsayılanı veriyordu. Yeni migration mevcut hatalı/boş slug değerlerini ve profil alanlarını onarır.
- Seeder ile oluşturulan ilk kullanıcının slug alanı boş kalabiliyordu; ilk oluşturma ve seeder akışları düzeltildi.
- Eksik gönderilen isteğe bağlı şifre, slug ve ajans anahtarı alanlarında doğrudan dizi erişimleri kaldırıldı.
- Oturum sürücüsü sabit `cookie` olmaktan çıkarıldı; ortam dosyasındaki ayar kullanılır.
- Robots doğrulaması `index,follow`, `noindex,follow`, `noindex,nofollow` değerlerini kabul eder.
- Uzun medya/profil URL'leri için veritabanı alanları 500 karakterle uyumlu hale getirildi.
- Aynı adlı kategoriler otomatik farklı slug alır; elle girilen çakışan slug doğrulama hatasıyla reddedilir.
- Controller'da bulunmayan yönetim `show` rotaları kaldırıldı.
- Taslak ve ileri tarihli haberlerin genel sitede açılması engellendi.
- Kök `.htaccess` içinde kaynak klasörlerini engelleme kuralı mevcut dosya kısayolundan önceye alındı.

## Arayüz

Sürmanşet kartları, numaralı manşet geçişleri, son dakika şeridi, haber akışı, öne çıkan haberler, yazarlar, gerçek kategorilerine göre spor/ekonomi/teknoloji/magazin bölümleri ve galeri bölümü eklendi. Mobil menü, arama, galeri ve video listeleme çalışır. Gerçek haber resimleri mevcut `image` alanından gelir; eksik resimler için yerel bir görsel kullanılır. Eski sabit örnek piyasa fiyatları kaldırıldı.

Kullanıcının verdiği Demo 6 referansı bulut ağ politikası nedeniyle görüntülenemedi. Tasarım haber portalı düzenine yaklaştırıldı; referans ile birebir görsel karşılaştırma yapılmış değildir. Önizleme resimleri yalnız yerel örnek içerikle çekildi. Örnek haberler/veritabanı ZIP'e dahil değildir.

## Doğrulama

- Tarayıcıyla kurulum/onarım ve migration + seeder kurulum yolları doğrulandı.
- İki kurulum yolu için 11 HTTP işlev testi geçti; panel girişi ve 13 panel ekranı alt kontrollerle doğrulandı.
- İsteğe bağlı alanlar, uzun URL, kategori slug çakışması, haber robots değeri ve yayın görünürlüğü test edildi.
- Blade derleme, yapılandırma önbelleği ve rota önbelleği komutları kontrol edildi.
- Masaüstü 1440 px ve mobil 390 px genişlikte yatay taşma yok; manşet geçişi ve mobil menü çalışıyor, tarayıcı JavaScript hatası yok.
- Gerçek hosting hesabına erişilmedi; sunucu üzerinde dağıtım veya test yapılmadı. Apache/Nginx hosting ayarları yerelde birebir test edilmedi. Dış ajans/AI/sosyal medya API çağrıları test kapsamına alınmadı.

Python 3 ile salt okunur HTTP testleri: `python3 tests/smoke.py`. Test adresi `REFLEX_TEST_BASE_URL` ortam değişkeniyle belirlenir. Panel kontrolleri için test hesabı bilgilerini `REFLEX_TEST_ADMIN_EMAIL` ve `REFLEX_TEST_ADMIN_PASSWORD` ortam değişkenleriyle sağlayın. **Yazma testleri yalnız atılabilir test veritabanında** `REFLEX_TEST_WRITES=1` ile çalıştırılmalıdır; yazar, kategori ve haber kayıtları oluşturur. Üretim veritabanında yazma testlerini çalıştırmayın.
