<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Str;

class User extends Authenticatable
{
    use HasFactory;

    protected $fillable = ['name','email','password','role','active','slug','photo','title','bio','short_bio','phone','website','twitter','facebook','instagram','linkedin','sort_order'];
    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return ['password' => 'hashed', 'active' => 'boolean', 'sort_order' => 'integer'];
    }

    protected static function booted(): void
    {
        static::creating(function (User $user) {
            if (!empty($user->slug)) return;
            $base = substr(Str::slug($user->name) ?: 'yazar', 0, 200);
            $slug = $base;
            $suffix = 2;
            while (static::where('slug', $slug)->exists()) $slug = $base.'-'.$suffix++;
            $user->slug = $slug;
        });
    }

    public function news() { return $this->hasMany(News::class, 'author_id'); }
    public function scopeAuthors($query) { return $query->whereIn('role', ['author', 'editor', 'admin']); }
}
