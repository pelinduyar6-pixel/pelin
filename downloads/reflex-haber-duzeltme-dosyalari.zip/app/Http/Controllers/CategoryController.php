<?php
namespace App\Http\Controllers; use App\Models\Category; class CategoryController {public function show(Category $category){$news=$category->news()->published()->with('category')->latest('published_at')->paginate(20);return view('category.show',compact('category','news'));}}
