<?php
namespace App\Http\Controllers; use App\Models\News; class NewsController { public function show(News $news){abort_unless(News::published()->whereKey($news->id)->exists(),404);$news->increment('views'); return view('news.show',compact('news'));} }
