<?php

namespace App\Http\Controllers\Admin;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class CategoryController
{
    public function index() { return view('admin.categories.index', ['items' => Category::orderBy('sort_order')->get()]); }
    public function store(Request $request) { Category::create($this->data($request)); return back(); }
    public function update(Request $request, Category $category) { $category->update($this->data($request, $category)); return back(); }
    public function destroy(Category $category) { $category->delete(); return back(); }

    private function data(Request $request, ?Category $category = null): array
    {
        $data = $request->validate([
            'name' => 'required|max:100', 'description' => 'nullable|string',
            'slug' => ['nullable','max:120', Rule::unique('categories', 'slug')->ignore($category?->id)],
            'color' => 'nullable|max:20', 'icon' => 'nullable|max:50', 'sort_order' => 'nullable|integer|min:0',
            'seo_title' => 'nullable|max:255', 'seo_description' => 'nullable|max:500',
        ]);
        if (empty($data['slug'])) {
            $base = substr(Str::slug($data['name']) ?: 'kategori', 0, 100);
            $slug = $category?->slug ?: $base;
            $suffix = 2;
            while (Category::where('slug', $slug)->when($category, fn ($q) => $q->where('id', '!=', $category->id))->exists()) $slug = $base.'-'.$suffix++;
            $data['slug'] = $slug;
        }
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);
        $data['active'] = $request->boolean('active');
        $data['show_home'] = $request->boolean('show_home');
        return $data;
    }
}
