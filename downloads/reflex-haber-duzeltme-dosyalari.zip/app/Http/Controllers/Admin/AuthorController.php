<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class AuthorController extends Controller
{
    public function index() { return view('admin.authors.index', ['authors' => User::authors()->orderBy('sort_order')->orderBy('name')->paginate(30)]); }
    public function create() { return view('admin.authors.form', ['item' => new User(['role' => 'author', 'active' => true])]); }

    public function store(Request $request)
    {
        $data = $this->data($request);
        $data['password'] = Hash::make($data['password'] ?? Str::random(32));
        $data['slug'] = $this->uniqueSlug($data['name']);
        User::create($data);
        return redirect()->route('admin.authors.index')->with('ok', 'Yazar oluşturuldu.');
    }
    public function edit(User $author) { return view('admin.authors.form', ['item' => $author]); }

    public function update(Request $request, User $author)
    {
        $data = $this->data($request);
        if (empty($data['password'])) unset($data['password']);
        else $data['password'] = Hash::make($data['password']);
        if (!$author->slug || $author->slug === '0') $data['slug'] = $this->uniqueSlug($data['name'], $author->id);
        $author->update($data);
        return back()->with('ok', 'Yazar güncellendi.');
    }
    public function destroy(User $author)
    {
        if ($author->id === auth()->id()) return back()->with('ok', 'Kendi hesabınızı silemezsiniz.');
        $author->update(['active' => false]);
        return back()->with('ok', 'Yazar pasife alındı.');
    }
    private function data(Request $request): array
    {
        $data = $request->validate([
            'name' => 'required|max:255',
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($request->route('author')?->id)],
            'password' => 'nullable|min:8', 'title' => 'nullable|max:255', 'photo' => 'nullable|max:500',
            'short_bio' => 'nullable', 'bio' => 'nullable', 'website' => 'nullable|max:500',
            'twitter' => 'nullable|max:500', 'facebook' => 'nullable|max:500',
            'instagram' => 'nullable|max:500', 'linkedin' => 'nullable|max:500',
            'role' => 'required|in:author,editor,admin', 'active' => 'nullable', 'sort_order' => 'nullable|integer|min:0',
        ]);
        $data['active'] = $request->boolean('active');
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);
        return $data;
    }
    private function uniqueSlug(string $name, ?int $ignore = null): string
    {
        $base = substr(Str::slug($name) ?: 'yazar', 0, 200);
        $slug = $base;
        $suffix = 2;
        while (User::where('slug', $slug)->when($ignore, fn ($q) => $q->where('id', '!=', $ignore))->exists()) $slug = $base.'-'.$suffix++;
        return $slug;
    }
}
