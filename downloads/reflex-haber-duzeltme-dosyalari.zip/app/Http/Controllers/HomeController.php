<?php

namespace App\Http\Controllers;

use App\Models\{News, Category, User};

class HomeController
{
    public function index()
    {
        $query = News::published()->with('category');
        $latest = (clone $query)->latest('published_at')->take(24)->get();
        $headlines = (clone $query)->where('is_main_headline', true)->latest('published_at')->take(5)->get();
        if ($headlines->isEmpty()) $headlines = $latest->take(5);
        $top = (clone $query)->where('is_top_headline', true)->latest('published_at')->take(4)->get();
        if ($top->isEmpty()) $top = $latest->skip(1)->take(4);
        $featured = (clone $query)->where('is_featured', true)->latest('published_at')->take(6)->get();
        if ($featured->isEmpty()) $featured = $latest->take(6);
        $sections = [];
        foreach (['Spor', 'Ekonomi', 'Teknoloji', 'Magazin'] as $name) {
            $sections[$name] = (clone $query)->whereHas('category', fn ($q) => $q->where('name', $name))->latest('published_at')->take(4)->get();
        }
        return view('home.index', [
            'headlines' => $headlines, 'top' => $top,
            'breaking' => (clone $query)->where('is_breaking', true)->latest('published_at')->take(10)->get(),
            'featured' => $featured, 'latest' => $latest, 'sections' => $sections,
            'categories' => Category::where('active', true)->where('show_home', true)->orderBy('sort_order')->get(),
            'authors' => User::authors()->where('active', true)->orderBy('sort_order')->take(5)->get(),
            'gallery' => (clone $query)->whereNotNull('gallery')->whereJsonLength('gallery', '>', 0)->latest('published_at')->take(6)->get(),
        ]);
    }
}
