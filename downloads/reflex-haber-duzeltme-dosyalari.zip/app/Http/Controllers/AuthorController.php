<?php
namespace App\Http\Controllers;
use App\Models\User;use Illuminate\Http\Request;
class AuthorController extends Controller{
 public function index(){return view('author.index',['authors'=>User::whereIn('role',['author','editor','admin'])->where('active',1)->orderBy('sort_order')->orderBy('name')->paginate(24)]);}
 public function show(User $author){abort_unless($author->active && in_array($author->role,['author','editor','admin']),404);$news=$author->news()->with('category')->published()->latest('published_at')->paginate(12);return view('author.show',compact('author','news'));}
}
