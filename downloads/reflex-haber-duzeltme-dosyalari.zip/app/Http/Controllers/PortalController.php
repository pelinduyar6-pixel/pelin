<?php

namespace App\Http\Controllers;

use App\Models\News;
use Illuminate\Http\Request;

class PortalController extends Controller
{
    public function search(Request $request)
    {
        $data = $request->validate(['q' => 'nullable|string|max:200']);
        $query = trim($data['q'] ?? '');
        $news = News::published()->with('category')
            ->when($query !== '', fn ($q) => $q->where(fn ($q) => $q->where('title', 'like', '%'.$query.'%')->orWhere('spot', 'like', '%'.$query.'%')))
            ->latest('published_at')->paginate(20)->withQueryString();
        return view('listing.index', ['title' => $query ? 'Arama: '.$query : 'Son Haberler', 'news' => $news, 'query' => $query]);
    }

    public function gallery()
    {
        return view('listing.index', ['title' => 'Foto Galeri', 'news' => News::published()->with('category')->whereNotNull('gallery')->whereJsonLength('gallery', '>', 0)->latest('published_at')->paginate(20)]);
    }

    public function video()
    {
        return view('listing.index', ['title' => 'Video Haberler', 'news' => News::published()->with('category')->whereNotNull('video_url')->where('video_url', '!=', '')->latest('published_at')->paginate(20)]);
    }
}
