<?php
/**
 * Reflex Haber - browser-only installer / repair tool.
 * No terminal/SSH required.
 *
 * IMPORTANT: Run once, then delete kurulum.php and public/kurulum.php.
 */
declare(strict_types=1);

$root = __DIR__;
$lock = $root . '/storage/app/installer-v4.lock';
$ok = [];
$errors = [];

function e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }

function readEnvFile(string $path): array {
    $out = [];
    if (!is_file($path)) return $out;
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        $k = trim($k);
        $v = trim($v);
        if ($v !== '' && (($v[0] === '"' && substr($v, -1) === '"') || ($v[0] === "'" && substr($v, -1) === "'"))) {
            $v = substr($v, 1, -1);
        }
        $out[$k] = str_replace('\\"', '"', $v);
    }
    return $out;
}

function ensureDir(string $path, array &$ok, array &$errors): void {
    if (!is_dir($path)) @mkdir($path, 0775, true);
    if (!is_dir($path)) { $errors[] = "Klasör oluşturulamadı: {$path}"; return; }
    @chmod($path, 0775);
    if (is_writable($path)) $ok[] = "Yazılabilir: {$path}"; else $errors[] = "Yazma izni yok: {$path}";
}

function tableExists(PDO $pdo, string $table): bool {
    $s = $pdo->prepare('SHOW TABLES LIKE ?'); $s->execute([$table]); return (bool)$s->fetchColumn();
}

function columns(PDO $pdo, string $table): array {
    $out = [];
    foreach ($pdo->query("SHOW COLUMNS FROM `{$table}`") as $r) $out[strtolower((string)$r['Field'])] = $r;
    return $out;
}

function ensureTable(PDO $pdo, string $table, string $create, array &$ok, array &$errors): void {
    try { $pdo->exec($create); if (tableExists($pdo, $table)) $ok[] = "Tablo hazır: {$table}"; }
    catch (Throwable $e) { $errors[] = "{$table}: {$e->getMessage()}"; }
}

function addColumns(PDO $pdo, string $table, array $defs, array &$ok, array &$errors): void {
    if (!tableExists($pdo, $table)) return;
    $cols = columns($pdo, $table);
    foreach ($defs as $name => $sql) {
        if (isset($cols[strtolower($name)])) continue;
        try { $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN {$sql}"); $ok[] = "{$table}.{$name} eklendi"; }
        catch (Throwable $e) { $errors[] = "{$table}.{$name}: {$e->getMessage()}"; }
    }
}

function indexIfMissing(PDO $pdo, string $table, string $index, string $sql, array &$ok, array &$errors): void {
    if (!tableExists($pdo, $table)) return;
    $has = false;
    foreach ($pdo->query("SHOW INDEX FROM `{$table}`") as $r) if ((string)$r['Key_name'] === $index) { $has = true; break; }
    if ($has) return;
    try { $pdo->exec($sql); $ok[] = "İndeks hazır: {$table}.{$index}"; } catch (Throwable $e) { $errors[] = "İndeks {$table}.{$index}: {$e->getMessage()}"; }
}

if (file_exists($lock)) {
    $errors[] = 'Kurulum/onarım daha önce tamamlanmış. Tekrar çalıştırmak için dosyayı silip yeniden yükleyin.';
}

$env = readEnvFile($root . '/.env');

// Report prerequisites before Laravel's autoloader can turn them into a blank 500.
if (PHP_VERSION_ID < 80300) $errors[] = 'Bu paket PHP 8.3 veya üzerini gerektirir. Hosting panelinde web sitesinin PHP sürümünü yükseltin.';
foreach (['ctype', 'fileinfo', 'filter', 'hash', 'iconv', 'mbstring', 'openssl', 'pdo', 'pdo_mysql', 'session', 'tokenizer', 'dom', 'xml', 'simplexml'] as $extension) {
    if (!extension_loaded($extension)) $errors[] = "Eksik PHP eklentisi: {$extension}. Hosting panelinde etkinleştirin.";
}
if (!is_file($root.'/vendor/autoload.php')) $errors[] = 'vendor/autoload.php bulunamadı. Paketin vendor klasörünü eksiksiz yükleyin.';
if (!is_file($root.'/.env')) $errors[] = '.env bulunamadı. Mevcut sunucu .env dosyanızı proje ana dizinine yerleştirin.';
$appKey = (string) ($env['APP_KEY'] ?? '');
$decodedKey = str_starts_with($appKey, 'base64:') ? base64_decode(substr($appKey, 7), true) : $appKey;
if ($decodedKey === false || strlen($decodedKey) !== 32) $errors[] = 'APP_KEY geçerli bir 32 bayt AES-256 anahtarı olmalı. Mevcut geçerli anahtarı değiştirmeyin; eksikse php artisan key:generate çalıştırın.';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$errors) {
    try {
        $host = $env['DB_HOST'] ?? '127.0.0.1';
        $port = $env['DB_PORT'] ?? '3306';
        $db   = $env['DB_DATABASE'] ?? '';
        $user = $env['DB_USERNAME'] ?? '';
        $pass = $env['DB_PASSWORD'] ?? '';
        if ($db === '' || $user === '') throw new RuntimeException('DB_DATABASE / DB_USERNAME .env içinde bulunamadı.');

        $pdo = new PDO("mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
        $ok[] = "MySQL bağlantısı başarılı: {$db}";

        foreach ([
            $root.'/bootstrap/cache',
            $root.'/storage/app',
            $root.'/storage/app/public',
            $root.'/storage/framework',
            $root.'/storage/framework/cache',
            $root.'/storage/framework/cache/data',
            $root.'/storage/framework/sessions',
            $root.'/storage/framework/views',
            $root.'/storage/logs',
        ] as $d) ensureDir($d, $ok, $errors);

        ensureTable($pdo, 'migrations', "CREATE TABLE IF NOT EXISTS `migrations` (`id` int unsigned NOT NULL AUTO_INCREMENT, `migration` varchar(255) NOT NULL, `batch` int NOT NULL, PRIMARY KEY (`id`), KEY `migrations_migration_index` (`migration`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci", $ok, $errors);
        ensureTable($pdo, 'users', "CREATE TABLE IF NOT EXISTS `users` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, `email` varchar(255) NOT NULL, `password` varchar(255) NOT NULL, `role` varchar(30) NOT NULL DEFAULT 'editor', `active` tinyint(1) NOT NULL DEFAULT 1, `remember_token` varchar(100) DEFAULT NULL, `created_at` timestamp NULL DEFAULT NULL, `updated_at` timestamp NULL DEFAULT NULL, PRIMARY KEY (`id`), UNIQUE KEY `users_email_unique` (`email`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci", $ok, $errors);
        addColumns($pdo,'users',[
            'name'=>"`name` varchar(255) NOT NULL DEFAULT ''",'email'=>"`email` varchar(255) NOT NULL DEFAULT ''",'password'=>"`password` varchar(255) NOT NULL DEFAULT ''",'role'=>"`role` varchar(30) NOT NULL DEFAULT 'editor'",'active'=>"`active` tinyint(1) NOT NULL DEFAULT 1",'remember_token'=>"`remember_token` varchar(100) NULL",'created_at'=>"`created_at` timestamp NULL",'updated_at'=>"`updated_at` timestamp NULL"
        ],$ok,$errors);
        addColumns($pdo,'users',[
            'slug'=>"`slug` varchar(255) NULL", 'photo'=>"`photo` varchar(500) NULL",
            'title'=>"`title` varchar(255) NULL", 'bio'=>"`bio` text NULL", 'short_bio'=>"`short_bio` text NULL",
            'phone'=>"`phone` varchar(255) NULL", 'website'=>"`website` varchar(500) NULL",
            'twitter'=>"`twitter` varchar(500) NULL", 'facebook'=>"`facebook` varchar(500) NULL",
            'instagram'=>"`instagram` varchar(500) NULL", 'linkedin'=>"`linkedin` varchar(500) NULL",
            'sort_order'=>"`sort_order` int unsigned NOT NULL DEFAULT 0"
        ],$ok,$errors);
        foreach (['photo','website','twitter','facebook','instagram','linkedin'] as $column) {
            $definition = columns($pdo, 'users')[$column]['Type'] ?? '';
            if (preg_match('/^varchar\((\d+)\)$/i', $definition, $match) && (int)$match[1] < 500) {
                $pdo->exec("ALTER TABLE `users` MODIFY `{$column}` varchar(500) NULL");
            }
        }

        ensureTable($pdo, 'categories', "CREATE TABLE IF NOT EXISTS `categories` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, `slug` varchar(255) NOT NULL, `description` text NULL, `color` varchar(20) NULL, `icon` varchar(50) NULL, `sort_order` int unsigned NOT NULL DEFAULT 0, `show_home` tinyint(1) NOT NULL DEFAULT 1, `active` tinyint(1) NOT NULL DEFAULT 1, `seo_title` varchar(255) NULL, `seo_description` text NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`), UNIQUE KEY `categories_slug_unique` (`slug`), KEY `categories_active_index` (`active`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        addColumns($pdo,'categories',[
            'name'=>"`name` varchar(255) NOT NULL DEFAULT ''",'slug'=>"`slug` varchar(255) NOT NULL DEFAULT ''",'description'=>"`description` text NULL",'color'=>"`color` varchar(20) NULL",'icon'=>"`icon` varchar(50) NULL",'sort_order'=>"`sort_order` int unsigned NOT NULL DEFAULT 0",'show_home'=>"`show_home` tinyint(1) NOT NULL DEFAULT 1",'active'=>"`active` tinyint(1) NOT NULL DEFAULT 1",'seo_title'=>"`seo_title` varchar(255) NULL",'seo_description'=>"`seo_description` text NULL",'created_at'=>"`created_at` timestamp NULL",'updated_at'=>"`updated_at` timestamp NULL"
        ],$ok,$errors);
        indexIfMissing($pdo,'categories','categories_active_index','ALTER TABLE `categories` ADD INDEX `categories_active_index` (`active`)',$ok,$errors);

        ensureTable($pdo, 'news', "CREATE TABLE IF NOT EXISTS `news` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `category_id` bigint unsigned NULL, `author_id` bigint unsigned NULL, `title` varchar(255) NOT NULL, `subtitle` varchar(255) NULL, `slug` varchar(255) NOT NULL, `spot` text NULL, `body` longtext NOT NULL, `image` varchar(500) NULL, `status` enum('draft','published','scheduled') NOT NULL DEFAULT 'draft', `published_at` timestamp NULL, `views` bigint unsigned NOT NULL DEFAULT 0, `is_breaking` tinyint(1) NOT NULL DEFAULT 0, `is_featured` tinyint(1) NOT NULL DEFAULT 0, `is_main_headline` tinyint(1) NOT NULL DEFAULT 0, `is_top_headline` tinyint(1) NOT NULL DEFAULT 0, `is_surmanset` tinyint(1) NOT NULL DEFAULT 0, `is_box` tinyint(1) NOT NULL DEFAULT 0, `comments_enabled` tinyint(1) NOT NULL DEFAULT 1, `social_share` tinyint(1) NOT NULL DEFAULT 1, `seo_title` varchar(255) NULL, `seo_description` text NULL, `canonical_url` varchar(500) NULL, `source_name` varchar(255) NULL, `source_url` varchar(500) NULL, `location` varchar(255) NULL, `video_url` varchar(500) NULL, `gallery` json NULL, `tags` json NULL, `robots` varchar(50) NOT NULL DEFAULT 'index,follow', `created_at` timestamp NULL, `updated_at` timestamp NULL, `deleted_at` timestamp NULL, PRIMARY KEY (`id`), UNIQUE KEY `news_slug_unique` (`slug`), KEY `news_status_index` (`status`), KEY `news_published_at_index` (`published_at`), KEY `news_is_main_headline_index` (`is_main_headline`), KEY `news_is_top_headline_index` (`is_top_headline`), KEY `news_is_breaking_index` (`is_breaking`), KEY `news_is_featured_index` (`is_featured`), KEY `news_is_surmanset_index` (`is_surmanset`), KEY `news_is_box_index` (`is_box`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        addColumns($pdo,'news',[
            'category_id'=>"`category_id` bigint unsigned NULL",'author_id'=>"`author_id` bigint unsigned NULL",'title'=>"`title` varchar(255) NOT NULL DEFAULT ''",'subtitle'=>"`subtitle` varchar(255) NULL",'slug'=>"`slug` varchar(255) NOT NULL DEFAULT ''",'spot'=>"`spot` text NULL",'body'=>"`body` longtext NOT NULL",'image'=>"`image` varchar(500) NULL",'status'=>"`status` enum('draft','published','scheduled') NOT NULL DEFAULT 'draft'",'published_at'=>"`published_at` timestamp NULL",'views'=>"`views` bigint unsigned NOT NULL DEFAULT 0",'is_breaking'=>"`is_breaking` tinyint(1) NOT NULL DEFAULT 0",'is_featured'=>"`is_featured` tinyint(1) NOT NULL DEFAULT 0",'is_main_headline'=>"`is_main_headline` tinyint(1) NOT NULL DEFAULT 0",'is_top_headline'=>"`is_top_headline` tinyint(1) NOT NULL DEFAULT 0",'is_surmanset'=>"`is_surmanset` tinyint(1) NOT NULL DEFAULT 0",'is_box'=>"`is_box` tinyint(1) NOT NULL DEFAULT 0",'comments_enabled'=>"`comments_enabled` tinyint(1) NOT NULL DEFAULT 1",'social_share'=>"`social_share` tinyint(1) NOT NULL DEFAULT 1",'seo_title'=>"`seo_title` varchar(255) NULL",'seo_description'=>"`seo_description` text NULL",'canonical_url'=>"`canonical_url` varchar(500) NULL",'source_name'=>"`source_name` varchar(255) NULL",'source_url'=>"`source_url` varchar(500) NULL",'location'=>"`location` varchar(255) NULL",'video_url'=>"`video_url` varchar(500) NULL",'gallery'=>"`gallery` json NULL",'tags'=>"`tags` json NULL",'robots'=>"`robots` varchar(50) NOT NULL DEFAULT 'index,follow'",'created_at'=>"`created_at` timestamp NULL",'updated_at'=>"`updated_at` timestamp NULL",'deleted_at'=>"`deleted_at` timestamp NULL"
        ],$ok,$errors);
        foreach ([['news_slug_unique','ALTER TABLE `news` ADD UNIQUE INDEX `news_slug_unique` (`slug`)'],['news_status_index','ALTER TABLE `news` ADD INDEX `news_status_index` (`status`)'],['news_published_at_index','ALTER TABLE `news` ADD INDEX `news_published_at_index` (`published_at`)']] as $ix) indexIfMissing($pdo,'news',$ix[0],$ix[1],$ok,$errors);

        ensureTable($pdo,'settings',"CREATE TABLE IF NOT EXISTS `settings` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `group` varchar(255) NOT NULL DEFAULT 'general', `key` varchar(255) NOT NULL, `value` longtext NULL, `type` varchar(50) NOT NULL DEFAULT 'text', `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`), UNIQUE KEY `settings_key_unique` (`key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        addColumns($pdo,'settings',['group'=>"`group` varchar(255) NOT NULL DEFAULT 'general'",'key'=>"`key` varchar(255) NOT NULL DEFAULT ''",'value'=>"`value` longtext NULL",'type'=>"`type` varchar(50) NOT NULL DEFAULT 'text'",'created_at'=>"`created_at` timestamp NULL",'updated_at'=>"`updated_at` timestamp NULL"],$ok,$errors);
        ensureTable($pdo,'custom_codes',"CREATE TABLE IF NOT EXISTS `custom_codes` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, `location` enum('head','body_start','body_end','css','js') NOT NULL, `scope` enum('all','home','news','category','mobile') NOT NULL DEFAULT 'all', `code` longtext NOT NULL, `priority` int NOT NULL DEFAULT 100, `active` tinyint(1) NOT NULL DEFAULT 1, `description` text NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'pages',"CREATE TABLE IF NOT EXISTS `pages` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `title` varchar(255) NOT NULL, `slug` varchar(255) NOT NULL, `body` longtext NOT NULL, `active` tinyint(1) NOT NULL DEFAULT 1, `seo_title` varchar(255) NULL, `seo_description` text NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`), UNIQUE KEY `pages_slug_unique` (`slug`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'jobs',"CREATE TABLE IF NOT EXISTS `jobs` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `queue` varchar(255) NOT NULL, `payload` longtext NOT NULL, `attempts` tinyint unsigned NOT NULL, `reserved_at` int unsigned NULL, `available_at` int unsigned NOT NULL, `created_at` int unsigned NOT NULL, PRIMARY KEY (`id`), KEY `jobs_queue_index` (`queue`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'advertisements',"CREATE TABLE IF NOT EXISTS `advertisements` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, `type` enum('image','code') NOT NULL DEFAULT 'image', `placement` varchar(255) NOT NULL, `device` enum('all','desktop','mobile') NOT NULL DEFAULT 'all', `image` varchar(500) NULL, `target_url` varchar(500) NULL, `code` longtext NULL, `starts_at` timestamp NULL, `ends_at` timestamp NULL, `priority` int unsigned NOT NULL DEFAULT 10, `active` tinyint(1) NOT NULL DEFAULT 1, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`), KEY `advertisements_placement_index` (`placement`), KEY `advertisements_device_index` (`device`), KEY `advertisements_active_index` (`active`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'agency_connections',"CREATE TABLE IF NOT EXISTS `agency_connections` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `agency` varchar(255) NOT NULL, `label` varchar(255) NOT NULL, `connection_type` enum('rss','xml','api','ftp') NOT NULL DEFAULT 'xml', `endpoint` text NULL, `username` varchar(255) NULL, `secret` text NULL, `options` json NULL, `publish_mode` enum('draft','auto') NOT NULL DEFAULT 'draft', `interval_minutes` int unsigned NOT NULL DEFAULT 30, `max_age_hours` int unsigned NOT NULL DEFAULT 24, `download_images` tinyint(1) NOT NULL DEFAULT 1, `prevent_duplicates` tinyint(1) NOT NULL DEFAULT 1, `active` tinyint(1) NOT NULL DEFAULT 0, `last_run_at` timestamp NULL, `last_status` text NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`), UNIQUE KEY `agency_connections_agency_unique` (`agency`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'agency_logs',"CREATE TABLE IF NOT EXISTS `agency_logs` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `agency_connection_id` bigint unsigned NULL, `level` varchar(30) NOT NULL DEFAULT 'info', `message` text NOT NULL, `context` json NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'bot_sources',"CREATE TABLE IF NOT EXISTS `bot_sources` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `name` varchar(255) NOT NULL, `source_url` text NOT NULL, `source_type` enum('auto','rss','xml','html') NOT NULL DEFAULT 'auto', `category_id` bigint unsigned NULL, `interval_minutes` int unsigned NOT NULL DEFAULT 60, `max_age_hours` int unsigned NOT NULL DEFAULT 24, `publish_mode` enum('draft','auto') NOT NULL DEFAULT 'draft', `ai_rewrite` tinyint(1) NOT NULL DEFAULT 1, `ai_seo` tinyint(1) NOT NULL DEFAULT 1, `download_images` tinyint(1) NOT NULL DEFAULT 1, `prevent_duplicates` tinyint(1) NOT NULL DEFAULT 1, `social_share` tinyint(1) NOT NULL DEFAULT 1, `active` tinyint(1) NOT NULL DEFAULT 1, `last_run_at` timestamp NULL, `next_run_at` timestamp NULL, `last_status` varchar(500) NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'bot_logs',"CREATE TABLE IF NOT EXISTS `bot_logs` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `bot_source_id` bigint unsigned NULL, `level` varchar(30) NOT NULL DEFAULT 'info', `message` text NOT NULL, `context` json NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'ai_settings',"CREATE TABLE IF NOT EXISTS `ai_settings` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `provider` varchar(50) NOT NULL DEFAULT 'openai', `api_key` text NULL, `model` varchar(100) NOT NULL DEFAULT 'gpt-5.6-luna', `rewrite_prompt` text NULL, `rewrite_title` tinyint(1) NOT NULL DEFAULT 1, `rewrite_body` tinyint(1) NOT NULL DEFAULT 1, `create_spot` tinyint(1) NOT NULL DEFAULT 1, `create_seo` tinyint(1) NOT NULL DEFAULT 1, `active` tinyint(1) NOT NULL DEFAULT 0, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'social_accounts',"CREATE TABLE IF NOT EXISTS `social_accounts` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `provider` enum('facebook','x') NOT NULL, `name` varchar(255) NOT NULL, `account_id` varchar(255) NULL, `app_id` varchar(255) NULL, `app_secret` text NULL, `access_token` text NULL, `refresh_token` text NULL, `options` json NULL, `auto_share` tinyint(1) NOT NULL DEFAULT 1, `active` tinyint(1) NOT NULL DEFAULT 0, `last_test_at` timestamp NULL, `last_status` text NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);
        ensureTable($pdo,'social_shares',"CREATE TABLE IF NOT EXISTS `social_shares` (`id` bigint unsigned NOT NULL AUTO_INCREMENT, `news_id` bigint unsigned NOT NULL, `social_account_id` bigint unsigned NOT NULL, `status` varchar(50) NOT NULL DEFAULT 'pending', `remote_id` varchar(255) NULL, `message` text NULL, `shared_at` timestamp NULL, `created_at` timestamp NULL, `updated_at` timestamp NULL, PRIMARY KEY (`id`), UNIQUE KEY `social_shares_news_social_unique` (`news_id`,`social_account_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",$ok,$errors);

        // Repair common missing columns on legacy bot/agency/ads tables.
        addColumns($pdo,'custom_codes',['active'=>"`active` tinyint(1) NOT NULL DEFAULT 1",'description'=>"`description` text NULL"],$ok,$errors);
        addColumns($pdo,'pages',['active'=>"`active` tinyint(1) NOT NULL DEFAULT 1",'seo_title'=>"`seo_title` varchar(255) NULL",'seo_description'=>"`seo_description` text NULL"],$ok,$errors);
        addColumns($pdo,'advertisements',['active'=>"`active` tinyint(1) NOT NULL DEFAULT 1",'starts_at'=>"`starts_at` timestamp NULL",'ends_at'=>"`ends_at` timestamp NULL",'device'=>"`device` enum('all','desktop','mobile') NOT NULL DEFAULT 'all'"],$ok,$errors);
        addColumns($pdo,'agency_connections',['download_images'=>"`download_images` tinyint(1) NOT NULL DEFAULT 1",'prevent_duplicates'=>"`prevent_duplicates` tinyint(1) NOT NULL DEFAULT 1",'last_run_at'=>"`last_run_at` timestamp NULL",'last_status'=>"`last_status` text NULL"],$ok,$errors);
        addColumns($pdo,'bot_sources',['next_run_at'=>"`next_run_at` timestamp NULL",'last_status'=>"`last_status` varchar(500) NULL"],$ok,$errors);
        addColumns($pdo,'social_accounts',['last_test_at'=>"`last_test_at` timestamp NULL",'last_status'=>"`last_status` text NULL"],$ok,$errors);

        foreach (['image','video_url','source_url','canonical_url'] as $column) {
            $definition = columns($pdo, 'news')[$column]['Type'] ?? '';
            if (preg_match('/^varchar\((\d+)\)$/i', $definition, $match) && (int)$match[1] < 500) {
                $pdo->exec("ALTER TABLE `news` MODIFY `{$column}` varchar(500) NULL");
            }
        }

        // Seed defaults only when absent; never erase existing content.
        $adminEmail = trim($env['NEWS_ADMIN_EMAIL'] ?? '');
        $adminPass  = (string)($env['NEWS_ADMIN_PASSWORD'] ?? '');
        if ($adminEmail !== '' && $adminPass !== '' && strlen($adminPass) >= 10) {
            $s = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1'); $s->execute([$adminEmail]);
            if (!$s->fetchColumn()) {
                $ins = $pdo->prepare('INSERT INTO users (name,email,password,role,active,created_at,updated_at) VALUES (?,?,?,?,?,?,?)');
                $now = date('Y-m-d H:i:s'); $ins->execute(['Reflex Admin',$adminEmail,password_hash($adminPass,PASSWORD_BCRYPT), 'admin',1,$now,$now]);
                $ok[] = 'Admin kullanıcı oluşturuldu';
            } else $ok[] = 'Admin kullanıcı zaten mevcut';
        }
        $cats = ['Gündem','Türkiye','Dünya','Ekonomi','Spor','Magazin','Teknoloji','Sağlık','Yerel','Yaşam','Kültür-Sanat'];
        $s = $pdo->prepare('SELECT id FROM categories WHERE slug = ? LIMIT 1');
        $ins = $pdo->prepare('INSERT INTO categories (name,slug,sort_order,show_home,active,created_at,updated_at) VALUES (?,?,?,?,?,?,?)');
        foreach ($cats as $i=>$name) { $slug = strtolower(preg_replace('/[^a-z0-9]+/i','-', iconv('UTF-8','ASCII//TRANSLIT',$name) ?: $name)); $slug = trim($slug,'-'); $s->execute([$slug]); if (!$s->fetchColumn()) $ins->execute([$name,$slug,$i+1,1,1,date('Y-m-d H:i:s'),date('Y-m-d H:i:s')]); }

        // The homepage builds author URLs, including the initial admin's URL.
        $authors = $pdo->query("SELECT id,name FROM users WHERE slug IS NULL OR TRIM(slug) = '' OR slug = '0'")->fetchAll();
        $saveSlug = $pdo->prepare('UPDATE users SET slug = ? WHERE id = ?');
        $slugExists = $pdo->prepare('SELECT id FROM users WHERE slug = ? AND id <> ? LIMIT 1');
        foreach ($authors as $author) {
            $name = strtr($author['name'], ['ı'=>'i','İ'=>'I','ş'=>'s','Ş'=>'S','ğ'=>'g','Ğ'=>'G','ü'=>'u','Ü'=>'U','ö'=>'o','Ö'=>'O','ç'=>'c','Ç'=>'C']);
            $name = iconv('UTF-8', 'ASCII//TRANSLIT', $name) ?: $name;
            $base = substr(trim(strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name)), '-'), 0, 200) ?: 'yazar';
            $slug = $base.'-'.$author['id'];
            $suffix = 2;
            while (true) {
                $slugExists->execute([$slug, $author['id']]);
                if (!$slugExists->fetchColumn()) break;
                $slug = $base.'-'.$author['id'].'-'.$suffix++;
            }
            $saveSlug->execute([$slug, $author['id']]);
        }
        $pdo->exec('UPDATE users SET sort_order = 0 WHERE sort_order IS NULL');
        $ok[] = 'Yazar profili alanları ve bağlantıları hazır';

        $migrations = [
            '2026_10_06_000001_create_users_table',
            '2026_10_06_000002_create_categories_table',
            '2026_10_06_000003_create_news_table',
            '2026_10_06_000004_create_settings_custom_codes_pages_jobs',
            '2026_10_06_000005_create_ads_agencies_and_expand_news',
            '2026_10_06_000006_create_bot_ai_social_tables',
            '2026_10_07_000001_repair_categories_schema',
            '2026_10_07_000007_repair_legacy_news_schema',
            '2026_10_08_000001_expand_users_for_authors',
            '2026_10_08_000002_repair_author_profiles',
            '2026_10_08_000003_expand_news_media_urls',
        ];
        $lastBatch = (int)($pdo->query('SELECT COALESCE(MAX(batch),0) FROM migrations')->fetchColumn() ?: 0);
        $mi = $pdo->prepare('SELECT id FROM migrations WHERE migration = ? LIMIT 1');
        $mx = $pdo->prepare('INSERT INTO migrations (migration,batch) VALUES (?,?)');
        if (!$errors) foreach ($migrations as $m) { $mi->execute([$m]); if (!$mi->fetchColumn()) $mx->execute([$m, max(1,$lastBatch)]); }
        $ok[] = 'Migration işaretleri senkronlandı';

        // Clear Laravel's compiled caches without invoking artisan.
        $cacheFiles = glob($root.'/bootstrap/cache/*.php') ?: [];
        foreach ($cacheFiles as $f) @unlink($f);
        foreach (glob($root.'/storage/framework/views/*.php') ?: [] as $f) @unlink($f);
        $ok[] = 'Laravel bootstrap cache temizlendi';

        // Create public/storage link when supported.
        $publicStorage = $root.'/public/storage'; $target = $root.'/storage/app/public';
        if (!file_exists($publicStorage)) { @symlink($target,$publicStorage); if (is_link($publicStorage)) $ok[]='public/storage bağlantısı oluşturuldu'; }

        if (!$errors) { @mkdir(dirname($lock),0775,true); @file_put_contents($lock,date('c')); }
    } catch (Throwable $e) { $errors[] = $e->getMessage(); }
}
?><!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reflex Haber Kurulum / Onarım</title>
<style>body{margin:0;background:#081423;font:15px Arial;color:#15202b}.box{max-width:900px;margin:38px auto;background:#fff;border-radius:16px;padding:30px;box-shadow:0 15px 45px rgba(0,0,0,.25)}h1{margin-top:0;color:#d91427}.note{background:#fff4cc;padding:14px;border-radius:10px}.ok{background:#e5faed;padding:14px;border-radius:10px;margin:10px 0}.err{background:#ffe4e4;color:#8a0000;padding:14px;border-radius:10px;margin:10px 0}.btn{background:#d91427;color:#fff;border:0;border-radius:8px;padding:13px 20px;font-weight:700;cursor:pointer}code{background:#eef1f4;padding:2px 5px;border-radius:4px}li{margin:5px 0}</style></head>
<body><div class="box"><h1>REFLEX HABER</h1><h2>Kurulum / Veritabanı Onarımı</h2>
<div class="note">Bu ekran terminal gerektirmez. Mevcut verileri silmez; eksik Laravel tablolarını/alanlarını tamamlar, cache klasörlerini hazırlar ve mevcut <code>.env</code> ayarlarını değiştirmez.</div>
<?php if($errors):?><div class="err"><b>Hata:</b><ul><?php foreach($errors as $x):?><li><?=e($x)?></li><?php endforeach;?></ul></div><?php endif;?>
<?php if($_SERVER['REQUEST_METHOD']==='POST' && !$errors):?><div class="ok"><b>Onarım tamamlandı.</b> Siteyi şimdi ana sayfadan açabilirsiniz.</div><ul><?php foreach(array_unique($ok) as $x):?><li><?=e($x)?></li><?php endforeach;?></ul><p><b>Güvenlik:</b> Şimdi <code>kurulum.php</code> ve <code>public/kurulum.php</code> dosyalarını sunucudan silin.</p>
<?php elseif(!$errors):?><p>Devam etmek için aşağıdaki düğmeye basın.</p><form method="post"><button class="btn">Sistemi Kur / Onar</button></form><?php endif;?></div></body></html>
