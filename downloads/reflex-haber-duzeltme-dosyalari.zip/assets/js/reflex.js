document.addEventListener('DOMContentLoaded', () => {
    const menu = document.querySelector('[data-menu-toggle]');
    const navigation = document.querySelector('#main-navigation');
    if (menu && navigation) {
        menu.addEventListener('click', () => {
            const expanded = menu.getAttribute('aria-expanded') !== 'true';
            menu.setAttribute('aria-expanded', String(expanded));
            navigation.classList.toggle('mobile-open', expanded);
        });
    }
    const slider = document.querySelector('[data-headline-slider]');
    if (!slider) return;
    const slides = Array.from(slider.querySelectorAll('[data-slide]'));
    const dots = Array.from(slider.querySelectorAll('[data-slide-to]'));
    let selected = 0;
    const show = (index) => {
        selected = (index + slides.length) % slides.length;
        slides.forEach((slide, i) => { slide.hidden = i !== selected; });
        dots.forEach((dot, i) => { dot.setAttribute('aria-pressed', String(i === selected)); });
    };
    dots.forEach((dot) => dot.addEventListener('click', () => show(Number(dot.dataset.slideTo))));
    slider.querySelector('[data-slide-prev]')?.addEventListener('click', () => show(selected - 1));
    slider.querySelector('[data-slide-next]')?.addEventListener('click', () => show(selected + 1));
    slider.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowLeft') { event.preventDefault(); show(selected - 1); }
        if (event.key === 'ArrowRight') { event.preventDefault(); show(selected + 1); }
    });
});
