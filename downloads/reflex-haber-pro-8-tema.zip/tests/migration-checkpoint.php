<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit(1);
$root=realpath(__DIR__.'/..');
if(!in_array($root,['/workspace/reflex-v343-migration-test','/workspace/reflex-v342-panel-test'],true))exit(1);
require $root.'/app/core.php';require $root.'/app/pro.php';
function checkpoint_check(bool $ok,string $label):void {if(!$ok)throw new RuntimeException($label);echo 'PASS '.$label.PHP_EOL;}
$id=bin2hex(random_bytes(16));$dir=migration_dir($id);mkdir($dir,0700);
$source="CREATE TABLE old_news (`id` INT,`title` TEXT,`body` TEXT); INSERT INTO old_news VALUES ";
for($i=0;$i<1105;$i++)$source.=($i?',':'')."(".$i.",'Başlık ".$i."','<p>".str_repeat('Türkçe içerik ', $i===0?500:($i%9+1))."</p>')";
$source.=';';file_put_contents($dir.'/source.sql',$source);
$job=['id'=>$id,'owner'=>1,'created_at'=>date('Y-m-d H:i:s'),'filename'=>'checkpoint.sql','hash'=>hash('sha256',$source),'tables'=>[],'stage'=>'analyzing','mapping'=>[],'images'=>[],'cursor'=>0,'parse_offset'=>0,'imported'=>0,'duplicates'=>0,'skipped'=>0,'missing_images'=>0];migration_store($job);
try {
    $job=migration_analyze($job);checkpoint_check($job['stage']==='analyzing','Large INSERT spans analysis requests');
    $table=$job['tables']['old_news'];clearstatcache(true,$dir.'/'.$table['file']);
    checkpoint_check($table['bytes']===filesize($dir.'/'.$table['file']),'Checkpoint stores absolute JSONL end, including previously appended records');
    // A failed request may append data without committing its checkpoint.
    file_put_contents($dir.'/'.$table['file'],"uncommitted tail",FILE_APPEND);
    do {$job=migration_analyze($job);}while($job['stage']==='analyzing');
    $rows=iterator_to_array(migration_rows($job,'old_news'));
    checkpoint_check(count($rows)===1105,'Resumed analysis preserves every source row without truncation or duplication');
    checkpoint_check($rows[0]['body']==='<p>'.str_repeat('Türkçe içerik ',500).'</p>'&&$rows[1104]['title']==='Başlık 1104','Long Unicode first row and final row round trip exactly');
    // Reproduce the production JSON error with an old truncated preview cache.
    file_put_contents($dir.'/'.$table['file'],"{\"body\":\"cut first row\n{\"id\":\"1000\"}\n");
    try {iterator_to_array(migration_rows($job,'old_news'));checkpoint_check(false,'Corrupt preview must reproduce JSON control-character failure');}
    catch(JsonException $error){checkpoint_check($error->getCode()===JSON_ERROR_CTRL_CHAR,'Legacy truncated cache reproduces production JsonException code 3');}
    $job['stage']='preview';unset($job['cache_format']);$job['mapping']=['news_table'=>'old_news','title'=>'title','body'=>'body'];
    $job['images']=['uploads/cover.jpg'=>'uploads/migration/'.$id.'/cover.jpg'];$job['targets']=['7'=>'3'];
    $preserved=array_intersect_key($job,array_flip(['hash','mapping','images','targets','cursor','imported','duplicates','skipped','missing_images']));
    $job=migration_prepare_cache($job);checkpoint_check($job['stage']==='analyzing'&&$job['resume_stage']==='preview','Existing preview is reindexed from retained SQL without another upload');
    do {$job=migration_analyze($job);}while($job['stage']==='analyzing');
    checkpoint_check($job['stage']==='preview'&&count(iterator_to_array(migration_rows($job,'old_news')))===1105,'Reindex restores a readable preview and every original row');
    checkpoint_check(array_intersect_key($job,$preserved)===$preserved,'Media, mapping, category targets and import receipts survive cache repair');
    $job['stage']='importing';$job['cursor']=8;$job['imported']=8;$job['category_map']=['7'=>3];$job['byte_offset']=123;unset($job['cache_format']);
    $job=migration_prepare_cache($job);do {$job=migration_analyze($job);}while($job['stage']==='analyzing');
    checkpoint_check($job['stage']==='importing'&&$job['cursor']===8&&$job['imported']===8&&$job['category_map']===['7'=>3]&&$job['byte_offset']===0,'Interrupted import resumes its cursor and category receipts with a rebuilt byte index');
    checkpoint_check(migration_prepare_cache($job)===$job,'Current-format jobs do not reindex repeatedly');
} finally {foreach(glob($dir.'/*')?:[] as $file)if(is_file($file))unlink($file);rmdir($dir);}
