"""Reproduce a cached incomplete 3.4.1 loader, then apply the real 3.4.3 ZIP."""
from pathlib import Path
from zipfile import ZipFile
import sqlite3,hashlib
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
assert BASE in ['http://127.0.0.1:8187','http://127.0.0.1:8188']
root=Path('/workspace/reflex-v342-opcache-test');assert root.is_dir()
archive=Path('/workspace/outputs/reflex-haber-pro-3-4-2-tam-guncelleme.zip')
def state():
    with sqlite3.connect(root/'storage/site.sqlite') as db:
        db.row_factory=sqlite3.Row
        return {table:[dict(row) for row in db.execute('SELECT * FROM rh6_'+table+(' WHERE name!=\'app_schema\'' if table=='settings' else '')+' ORDER BY id')] for table in ['news','users','categories','news_sources','ads','settings']}
private=root/'storage/site.php';private_hash=hashlib.sha256(private.read_bytes()).hexdigest()
before=state();form=get('/panel/giris')
status,body,_=request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(form))
check(status==500,'Cached incomplete loader reproduces authenticated panel failure')
entry=json.loads((root/'storage/logs/app.log').read_text().splitlines()[-1])
check(entry['type']=='Error' and entry['line']==19 and entry.get('function')=='social_admin_dispatch','Error matches supplied log line and missing function')
sentinel=root/'cache-sentinel.php';assert not sentinel.exists()
sentinel.write_text("<?php echo 'sentinel-cached-before';")
check(request('cache-sentinel.php')[1]=='sentinel-cached-before','Separate non-package script is cached')
try:
    sentinel.write_text("<?php echo 'sentinel-changed-on-disk';")
    with ZipFile(archive) as z:z.extractall(root)
    check("PRO_VERSION='3.4.3'" in (root/'app/pro.php').read_text(),'Actual update ZIP installs new disk source')
    status,body,_=request(route('/panel'))
    check(status==500,'Disabling OPcache timestamp checks retains failure after full ZIP extraction')
    report=request('reflex-panel-kurtarma-343.php')[1]
    check('Diskteki 3.4.3 dosyaları eksiksiz' in report and 'OPcache dosya değişikliklerini otomatik denetlemiyor' in report,'Fresh recovery script identifies correct disk files and stale-cache setting')
    token=csrf(report)
    guest=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    check(request('reflex-panel-kurtarma-343.php',{'csrf':token},opener=guest)[0]==403,'Anonymous cache refresh denied')
    check(request('reflex-panel-kurtarma-343.php',{'csrf':'invalid'})[0]==403,'Invalid CSRF cache refresh denied')
    stylesheet=root/'assets/v6/edition-admin.css';saved=stylesheet.read_bytes()
    try:
        stylesheet.write_bytes(b'/* incomplete deployment */')
        check(request('reflex-panel-kurtarma-343.php',{'csrf':token})[0]==422,'Incomplete deployment cannot invalidate live PHP code')
    finally:stylesheet.write_bytes(saved)
    status,body,_=request('reflex-panel-kurtarma-343.php',{'csrf':token})
    check(status==200 and re.search(r'Bu sitenin [1-9]\d* PHP dosyası için önbellek yenilendi',body),'Authenticated site-only OPcache refresh actually invalidates cached PHP')
    check(request('cache-sentinel.php')[1]=='sentinel-cached-before','Non-package cached script remains untouched')
    check('admin-sidebar' in get('/panel'),'Previously failing panel opens after targeted refresh')
    check('name="reflex-version" content="3.4.3"' in get('/'),'Running application, not only disk source, now reports 3.4.3')
    for path in ['/panel/haberler','/panel/tema','/panel/sosyal-medya','/panel/canli-veri','/panel/sistem-kontrolu']:
        check('admin-sidebar' in get(path),'Post-refresh module opens '+path)
    check(state()==before,'All content/accounts/passwords/category and source IDs/manual settings preserved')
    check(hashlib.sha256(private.read_bytes()).hexdigest()==private_hash,'Private hosting configuration remains byte-for-byte unchanged')
    (root/'reflex-panel-kurtarma-343.php').unlink()
    check('Güncelleme dosyaları eksiksiz' in get('/panel/sistem-kontrolu'),'Optional recovery tool can be removed without breaking runtime audit')
finally:sentinel.unlink(missing_ok=True)
