"""Exercise missing-table/column recovery and safe diagnostics on named localhost fixtures."""
from pathlib import Path
import subprocess
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
assert urllib.parse.urlsplit(BASE).hostname in ['127.0.0.1','localhost']
root=Path(sys.argv[3]).resolve()
assert root.name in ['reflex-v342-panel-test','reflex-v342-fresh-mysql']
def probe(action,**kwargs):
    r=subprocess.run(['/workspace/reflex-tools/php',str(root/'tests/panel-probe.php'),str(root)],input=json.dumps({'action':action,**kwargs}),text=True,capture_output=True,check=True)
    return json.loads(r.stdout)
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
check('admin-sidebar' in get('/panel'),'Authenticated dashboard opens')
before=probe('state');check(before['schema']=='3.4.3','Faults run with the current version marker')
for table in ['live_visitors','live_views','daily_stats','contacts']:
    indices=probe('fault',table=table)
    try:
        status,body,_=request(route('/panel'))
        check(status==200 and 'admin-sidebar' in body and 'İşlem tamamlanamadı. Lütfen tekrar deneyin.' not in body,'Current marker still repairs missing '+table)
        check(probe('missing')==[],'Complete schema after '+table+' repair')
    finally:probe('restore',table=table,indices=indices)
probe('column-fault')
try:
    status,body,_=request(route('/panel'))
    check(status==200 and probe('missing')==[],'Missing update column is repaired with current marker')
finally:probe('column-restore')
check(probe('state')==before,'News, accounts, passwords, category IDs, source IDs and settings preserved')
indices=probe('fault',table='news')
try:
    status,body,_=request(route('/panel'))
    check(status==503 and 'Hata kodu:' in body,'Missing core news table is not recreated as an empty archive')
    reference=re.search(r'Hata kodu: ([a-f0-9]{12})',body)[1]
    entry=next(json.loads(line) for line in reversed((root/'storage/logs/app.log').read_text().splitlines()) if '"reference":"'+reference+'"' in line)
    check(entry['cause']=='missing_table' and entry['table']=='rh6_news' and entry['trace'],'Public error code matches safe internal table/stack diagnosis')
    check('SQLSTATE' not in body and 'rh6_news' not in body,'Public error hides database internals')
finally:probe('restore',table='news',indices=indices)
reference=probe('log')['reference'];line=next(line for line in (root/'storage/logs/app.log').read_text().splitlines() if '"reference":"'+reference+'"' in line)
check(all(secret not in line for secret in ['DO_NOT_LOG_PASSWORD','DO_NOT_LOG_API_KEY','visitor@example.invalid','private.invalid','DO_NOT_LOG_TOKEN']),'Diagnostic logs omit credentials, API keys, email, URLs and raw exception text')
logs=root/'storage/logs';saved_logs=root/'storage/panel-probe-saved-logs';logs.rename(saved_logs)
try:
    logs.write_text('Fixture blocking directory creation')
    r=subprocess.run(['/workspace/reflex-tools/php','-d','error_log=/dev/stderr',str(root/'tests/panel-probe.php'),str(root)],input=json.dumps({'action':'log'}),text=True,capture_output=True,check=True)
    records=[json.loads(line[line.index('{'):]) for line in r.stderr.splitlines() if '{"time"' in line]
    check(len(records)==1 and records[0]['reference']==json.loads(r.stdout)['reference'],'Unwritable application log falls back to PHP error_log with matching reference')
finally:
    logs.unlink();saved_logs.rename(logs)
template=root/'views/admin/dashboard.php';saved=template.read_bytes()
try:
    template.unlink();status,body,_=request(route('/panel'))
    check(status==500 and re.search(r'Hata kodu: <strong>[a-f0-9]{12}</strong>',body),'Unexpected panel rendering failure has a trackable error code')
    reference=re.search(r'Hata kodu: <strong>([a-f0-9]{12})</strong>',body)[1]
    entry=next(json.loads(line) for line in reversed((root/'storage/logs/app.log').read_text().splitlines()) if '"reference":"'+reference+'"' in line)
    check(entry.get('missing_file')=='views/admin/dashboard.php','Incomplete upload identifies the exact missing application template')
finally:template.write_bytes(saved)
for route_name in ['/panel','/panel/haberler','/panel/haberler/yeni','/panel/tema','/panel/tasima','/panel/botlar','/panel/api-merkezi','/panel/canli-veri','/panel/sosyal-medya','/panel/sistem-kontrolu']:
    check('admin-sidebar' in get(route_name),'Recovered panel opens '+route_name)
check(probe('state')==before,'Fault tests restore all existing content and settings')
