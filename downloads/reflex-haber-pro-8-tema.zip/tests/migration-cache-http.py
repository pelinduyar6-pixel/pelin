"""Production JSONL checkpoint recovery through real chunk/preview/import HTTP."""
from pathlib import Path
exec(Path(__file__).with_name('migration-chunks-http.py').read_text().split('with tempfile.TemporaryDirectory')[0])
import subprocess,io
root=Path(sys.argv[3]).resolve()
assert str(root) in ['/workspace/reflex-v343-migration-test','/workspace/reflex-v343-migration-mysql']
def probe(job,action='state'):
    p=subprocess.run(['/workspace/reflex-tools/php',str(root/'tests/migration-cache-probe.php'),str(root)],input=json.dumps({'job':job,'action':action}),text=True,capture_output=True,check=True)
    return json.loads(p.stdout)
with tempfile.TemporaryDirectory(prefix='reflex-cache-http-') as temp:
    sql=Path(temp)/'checkpoint.sql';suffix=uuid.uuid4().hex
    rows=[]
    for i in range(1105):
        body=('<p>'+('Türkçe içerik '*500 if i==0 else 'Haber içeriği')+'</p>') if i<18 else ''
        rows.append(f"({i},'Kurtarma {suffix} {i}','{body}',712001,'uploads/cover.jpg')")
    sql.write_text("CREATE TABLE old_categories (`id` INT,`name` TEXT,`slug` TEXT); INSERT INTO old_categories VALUES (712001,'Kurtarma kategori','kurtarma-"+suffix+"'); CREATE TABLE old_news (`id` INT,`title` TEXT,`body` TEXT,`category_id` INT,`image` TEXT); INSERT INTO old_news VALUES "+','.join(rows)+';',encoding='utf-8')
    t,_=transfer(sql,'sql');job=t['job'];loops=0
    while True:
        status,result=post('incele',{'job':job});assert status==200,result;loops+=1
        if result['done']:break
    check(loops>1 and result['records']==1106,'Real chunk upload analyzes a varying-length INSERT across checkpoints')
    page=request(route('/panel/tasima',job=job))[1]
    mapping={'news_table':'old_news','category_table':'old_categories','id':'id','title':'title','body':'body','image':'image','category_id':'category_id','category_legacy_id':'id','category_name':'name','category_slug':'slug'}
    status,page,_=request(route('/panel/tasima/eslestir',job=job),{'map['+k+']':v for k,v in mapping.items()},csrf(page));assert status==200
    photo=(Path(__file__).parents[1]/'assets/v6/demo/bogaz-5-2-400x225.jpg').read_bytes()
    z=io.BytesIO()
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:archive.writestr('uploads/cover.jpg',photo)
    status,page,_=request(route('/panel/tasima/gorseller',job=job),{},csrf(page),file=('image_zip','cover.zip',z.getvalue()));assert status==200
    before=probe(job,'corrupt');status,page,_=request(route('/panel/tasima',job=job))
    check(status==200 and 'SQL incelemesine devam et' in page,'Existing broken preview opens its recovery step instead of a 500 error')
    while True:
        status,result=post('incele',{'job':job});assert status==200,result
        if result['done']:break
    after=probe(job)
    check(before==after,'Repair preserves mapping, source hash, images, category targets and draft counters')
    page=request(route('/panel/tasima',job=job))[1]
    check('Haber önizlemesi' in page and 'uploads/migration/' in page,'Existing SQL and separately uploaded cover return to preview without re-upload')
    status,page,_=request(route('/panel/tasima/baslat',job=job),{'reviewed':'1'},csrf(page));assert status==200
    status,page,_=request(route('/panel/tasima/devam',job=job),{},csrf(page));assert status==200
    before=probe(job,'corrupt');check(before['imported']==18 and before['cursor']==100,'First real batch creates 18 drafts and skips blank content')
    status,page,_=request(route('/panel/tasima',job=job));assert status==200
    while True:
        status,result=post('incele',{'job':job});assert status==200,result
        if result['done']:break
    check(probe(job)==before,'Already-imported drafts and category receipts survive cache recovery during import')
    while probe(job)['stage']=='importing':
        page=request(route('/panel/tasima',job=job))[1];status,page,_=request(route('/panel/tasima/devam',job=job),{},csrf(page));assert status==200
    result=probe(job)
    check(result['drafts']==18 and result['imported']==18 and result['cursor']==1105 and result['duplicates']==0,'Recovered import finishes without duplicate news or implicit publishing')
print('Migration cache HTTP checks completed:',DRIVER)
