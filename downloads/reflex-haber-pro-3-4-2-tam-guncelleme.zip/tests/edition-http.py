"""Pro 3.3 URL scheduling, shared settings and article advertising; localhost only."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
import time
assert urllib.parse.urlsplit(BASE).hostname in ['127.0.0.1','localhost']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
def post(path,data,query=None):
    form=request(route(path,**(query or {})))[1]
    return request(route(path,**(query or {})),data,csrf(form))
home=get('/');check('Türkiye Gündemi' in home and 'En çok okunanlar' in home,'Main agenda and popular sidebar render published stories')
form=get('/panel/botlar');check('Genel ayarlar' in form and 'name="daily_time"' in form and 'cron-frequency' in form,'Bot exposes editable URLs, daily hour and cron setup')
status,body,_=post('/panel/botlar/ayarlar',{'ai_model':'gpt-5.6-luna','ai_target_words':'700','bot_enabled':'1','bot_ai_enabled':'1'})
check(status==200 and 'Bot ve ortak AI ayarları kaydedildi' in body,'Bot settings save the shared GPT-5.6 model')
for screen in ['api-merkezi','ai','ai-yazar']:
    check('gpt-5.6-luna' in get('/panel/'+screen),'Shared model visible in '+screen)
check(request(route('/panel/botlar/ayarlar'),{'ai_model':'gpt-5.6-sol'},'invalid')[0]==419,'Bot global settings require CSRF')
prefix='EditionSource'+str(time.time_ns());source={'name':prefix,'feed_url':'https://93.184.216.34/rss','source_kind':'rss','interval_minutes':'60','max_items':'2','import_status':'draft','active':'1','schedule_mode':'daily','daily_time':'11:30'}
status,body,_=post('/panel/botlar/duzenle',source);check(status==200 and prefix in body and 'Her gün 11:30' in body,'User URL and recurring daily clock are saved')
row=next(m.group(1) for m in re.finditer(r'<tr[^>]*>(.*?)</tr>',body,re.S) if prefix in m.group(1));sid=re.search(r'(?:id=|id%3D)(\d+)',row).group(1)
edit=request(route('/panel/botlar',id=sid))[1];check('value="11:30"' in edit and 'value="daily" selected' in edit,'Source edit restores daily schedule')
status,body,_=post('/panel/botlar/duzenle',{**source,'daily_time':'29:00'},{'id':sid});check(status==422,'Invalid daily clock cannot be saved')
request(route('/panel/botlar/sil',id=sid),{},csrf(edit));check(prefix not in get('/panel/botlar'),'Source fixture removed after scheduling verification')
adform=get('/panel/reklamlar/yeni');check(all('value="'+slot+'"' in adform for slot in ['article_inline','article_sidebar_top','article_sidebar_mid','article_sidebar_bottom']),'Advert editor offers text and three detail sidebar positions')
adname='EditionAd'+str(time.time_ns());ad={'name':adname,'code':'<div class="edition-ad-test">Acceptance advert</div>','placement':'article_inline','device':'all','priority':'1','active':'1'}
status,body,_=post('/panel/reklamlar/yeni',ad);check(status==200 and adname in body,'Inline advertising placement can be saved')
row=next(m.group(1) for m in re.finditer(r'<tr[^>]*>(.*?)</tr>',body,re.S) if adname in m.group(1));aid=re.search(r'(?:id=|id%3D)(\d+)',row).group(1)
slug='edition-article-'+str(time.time_ns());news={'title':'Haber içi reklam ve detay sütunu kabul testi','slug':slug,'body':'<p>Birinci paragraf.</p><p>İkinci paragraf.</p><p>Üçüncü paragraf.</p><p>Dördüncü paragraf.</p>','kind':'article','status':'published','seo_autofill':'1'}
status,body,_=post('/panel/haberler/yeni',news);check(status==200,'Article advert fixture published')
row=next(m.group(1) for m in re.finditer(r'<tr[^>]*>(.*?)</tr>',body,re.S) if news['title'] in m.group(1));nid=re.search(r'name="selected\[\]" value="(\d+)"',row).group(1)
article=get('/haber/'+slug);body_text=article[article.index('id="article-text"'):article.index('<section class="article-reactions"')];check(body_text.count('edition-ad-test')==1 and body_text.index('Üçüncü paragraf')<body_text.index('edition-ad-test')<body_text.index('Dördüncü paragraf'),'Saved advert renders inside article between intact paragraphs')
check('article-recent' in article and 'popular-sidebar' in article and 'class="article-image"' not in article,'Detail sidebar is rich and missing cover does not create a large blank image')
check('data-share-url=' in get('/panel/haberler') and 'data-share-title=' in get('/panel/haberler'),'Published record supplies actual share URL and title')
request(route('/panel/haberler/sil',id=nid),{},csrf(get('/panel/haberler')));request(route('/panel/reklamlar/sil',id=aid),{},csrf(get('/panel/reklamlar')))
post('/panel/botlar/ayarlar',{'ai_model':'gpt-5.6-sol','ai_target_words':'700','bot_enabled':'1'})
check(request('cron.php?token=invalid')[0]==403,'Cron rejects invalid secret token without fetching sources')
print('Edition HTTP checks completed on',DRIVER)
