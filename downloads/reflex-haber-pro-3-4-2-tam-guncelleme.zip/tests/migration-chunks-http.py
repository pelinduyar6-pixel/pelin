"""Chunk transfers with 2 MB POST/file and 64 MB PHP memory; disposable localhost."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
import tempfile,zipfile,uuid,hashlib,struct,time
assert urllib.parse.urlsplit(BASE).hostname in ['localhost','127.0.0.1']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login));token=csrf(get('/panel/tasima'))
def post(action,data={},file=None,owner=client,secret=token):
 status,body,_=request(route('/panel/tasima/'+action),data,secret,file=file,opener=owner)
 try:result=json.loads(body)
 except Exception:raise AssertionError((status,body[:300]))
 return status,result

def begin(file,kind,job='',path='',key=None):
 return post('dosya-baslat',{'kind':kind,'name':file.name,'size':str(file.stat().st_size),'client_key':key or str(file),'job':job,'path':path})
def transfer(file,kind,job='',path='',retry_check=False):
 status,t=begin(file,kind,job,path);assert status==200,t;size=t['chunk_size'];assert 0<size<2*1024*1024
 offset=t['offset'];ident=t['upload'];chunks=0
 with file.open('rb') as h:
  h.seek(offset)
  while offset<file.stat().st_size:
   data=h.read(size);status,t=post('dosya-parca',{'upload':ident,'offset':str(offset)},('chunk_file','chunk.part',data));assert status==200,t
   if retry_check and chunks==0:
    previous=t['offset'];status,again=post('dosya-parca',{'upload':ident,'offset':str(offset)},('chunk_file','chunk.part',data));assert status==200 and again['offset']==previous
    status,resumed=begin(file,kind,job,path);assert resumed['offset']==previous
    status,wrong=post('dosya-parca',{'upload':ident,'offset':'0'},('chunk_file','chunk.part',b'wrong'));assert status==422 and not wrong['ok']
   offset=t['offset'];chunks+=1
 status,t=post('dosya-bitir',{'upload':ident});assert status==200,t;return t,chunks
with tempfile.TemporaryDirectory(prefix='reflex-chunks-') as temp:
 tmp=Path(temp);sql=tmp/'large.sql';count=160005
 with sql.open('wb') as h:
  h.write(b'CREATE TABLE old_news (`id` INT,`title` TEXT,`body` TEXT); INSERT INTO old_news VALUES ')
  for i in range(count):h.write(((',' if i else '')+f"({i},'{'Başlık '*35}','<p>Unicode içerik; satır</p>')").encode())
  h.write(b';')
 assert sql.stat().st_size>32*1024*1024
 status,error=post('dosya-baslat',{'kind':'sql','name':'x.sql','size':'1','client_key':'csrf'},secret='invalid');check(status==419 and not error['ok'],'Chunk initialization enforces CSRF')
 t,chunks=transfer(sql,'sql',retry_check=True);job=t['job'];check(chunks>1,'SQL above 32 MB uses sub-2-MB requests and acknowledges retry/resume without duplication')
 loops=0
 while True:
  status,r=post('incele',{'job':job});assert status==200,r;loops+=1
  if r['done']:break
 check(loops>1 and r['records']==count,'More than 150,000 records in one long INSERT are analyzed incrementally under 64 MB memory')
 page=request(route('/panel/tasima',job=job))[1]
 check(str(count) in page,'Every streamed source row is available for mapping')
 editor=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));elogin=request(route('/panel/giris'),opener=editor)[1];request(route('/panel/giris'),{'email':'test-editor@example.invalid','password':PASSWORD},csrf(elogin),opener=editor)
 check(request(route('/panel/tasima/dosya-bitir'),{'upload':t['upload'],'csrf':token},opener=editor)[0]==403,'Editor cannot access staged chunks')
 image=tmp/'big.jpg';photo=(Path(__file__).resolve().parents[1]/'assets/v6/demo/bogaz-5-2-400x225.jpg').read_bytes()
 with image.open('wb') as h:
  h.write(photo)
  for i in range(66):h.write(b'X'*1024*1024)
 zipfile_path=tmp/'large.zip'
 with zipfile.ZipFile(zipfile_path,'w',zipfile.ZIP_STORED) as z:
  z.write(image,'uploads/archive/big.jpg')
  for i in range(5001):z.writestr(f'uploads/archive/small-{i}.jpg',photo)
 assert zipfile_path.stat().st_size>64*1024*1024
 t,chunks=transfer(zipfile_path,'zip',job);check(chunks>1,'ZIP above 64 MB is accepted through bounded chunk transfers')
 loops=0
 while not t['done']:
  status,t=post('arsiv-devam',{'upload':t['upload']});assert status==200,t;loops+=1
 page=request(route('/panel/tasima',job=job))[1];check('5002 görsel' in page and loops>1,'ZIP with more than 5,000 images is extracted in resumable batches')
 # Content checksum and large original image are verified from the public mapping.
 local=Path('/workspace/reflex-v333-cpanel-test/uploads/migration')/job/(hashlib.sha256(image.read_bytes()).hexdigest()+'.jpg')
 check(local.stat().st_size==image.stat().st_size and hashlib.sha256(local.read_bytes()).digest()==hashlib.sha256(image.read_bytes()).digest(),'Large ZIP image is copied completely with validated CRC and original bytes')
 t,_=transfer(image,'image',job,'uploads/other/big.jpg');check(t['done'],'Direct folder image above PHP per-file limit is assembled and mapped')
 bad=tmp/'bad.zip'
 with zipfile.ZipFile(bad,'w') as z:z.writestr('../escape.jpg',photo)
 t,_=transfer(bad,'zip',job);status,error=post('arsiv-devam',{'upload':t['upload']});check(status==422 and not error['ok'],'Chunked ZIP still rejects path traversal')
 schema=tmp/'schema.sql';schema.write_text('CREATE TABLE empty_news (`id` INT);')
 t,_=transfer(schema,'sql');status,error=post('incele',{'job':t['job']});check(status==422 and 'INSERT' in error['message'],'Schema-only SQL gives a visible explanation instead of a silent upload')
 cleanup=get('/panel/tasima');request(route('/panel/tasima/temizle',job=job),{},csrf(cleanup))
print('Large chunk HTTP checks completed under constrained PHP.')
