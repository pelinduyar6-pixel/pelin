"""Live visits, selectable sources, BIK insertion and media import UI; localhost only."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
assert urllib.parse.urlsplit(BASE).hostname in ['localhost','127.0.0.1']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
def live():
    status,body,_=request(route('/panel/api/live-traffic'));assert status==200;return json.loads(body)['data']
check('Şu Anda Sitede' in get('/panel/canli-veri') and 'data-live-traffic' in get('/panel'),'Live center and dashboard expose actual traffic')
before=live()['views_30m'];get('/');get('/panel/haberler');check(live()['views_30m']==before,'Authenticated panel/site requests are excluded from traffic')
reader=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
status,home,_=request(route('/'),opener=reader);m=re.search(r'name="live-visitor-endpoint"[^>]*data-csrf="([a-f0-9]+)"',home);assert m;token=m[1]
check(live()['views_30m']==before+1,'Anonymous page load adds exactly one timed view')
status,_,_=request(route('/api/ziyaret'),{'page_route':'/'},'bad',opener=reader);check(status==419,'Heartbeat rejects invalid CSRF')
status,body,_=request(route('/api/ziyaret'),{'page_route':'/'},token,opener=reader);check(status==200 and json.loads(body)['ok'] and live()['views_30m']==before+1,'Valid heartbeat maintains presence without extra views')
status,_,_=request(route('/api/ziyaret'),{'page_route':'/not-visited'},token,opener=reader);check(status==422,'Heartbeat rejects fabricated pages')
code=get('/panel/ozel-kodlar');check('name="code_bik"' in code and 'BİK takip kodu' in code,'Separate BIK code editor is available')
values={k:re.search(r'name="'+k+r'"[^>]*>(.*?)</textarea>',code,re.S).group(1) for k in ['code_head','code_body_start','code_footer','code_body_end','code_bik']}
import html
values={k:html.unescape(v) for k,v in values.items()}
try:
    form={**values,'code_bik':'<script data-bik-fixture="1">window.reflexBikFixture=1;</script>'};status,_,_=request(route('/panel/ozel-kodlar'),form,csrf(code));check(status==200,'BIK code saves with CSRF')
    public=request(route('/'),opener=reader)[1];check(public.count('data-bik-fixture="1"')==1 and 'data-bik-fixture="1"' not in get('/panel'),'BIK code executes once on public pages and never on panel')
finally:request(route('/panel/ozel-kodlar'),values,csrf(get('/panel/ozel-kodlar')))
# Sources keep user-controlled URL/category/timing when paused and resumed.
name='Selectable source test';data={'name':name,'feed_url':'https://example.org/custom/rss','source_kind':'rss','interval_minutes':'45','max_items':'2','import_status':'draft','schedule_mode':'daily','daily_time':'08:15','active':'1'}
status,body,_=request(route('/panel/botlar/duzenle'),data,csrf(get('/panel/botlar')));check(status==200,'Custom source URL and daily time save without a network fetch')
m=re.search(name+r'.*?route=%2Fpanel%2Fbotlar%2Fdurum[^"\n]*?id=(\d+)',body,re.S);assert m;source_id=int(m[1])
try:
    for active in ['0','1']:
        status,body,_=request(route('/panel/botlar/durum',id=source_id),{'active':active},csrf(get('/panel/botlar')));selected=re.search(name+r'.*?</tr>',body,re.S).group(0);check(status==200 and ('Duraklatıldı' if active=='0' else '>Aktif<') in selected,'Source can be '+('paused' if active=='0' else 'resumed'))
    form=request(route('/panel/botlar',id=source_id))[1]
    check('https://example.org/custom/rss' in form and 'value="08:15"' in form and 'value="45"' in form,'Source URL and chosen schedule survive activation changes')
finally:request(route('/panel/botlar/sil',id=source_id),{},csrf(get('/panel/botlar')))
records=get('/panel/haberler');check('<th>Kapak</th><th>Başlık</th>' in records and '<th>Görüntülenme</th>' in records,'News table has separate cover/title and reference columns')
editor=get('/panel/haberler/yeni');check(editor.count('class="editor-step-number"')==4,'Editor step numbers are separated from their labels')
migration=get('/panel/tasima');check('name="sql_file"' in migration and 'data-migration-directory' in migration and 'name="image_zip"' in migration,'SQL and separate uploads folder/ZIP selection exist on first screen')
print('Refinement HTTP checks completed:',DRIVER)
