/* Restored theme, sharing, pagination and bot checks on disposable localhost only. */
const { chromium } = require('playwright'), fs = require('fs'), path = require('path');
(async () => {
  const base = process.argv[2], out = process.env.REFLEX_SCREENSHOTS || '/workspace/outputs/reflex-edition';
  if (!/^http:\/\/(localhost|127\.0\.0\.1):/.test(base)) throw Error('Disposable local installation required');
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
  const admin = await browser.newPage({ viewport: { width: 1440, height: 1000 } }), reader = await browser.newPage({ viewport: { width: 1440, height: 1000 } }), errors = [];
  for (const page of [admin, reader]) page.on('pageerror', e => errors.push(e.message));
  admin.on('dialog', d => d.dismiss());
  const route = p => base + '/index.php?' + new URLSearchParams({ route: p });
  const check = (ok, label) => { if (!ok) throw Error(label); console.log('PASS', label); };
  await admin.goto(route('/panel/giris')); await admin.locator('[name=email]').fill('test-admin@example.invalid'); await admin.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD); await admin.getByRole('button', { name: 'Giriş yap' }).click(); await admin.waitForURL(/route=%2Fpanel$/);
  for (const width of [1440, 768, 390, 320]) {
    await admin.setViewportSize({ width, height: 1000 });
    for (const screen of ['haberler', 'haberler/yeni', 'botlar', 'reklamlar/yeni', 'ogeler', 'api-merkezi', 'tasima']) {
      const response = await admin.goto(route('/panel/' + screen)); check(response.status() === 200 && await admin.evaluate(() => document.documentElement.scrollWidth <= innerWidth), screen + ' fits ' + width + 'px');
    }
    await admin.goto(route('/panel/haberler')); const button = admin.locator('[data-share-url]').first(); await button.click();
    const menu = admin.locator('#news-share-menu'); check(await menu.locator('[role=menuitem]').count() === 9, 'Share menu exposes eight services plus copy at ' + width + 'px');
    check(await menu.evaluate(e => { const r = e.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth && r.top >= 0 && r.bottom <= innerHeight; }), 'Share menu remains inside viewport at ' + width + 'px');
    const url = await button.getAttribute('data-share-url'), title = await button.getAttribute('data-share-title');
    const x = new URL(await menu.getByRole('menuitem', { name: 'X (Twitter)' }).getAttribute('href'));
    check(x.searchParams.get('url') === url && x.searchParams.get('text') === title, 'Sharing encodes actual URL and Turkish title at ' + width + 'px');
    await admin.keyboard.press('ArrowDown'); check(await menu.getByRole('menuitem', { name: 'X (Twitter)' }).evaluate(e => e === document.activeElement), 'Share menu keyboard navigation works');
    if (width === 1440) await admin.screenshot({ path: path.join(out, 'paylas-menu.png') });
    await admin.keyboard.press('Escape'); check(await menu.isHidden() && await button.evaluate(e => e === document.activeElement), 'Escape closes share menu and restores trigger focus');
    await button.click(); await admin.locator('.admin-heading h1').click(); check(await menu.isHidden(), 'Outside click closes share menu');
  }
  await admin.setViewportSize({ width: 1440, height: 1000 }); await admin.goto(route('/panel/haberler'));
  await admin.context().grantPermissions(['clipboard-read', 'clipboard-write'], {origin:base});
  const copyTrigger=admin.locator('[data-share-url]').first();await copyTrigger.click();await admin.locator('#news-share-menu').getByRole('menuitem',{name:'Linki kopyala'}).click();
  check(await admin.evaluate(()=>navigator.clipboard.readText())===await copyTrigger.getAttribute('data-share-url'),'Copy option writes the actual news URL');await admin.keyboard.press('Escape');
  check(await admin.locator('.record-identity strong').first().evaluate(e => parseFloat(getComputedStyle(e).fontSize) >= 14), 'News titles are readable in administration');
  const pager = admin.locator('.pagination');
  check(await pager.isVisible(), 'News list has multiple actual pages');
  check(await pager.evaluate(e => {
    const controls = [...e.children].map(x => x.getBoundingClientRect());
    return getComputedStyle(e).display === 'flex' && controls.every((r,i) => r.height >= 36 && (!i || r.left - controls[i-1].right >= 6 || r.top > controls[i-1].bottom));
  }), 'Pagination buttons have separate, readable hit areas');
  await pager.getByRole('link', {name:'2',exact:true}).click();
  check(await admin.locator('.pagination [aria-current=page]').textContent() === '2', 'Page 2 becomes selected after navigation');
  await admin.locator('.pagination').screenshot({path:path.join(out,'haber-sayfalama.png')});
  await admin.goto(route('/panel/botlar')); await admin.locator('[name=schedule_mode]').selectOption('daily'); check(await admin.locator('[data-daily-schedule]').isVisible() && await admin.locator('[data-interval-schedule]').first().isHidden(), 'Bot form displays chosen daily hour');
  await admin.screenshot({ path: path.join(out, 'bot-merkezi.png'), mask: [admin.locator('.cron-card input')] });
  await admin.locator('[name=schedule_mode]').selectOption('interval'); check(await admin.locator('[data-daily-schedule]').isHidden(), 'Bot form hides daily hour in interval mode');
  for (const theme of [1, 2, 3, 4]) {
    await admin.goto(route('/panel/tema')); await admin.locator('[name=theme_style][value="' + theme + '"]').check(); await admin.getByRole('button', { name: 'Tema ayarlarını kaydet' }).click();
    for (const width of [1440, 1100, 900, 768, 390, 320]) {
      await reader.setViewportSize({ width, height: 1000 }); await reader.goto(base, { waitUntil: 'networkidle' });
      check(await reader.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'Theme ' + theme + ' fits ' + width + 'px');
      const layouts = {1: '.home-grid .side-carousel', 2: '.triple-hero + .featured-pair', 3: '.wide-hero', 4: '.banner-hero'};
      check(await reader.locator(layouts[theme]).count() > 0 && await reader.locator('.main-agenda').count() === 0, 'Original page arrangement restored in theme ' + theme);
      check(await reader.locator('.main-nav a').filter({hasText:'Türkiye Gündemi'}).count() === 1, 'Existing primary category remains in navigation');
      check(await reader.locator('.headline-carousel').first().evaluate(e => {
        const title = e.querySelector('.hero-slide:not([hidden]) h2').getBoundingClientRect(), tag = e.querySelector('.hero-slide:not([hidden]) .hero-tag').getBoundingClientRect(), dots = e.querySelector('.carousel-dots').getBoundingClientRect(), stage = e.querySelector('.hero-stage').getBoundingClientRect();
        return title.top >= tag.bottom - 1 && title.bottom <= stage.bottom + 1 && dots.top >= stage.bottom - 1;
      }), 'Headline title, label and numbers do not overlap: theme ' + theme + ' ' + width + 'px');
      check(await reader.locator('.markets-compact').evaluate(e => e.previousElementSibling.classList.contains('authors-middle')), 'Markets still follow authors');
      if (width === 1440) {
        await reader.screenshot({ path: path.join(out, 'tema-' + theme + '.png') });
        if (theme === 1) {
          await reader.locator('.home-grid').screenshot({ path: path.join(out, 'turkiye-gundemi.png') });
          const first = await reader.locator('.footer-highlights').boundingBox(), last = await reader.locator('.site-footer').boundingBox();
          await reader.screenshot({ path: path.join(out, 'footer.png'), fullPage: true, clip: { x: 0, y: first.y, width: 1440, height: last.y + last.height - first.y } });
          const article = await reader.locator('.home-grid .news-card a').first().getAttribute('href'); await reader.goto(new URL(article, base).href);
          check(await reader.locator('.article-sidebar .article-recent .compact-story').count() > 0 && await reader.locator('.article-sidebar .popular-sidebar').count() === 1, 'Article has visual recent and popular stories');
          await reader.screenshot({ path: path.join(out, 'haber-detay.png') });
        }
      }
      if (width === 390) await reader.screenshot({ path: path.join(out, 'tema-' + theme + '-mobil.png') });
    }
    for(const width of [1440,390,320]){
      await reader.setViewportSize({width,height:1000});await reader.goto(route('/kategori/politika'));
      check(await reader.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Category fits theme '+theme+' at '+width+'px');
      check(await reader.locator('.category-page-hero .hero-slide:not([hidden]) h2').evaluate(e=>getComputedStyle(e).backgroundColor==='rgba(0, 0, 0, 0)'&&getComputedStyle(e).color==='rgb(255, 255, 255)'),'Category headline has no white band in theme '+theme);
      if(width===1440&&theme===1)await reader.screenshot({path:path.join(out,'kategori-slider.png')});
    }
  }
  await admin.goto(route('/panel/tema')); await admin.locator('[name=theme_style][value="1"]').check(); await admin.getByRole('button', { name: 'Tema ayarlarını kaydet' }).click();
  check(errors.length === 0, 'No browser script errors: ' + errors.join('; ')); await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
