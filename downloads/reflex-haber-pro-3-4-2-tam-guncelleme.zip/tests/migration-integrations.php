<?php
declare(strict_types=1);
require __DIR__.'/../app/core.php';require __DIR__.'/../app/pro.php';require __DIR__.'/../app/install.php';
$config=require ROOT.'/storage/site.php';if(!in_array(parse_url($config['site_url'],PHP_URL_HOST),['127.0.0.1','localhost'],true))exit(1);
date_default_timezone_set('Europe/Istanbul');$pdo=new PDO('sqlite::memory:');$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);Database::use($pdo);create_schema($pdo,'sqlite');seed_site('Test','test@example.invalid','Local-test-password-2026!',false);
function check(bool $ok,string $label):void{if(!$ok)throw new RuntimeException('FAIL '.$label);echo 'PASS '.$label.PHP_EOL;}
$id=bin2hex(random_bytes(16));$dir=migration_dir($id);mkdir($dir,0700);$sql=$dir.'/source.sql';
file_put_contents($sql,<<<'SQL'
-- Source fixture only; DDL must never run
DROP TABLE rh6_users;
CREATE TABLE old_categories (`id` INT, `name` VARCHAR(100), `slug` VARCHAR(100));
INSERT INTO old_categories VALUES (1,'Eski yerel','eski-yerel'),(11,'ID korunacak','id-korunacak'),(900,'Yüksek ID','yuksek-id'),(7,'Türkiye Gündemi','gundem');
CREATE TABLE old_news (`id` INT, `title` VARCHAR(255), `body` TEXT, `category_id` INT, `image` VARCHAR(1000), `summary` TEXT, `date` DATETIME);
INSERT INTO old_news VALUES
(51,'Virgül, noktalı; tırnak \' ve Türkçe','<p>İlk kaynak haber.</p><p><img src="https://old.example.invalid/resimler/a.png"><script>alert(1)</script></p>',11,'https://old.example.invalid/resimler/a.png','Birinci özet','2020-01-02 10:20:00'),
(52,'İkinci haber','<p>İkinci içerik.</p>',1,NULL,NULL,NULL),
(53,'Üçüncü haber','<p>Üçüncü içerik.</p>',900,'a.png','Özet',NULL),
(54,'Dördüncü haber','<p>Dördüncü içerik.</p>',7,NULL,NULL,NULL),
(55,'','',7,NULL,NULL,NULL);
SQL);
try{
    $tables=migration_parse_sql($sql,$dir);check($tables['old_news']['count']===5&&count($tables['old_categories']['columns'])===3,'SQL parser understands multiline INSERT and declared columns');
    check(Database::scalar('SELECT COUNT(*) FROM rh6_users')===1,'Uploaded DROP and DDL are never executed');
    $job=['id'=>$id,'owner'=>1,'hash'=>hash_file('sha256',$sql),'tables'=>$tables,'stage'=>'mapping','mapping'=>[],'images'=>[],'cursor'=>0,'imported'=>0,'duplicates'=>0,'skipped'=>0,'missing_images'=>0];migration_store($job);
    $guess=migration_guess($job);check($guess['news_table']==='old_news'&&$guess['category_table']==='old_categories','News and category mapping can be inferred from field names');
    $map=migration_validate_mapping($job,$guess);$plan=migration_category_plan($job,$map);check($plan[11]['preserve']&&$plan[900]['preserve']&&!$plan[1]['preserve']&&$plan[7]['target']===1,'Category preview distinguishes free IDs, collisions and existing slugs');
    check(Database::scalar('SELECT COUNT(*) FROM rh6_news')===0&&Database::scalar('SELECT COUNT(*) FROM rh6_categories')===10,'Mapping preview does not write news or categories');
    try{migration_validate_mapping($job,[...$map,'body'=>'not_a_column']);check(false,'Bad mapping');}catch(InvalidArgumentException){check(true,'Mapping rejects unknown source columns');}
    $job['mapping']=$map;$job['stage']='preview';$job['images']=['resimler/a.png'=>'uploads/migration/'.$id.'/a.png'];migration_store($job);$job=migration_start($job);
    check($job['category_map'][11]===11&&$job['category_map'][900]===900&&$job['category_map'][1]!==1&&$job['category_map'][7]===1,'Free legacy IDs are reserved before new IDs for conflicts');
    check(Database::row('SELECT name FROM rh6_categories WHERE id=1')['name']==='Türkiye Gündemi','Category collision does not overwrite current categories');
    $job=migration_batch($job,2);check($job['cursor']===2&&$job['imported']===2&&$job['stage']==='importing','Batch imports records with resumable progress');
    $first=Database::row('SELECT * FROM rh6_news ORDER BY id LIMIT 1');check($first['status']==='draft'&&$first['category_id']===11&&$first['title']==="Virgül, noktalı; tırnak ' ve Türkçe",'Imported stories keep Unicode and category relationships and remain drafts');
    check($first['image']==='uploads/migration/'.$id.'/a.png'&&str_contains($first['body'],'/uploads/migration/')&&!str_contains($first['body'],'<script'),'Covers and inline images are mapped and unsafe HTML is removed');
    $stale=$job;$stale['cursor']=0;$stale['byte_offset']=0;$stale['imported']=0;$stale['duplicates']=0;$stale=migration_batch($stale,2);check($stale['duplicates']===2&&Database::scalar('SELECT COUNT(*) FROM rh6_news')===2,'Retry after a stale progress file cannot duplicate imported stories');
    $job=migration_batch($job,100);check($job['stage']==='complete'&&$job['imported']===4&&$job['skipped']===1,'Final batch reports blank records without breaking valid imports');
    check(migration_image('a.png',['one/a.png'=>'one','two/a.png'=>'two'])===null,'Ambiguous image basenames are not assigned to the wrong story');
    check(migration_image('https://old.invalid/root/resimler/a.png',$job['images'])===$job['images']['resimler/a.png'],'Old image URL paths resolve through preserved folder suffixes');
    foreach(['../outside.png','/absolute.png','C:\\outside.png','x/../outside.png'] as $path){try{migration_safe_image_path($path);check(false,'Unsafe archive path');}catch(InvalidArgumentException){}}
    check(true,'Archive paths reject traversal and absolute paths');
    foreach(['(1, NOW())',"(1, 'unfinished)",'(1, 2) ON DUPLICATE KEY UPDATE id=1'] as $values){try{iterator_to_array(migration_literals($values));check(false,'SQL expression');}catch(InvalidArgumentException){}}
    check(true,'SQL values reject executable expressions and incomplete records');
    try{migration_load($id,2);check(false,'Other owner');}catch(InvalidArgumentException){check(true,'Staged data cannot be read by a different administrator');}
    $literal=iterator_to_array(migration_literals("('a''b', 'line\\nvalue', NULL, -1.25)"))[0];check($literal===["a'b","line\nvalue",null,'-1.25'],'Literal parser preserves escaped text, NULL and decimal numbers');
}finally{foreach(glob($dir.'/*')?:[] as $file)if(is_file($file))unlink($file);if(is_dir($dir))rmdir($dir);}
echo "Migration integration checks completed; isolated database only.\n";
