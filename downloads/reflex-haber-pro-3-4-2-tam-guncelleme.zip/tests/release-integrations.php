<?php
// Release audit uses isolated local files; no DB or private configuration is opened.
declare(strict_types=1);
require __DIR__.'/../app/core.php';require __DIR__.'/../app/pro.php';require __DIR__.'/../app/release-check.php';
function check(bool $ok,string $label):void{if(!$ok)throw new RuntimeException('FAIL '.$label);echo 'PASS '.$label.PHP_EOL;}
$base=sys_get_temp_dir().'/reflex-release-test-'.bin2hex(random_bytes(6));mkdir($base.'/assets/v6',0700,true);
try{
    $style='body { color: red; }';$path='assets/v6/edition-admin.css';file_put_contents($base.'/'.$path,$style);
    $manifest=['version'=>PRO_VERSION,'files'=>[$path=>hash('sha256',$style)]];file_put_contents($base.'/release-files.json',json_encode($manifest));
    check(release_check($base)['issues']===[],'Complete package passes file audit');
    file_put_contents($base.'/'.$path,'body { color: blue; }');$r=release_check($base);check(count($r['issues'])===1&&$r['issues'][0]['file']===$path,'Mixed old CSS is identified by its exact relative file path');
    unlink($base.'/'.$path);check(release_check($base)['issues'][0]['status']==='Eksik veya okunamıyor','Missing pagination stylesheet is reported');
    $manifest['files']=['../../private.php'=>hash('sha256','')];file_put_contents($base.'/release-files.json',json_encode($manifest));check(release_check($base)['checked']===0,'Manifest cannot request private or parent paths');
    unlink($base.'/release-files.json');check(release_check($base)['version']===null,'Missing release manifest cannot claim a verified update');
}finally{@unlink($base.'/'.$path);@unlink($base.'/release-files.json');rmdir($base.'/assets/v6');rmdir($base.'/assets');rmdir($base);}
echo "Release audit checks completed.\n";
