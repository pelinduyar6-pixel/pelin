const {chromium}=require('playwright'),cp=require('child_process');
(async()=>{
 const base=process.argv[2],root=process.argv[3];if(base!=='http://127.0.0.1:8181'||root!=='/workspace/reflex-v340-fresh-sqlite')throw Error('Disposable target required');
 const fixture=mode=>cp.execFileSync('/workspace/reflex-tools/php',[__dirname+'/theme-data-fixture.php',root,mode]);
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),a=await b.newPage(),p=await b.newPage();
 const route=s=>base+'/index.php?'+new URLSearchParams({route:s}),check=(ok,label)=>{if(!ok)throw Error(label);console.log('PASS',label)};
 try{
  await a.goto(route('/panel/giris'));await a.locator('[name=email]').fill('test-admin@example.invalid');await a.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD);await a.getByRole('button',{name:'Giriş yap'}).click();await a.waitForURL(/route=%2Fpanel$/);
  for(const mode of ['empty','one','many']){fixture(mode);
   for(const theme of ['5','6','7','8']){
    await a.goto(route('/panel/tema'));await a.locator('[name=theme_style][value="'+theme+'"]').check();await a.getByRole('button',{name:'Tema ayarlarını kaydet'}).click();
    for(const width of [1440,320]){await p.setViewportSize({width,height:1000});await p.goto(route('/'));check(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Sparse/long fixture fits '+mode+'/'+theme+'/'+width);
     if(mode==='empty'){check(await p.locator('.reference-lead,.reference-top,.reference-content').count()===0,'Empty data leaves no hero, card or sidebar wrappers '+theme+'/'+width);}
     else{check(await p.locator('.reference-hero .hero-slide').count()===(mode==='one'?1:17),'Correct real slide count '+mode+'/'+theme+'/'+width);check(await p.locator('.reference-hero').evaluate(e=>{const t=e.querySelector('h2').getBoundingClientRect(),s=e.querySelector('.hero-stage').getBoundingClientRect(),d=e.querySelector('.carousel-dots').getBoundingClientRect();return t.top>=s.top&&t.bottom<=s.bottom&&d.top>=s.bottom;}),'Long headline and numbers occupy separate areas '+mode+'/'+theme+'/'+width);await p.locator('.reference-hero .carousel-dots button').last().click();check(await p.locator('.reference-hero .carousel-dots button').last().getAttribute('aria-pressed')==='true','Last slide is selectable '+mode+'/'+theme+'/'+width);check(await p.locator('.reference-hero').evaluate(e=>{const t=e.querySelector('.hero-slide:not([hidden]) h2').getBoundingClientRect(),r=e.querySelector('.hero-stage').getBoundingClientRect();return t.top>=r.top&&t.bottom<=r.bottom&&t.left>=r.left&&t.right<=r.right;}),'Last headline fits its image '+mode+'/'+theme+'/'+width);}
    }
   }
  }
 }finally{fixture('restore');await b.close();}
})().catch(e=>{console.error(e);process.exit(1)});
