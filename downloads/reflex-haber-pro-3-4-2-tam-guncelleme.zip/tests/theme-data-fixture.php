<?php
// Exercises sparse and long-headline layouts in a disposable SQLite copy only.
$base=$argv[1];$mode=$argv[2];
if(!str_starts_with(realpath($base),'/workspace/reflex-v340-fresh-sqlite'))exit(1);
require $base.'/app/core.php';require $base.'/app/pro.php';
$config=require $base.'/storage/site.php';
if($config['db']['driver']!=='sqlite'||parse_url($config['site_url'],PHP_URL_HOST)!=='127.0.0.1')exit(1);
$file=$base.'/storage/theme-fixture.json';
if(!is_file($file))file_put_contents($file,json_encode(['news'=>Database::rows('SELECT id,title,status,is_headline,published_at FROM rh6_news'),'ads'=>Database::rows('SELECT id,active FROM rh6_ads'),'settings'=>Database::rows('SELECT name,value FROM rh6_settings')]));
$snapshot=json_decode(file_get_contents($file),true);
foreach($snapshot['news'] as $row){$id=$row['id'];unset($row['id']);Database::save('news',$row,$id);}
foreach($snapshot['ads'] as $row)Database::save('ads',['active'=>$row['active']],$row['id']);
foreach($snapshot['settings'] as $row)put_setting($row['name'],$row['value']);
if($mode==='restore'){unlink($file);exit;}
put_setting('home_primary_category','0');put_setting('home_sections','[]');put_setting('slider_autoplay','0');put_setting('home_show_headline','1');put_setting('home_show_top','1');put_setting('home_show_sidebar','1');
Database::query("UPDATE rh6_news SET status='draft'");Database::query('UPDATE rh6_ads SET active=0');
$count=match($mode){'empty'=>0,'one'=>1,'many'=>17,default=>throw new RuntimeException('Unknown mode')};
foreach(array_slice($snapshot['news'],0,$count) as $i=>$row){Database::save('news',['status'=>'published','is_headline'=>1,'published_at'=>'2026-10-01 12:00:00','title'=>$i===0?str_repeat('Türkiye gündeminde güncel gelişmeler ve ayrıntılar ',5):$row['title']],$row['id']);}
echo 'Fixture ready: '.$mode.PHP_EOL;
