"""3.2 bulk actions, category configuration and live-data API; disposable localhost only."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
import time
assert urllib.parse.urlsplit(BASE).hostname in ['127.0.0.1','localhost']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
prefix='LayoutBulk'+str(time.time_ns());ids=[]
for i in range(3):
 form=get('/panel/haberler/yeni');data={'title':prefix+' '+str(i),'slug':prefix.lower()+'-'+str(i),'body':'<p>Toplu işlem kabul testi.</p>','kind':'article','status':'draft','seo_autofill':'1'}
 status,body,_=request(route('/panel/haberler/yeni'),data,csrf(form));check(status==200,'Fixture news created')
 for match in re.finditer(r'<tr[^>]*>(.*?)</tr>',body,re.S):
  if data['title'] in match.group(1):ids.append(re.search(r'name="selected\[\]" value="(\d+)"',match.group(1)).group(1));break
check(len(ids)==3,'Modern news table provides selectable record IDs')
body=request(route('/panel/haberler',q=prefix))[1];token=csrf(body)
check(all(x in body for x in ['data-select-page','bulk_operation','Konum','SEO','Filtredeki tüm kayıtlar (3)']),'News list includes selection, scope, positions and SEO')
base={'bulk_operation':'publish','scope':'selected','selected[0]':ids[0],'selected[1]':ids[1]}
check(request(route('/panel/haberler/toplu'),base,'invalid')[0]==419,'Bulk endpoint enforces CSRF')
status,body,_=request(route('/panel/haberler/toplu'),base,token);check(status==200 and '2 kayıt için' in body,'Selected news publish together')
base={'bulk_operation':'delete','scope':'all','q':prefix,'expected_total':'3'}
check(request(route('/panel/haberler/toplu'),base,token)[0]>=400,'Bulk deletion requires explicit typed confirmation')
check(request(route('/panel/haberler/toplu'),{**base,'delete_confirmation':'SİL','expected_total':'999'},token)[0]>=400,'All-record deletion rejects stale record count')
check(prefix+' 2' in request(route('/panel/haberler',q=prefix))[1],'Rejected operation leaves records intact')
check(request(route('/panel/haberler/toplu'),{**base,'delete_confirmation':'SİL'},token)[0]==200,'Delete all acts only on the explicit filter scope')
check('Henüz kayıt bulunmuyor' in request(route('/panel/haberler',q=prefix))[1],'All scoped fixture news deleted')
form=get('/panel/yazarlar');own=re.search(r'name="selected\[\]" value="(\d+)"[^>]*disabled',form).group(1)
check(request(route('/panel/yazarlar/toplu'),{'bulk_operation':'delete','scope':'selected','selected[0]':own,'delete_confirmation':'SİL'},csrf(form))[0]>=400,'Current administrator cannot be bulk-deleted')
check('Yazarlar ve Kullanıcılar' in get('/panel/yazarlar'),'Administrator access remains after rejected deletion')
form=get('/panel/ogeler');category_ids=re.findall(r'name="home_category\[(\d+)\]\[enabled\]"',form)
check(len(category_ids)>4 and 'Teknoloji' in form and 'Magazin' in form,'Homepage panel exposes technology, magazine and every category')
# Save all existing selections; choose two layouts and place magazine before technology.
data={'categories_present':'1','home_show_top':'1','home_show_headline':'1','home_show_sidebar':'1'}
for i,key in enumerate(['latest','categories','video','gallery','authors']):data['active_'+key]='1';data['position['+key+']']=str(i+1)
for i,cid in enumerate(category_ids):data['home_category['+cid+'][enabled]']='1';data['home_category['+cid+'][position]']=str(i+1);data['home_category['+cid+'][layout]']='auto'
check(request(route('/panel/ogeler'),data,csrf(form))[0]==200,'Homepage saves complete category configuration')
home=get('/');check('vertical-breaking' not in re.sub(r'<style>.*?</style>','',home,flags=re.S),'Upper headline has no vertical breaking strip')
check(home.find('authors-middle')<home.find('data-live-markets'),'Markets appear after authors')
check('footer-highlights' in home and 'footer-social-band' in home and 'HAKKIMIZDA' in home,'New footer includes highlighted news, social strip and information columns')
status,body,_=request(route('/api/veriler'));payload=json.loads(body)
check(status==200 and len(payload['markets'])==5 and 'teams' in payload,'Public data endpoint exposes five cached markets and standings')
check(not any(x in body for x in ['football_key','market_token','openai_key','Authorization','csrf']),'Public data response never exposes integration credentials')
# Test editor role without modifying real accounts.
editor=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));login=request(route('/panel/giris'),opener=editor)[1]
status,body,_=request(route('/panel/giris'),{'email':'test-editor@example.invalid','password':PASSWORD},csrf(login),opener=editor)
if 'admin-sidebar' in body:
 form=request(route('/panel/haberler'),opener=editor)[1]
 check(request(route('/panel/haberler/toplu'),{'bulk_operation':'delete','scope':'all','expected_total':'0','delete_confirmation':'SİL'},csrf(form),opener=editor)[0]==403,'Editor cannot delete entire filtered archive')
else:raise AssertionError('Disposable editor account is required')
print('Layout HTTP checks completed:',DRIVER)
