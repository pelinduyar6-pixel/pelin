<?php
// Pro 3.3 behavior on an isolated in-memory database; no provider requests.
declare(strict_types=1);
require __DIR__.'/../app/core.php';require __DIR__.'/../app/pro.php';require __DIR__.'/../app/install.php';require __DIR__.'/../app/integrations.php';
$config=is_file(ROOT.'/storage/site.php')?require ROOT.'/storage/site.php':[];if(!in_array(parse_url($config['site_url']??'',PHP_URL_HOST),['localhost','127.0.0.1'],true))exit(1);
date_default_timezone_set('Europe/Istanbul');$_SESSION=[];$pdo=new PDO('sqlite::memory:');$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);Database::use($pdo);create_schema($pdo,'sqlite');seed_site('Test','test@example.invalid','Local-test-password-2026!',false);
function check(bool $ok,string $label):void{if(!$ok)throw new RuntimeException('FAIL '.$label);echo 'PASS '.$label.PHP_EOL;}
$category=Database::row("SELECT * FROM rh6_categories WHERE slug='gundem'");check($category['name']==='Türkiye Gündemi'&&setting('home_primary_category')===(string)$category['id'],'Primary category retains existing ID and gundem URL');
$before=Database::scalar('SELECT COUNT(*) FROM rh6_categories');initialize_primary_category();check(Database::scalar('SELECT COUNT(*) FROM rh6_categories')===$before,'Primary category migration does not duplicate categories');
check(setting('ai_model')==='gpt-5.6-sol','Shared AI default selects GPT-5.6');
$now='2026-01-01 12:00:00';foreach([['Popular',800,'published','article'],['Recent',3,'published','article'],['Private',999,'draft','article'],['Opinion',2000,'published','opinion']] as $i=>[$title,$views,$status,$kind])Database::save('news',['title'=>$title,'slug'=>strtolower($title),'body'=>'<p>Test news</p>','kind'=>$kind,'status'=>$status,'views'=>$views,'category_id'=>$category['id'],'published_at'=>$now,'created_at'=>$now,'updated_at'=>$now]);
$popular=news_rows('AND n.kind=?',['article'],5,0,'popular');check(array_column($popular,'title')===['Popular','Recent'],'Read ranking uses actual views and excludes drafts and opinions');
Database::save('news',['title'=>'Future','slug'=>'future','body'=>'<p>Future</p>','kind'=>'article','status'=>'published','views'=>9999,'published_at'=>'2099-01-01 00:00:00','created_at'=>$now,'updated_at'=>$now]);check(count(news_rows('AND n.kind=?',['article'],5,0,'popular'))===2,'Future publication cannot leak into rankings');
$clock=new DateTimeImmutable('2026-10-10 10:05:00',new DateTimeZone('Europe/Istanbul'));
check(source_next_run(['schedule_mode'=>'daily','daily_time'=>'11:00'],$clock)==='2026-10-10 11:00:00','Daily bot runs today when chosen time is ahead');
check(source_next_run(['schedule_mode'=>'daily','daily_time'=>'09:00'],$clock)==='2026-10-11 09:00:00','Daily bot keeps the exact local hour after a missed run');
check(source_next_run(['schedule_mode'=>'daily','daily_time'=>'10:05'],$clock)==='2026-10-11 10:05:00','Exact deadline advances to tomorrow instead of repeating');
check(source_next_run(['schedule_mode'=>'interval','interval_minutes'=>60,'next_run_at'=>'2026-10-10 09:00:00'],$clock)==='2026-10-10 11:00:00','Interval bot retains its configured clock without cron drift');
check(source_next_run(['interval_minutes'=>60,'next_run_at'=>'2026-10-10 13:00:00'],$clock)==='2026-10-10 13:00:00','Manual import preserves a future scheduled run');
try{source_next_run(['schedule_mode'=>'daily','daily_time'=>'25:00'],$clock);check(false,'Invalid daily time');}catch(InvalidArgumentException $e){check(true,'Daily schedule rejects invalid clock values');}
$id=Database::save('news_sources',['name'=>'Future fixture','feed_url'=>'https://example.invalid/rss','source_kind'=>'rss','active'=>1,'schedule_mode'=>'daily','daily_time'=>'09:00','next_run_at'=>'2099-01-01 09:00:00','interval_minutes'=>60,'max_items'=>5,'import_status'=>'draft']);$called=false;$count=import_source(Database::row('SELECT * FROM rh6_news_sources WHERE id=?',[$id]),function()use(&$called){$called=true;return '';},true);check(!$called&&$count===0,'Cron importer does not fetch a source before its deadline');put_setting('bot_enabled','0');check(run_due_sources()===[],'Automatic switch stops scheduled source requests');
$privatePath=ROOT.'/storage/integrations.php';$private=is_file($privatePath)?file_get_contents($privatePath):null;
try{
    save_integration_key('local-only-fixture-key');put_setting('ai_model','gpt-5.6-luna');$seen=[];
    $content=['title'=>'Kaynağa dayalı Türkçe haber başlığı','summary'=>'Mevcut kaynak metninin özeti.','seo_title'=>'Kaynağa dayalı Türkçe haber başlığı','seo_description'=>'Mevcut bilgilerden oluşturulmuş açıklama.','focus_keyword'=>'haber','body'=>'<p>'.str_repeat('Mevcut doğrulanmış bilgiler. ',10).'</p>'];
    $transport=function($payload)use(&$seen,$content){$seen[]=$payload['model'];return ['output'=>[['content'=>[['type'=>'output_text','text'=>json_encode($content)]]]]];};
    openai_seo(['body'=>str_repeat('Gerçek bilgiler. ',20)],$transport);openai_article(['facts'=>str_repeat('Doğrulanmış bilgiler. ',10),'kind'=>'article'],$transport);openai_connection_test(fn($payload)=>$transport($payload));
    check($seen===array_fill(0,3,'gpt-5.6-luna'),'SEO, writing and connection test send the same selected API model');
    $_POST=['ai_model'=>'gpt-5.6-terra','ai_target_words'=>'700'];save_ai_configuration();check(setting('ai_verified_model')===''&&setting('ai_model')==='gpt-5.6-terra','Changing model clears old connection verification');
}finally{if($private===null)@unlink($privatePath);else file_put_contents($privatePath,$private);}
Database::save('ads',['name'=>'Inline fixture','code'=>'<div class="inline-fixture">Advert</div>','placement'=>'article_inline','active'=>1,'device'=>'all','priority'=>1]);ob_start();render_article_body('<p>First paragraph</p><p>Second paragraph</p><p>Third paragraph</p><p>Fourth paragraph</p>');$body=ob_get_clean();check(substr_count($body,'inline-fixture')===1&&strpos($body,'Third paragraph')<strpos($body,'inline-fixture')&&strpos($body,'inline-fixture')<strpos($body,'Fourth paragraph'),'Inline advert appears once after third paragraph without breaking markup');
check(isset(ad_slots()['article_sidebar_top'],ad_slots()['article_sidebar_mid'],ad_slots()['article_sidebar_bottom']),'Advertising manager exposes three article-specific sidebar positions');
echo "Edition integration checks completed; no real AI or source requests.\n";
