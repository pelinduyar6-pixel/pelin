"""Social admin permissions and local settings; never publishes to external accounts."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
assert urllib.parse.urlsplit(BASE).hostname in ['localhost','127.0.0.1']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
page=get('/panel/sosyal-medya');check('name="facebook_token"' in page and 'name="x_token"' in page and 'Sosyal Medya Merkezi' in page,'Social menu exposes Facebook Page and X account setup')
check(not re.search(r'name="(?:facebook_token|x_token)"[^>]*value="[^\"]+',page),'Saved tokens are never rendered in input values')
check(request(route('/panel/sosyal-medya/ayarlar'),{'csrf':'bad'})[0]==419,'Social settings require a valid CSRF token')
status,body,_=request(route('/panel/sosyal-medya/ayarlar'),{'social_auto':'1','facebook_enabled':'1','facebook_page':'invalid','meta_version':'v24.0'},csrf(page));check(status==422 and 'Sayfa ID' in body,'Bad account settings show a visible validation error')
status,body,_=request(route('/panel/sosyal-medya/kuyruk'),{'news_id':'0','platform':'x'},csrf(get('/panel/sosyal-medya')));check(status==422,'Missing news cannot be queued')
status,body,_=request(route('/panel/sosyal-medya/calistir'),{},csrf(get('/panel/sosyal-medya')));check(status==422 and 'etkinleştirin' in body,'Disabled sharing does not trigger provider requests')
editor=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));login=request(route('/panel/giris'),opener=editor)[1];request(route('/panel/giris'),{'email':'test-editor@example.invalid','password':PASSWORD},csrf(login),opener=editor)
check(request(route('/panel/sosyal-medya'),opener=editor)[0]==403,'Account tokens and queue are administrator-only')
print('Social HTTP checks completed:',DRIVER)
