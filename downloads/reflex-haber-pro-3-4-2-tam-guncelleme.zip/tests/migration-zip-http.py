"""ZIP64, CRC, empty archive and failed-upload cleanup; disposable localhost."""
from pathlib import Path
exec(Path(__file__).with_name('migration-chunks-http.py').read_text().split("with tempfile.TemporaryDirectory")[0])
with tempfile.TemporaryDirectory(prefix='reflex-zip-edge-') as temp:
 tmp=Path(temp);sql=tmp/'source.sql';sql.write_text("INSERT INTO old_news (title,body) VALUES ('ZIP format test','<p>Body</p>');")
 t,_=transfer(sql,'sql');job=t['job'];status,result=post('incele',{'job':job});assert status==200 and result['done']
 photo=(Path(__file__).resolve().parents[1]/'assets/v6/demo/bogaz-5-2-400x225.jpg').read_bytes();standard=tmp/'standard.zip'
 with zipfile.ZipFile(standard,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('uploads/a.jpg',photo)
 data=standard.read_bytes();eocd=struct.unpack('<4s4H2LH',data[-22:]);count,cd_size,offset=eocd[4:7];z64=tmp/'zip64.zip';before=data[:-22];z64.write_bytes(before+struct.pack('<4sQHHIIQQQQ',b'PK\x06\x06',44,45,45,0,0,count,count,cd_size,offset)+struct.pack('<4sIQI',b'PK\x06\x07',0,len(before),1)+struct.pack('<4s4H2LH',b'PK\x05\x06',0,0,65535,65535,0xffffffff,0xffffffff,0))
 t,_=transfer(z64,'zip',job);status,t=post('arsiv-devam',{'upload':t['upload']});check(status==200 and t['done'],'ZIP64 directory metadata and deflated images are accepted')
 corrupt=tmp/'crc.zip'
 with zipfile.ZipFile(corrupt,'w',zipfile.ZIP_STORED) as z:z.writestr('uploads/corrupt.jpg',photo)
 data=bytearray(corrupt.read_bytes());namelen,extra=struct.unpack_from('<HH',data,26);data[30+namelen+extra]^=1;corrupt.write_bytes(data)
 t,_=transfer(corrupt,'zip',job);status,error=post('arsiv-devam',{'upload':t['upload']});check(status==422 and not error['ok'],'Corrupted archive data fails CRC validation before image mapping')
 ident=t['upload'];status,result=post('dosya-sil',{'upload':ident});check(status==200 and result['done'],'A failed partial archive can be removed from the panel')
 status,restarted=begin(corrupt,'zip',job);check(status==200 and restarted['offset']==0,'After removal the same archive starts a new transfer at zero bytes');post('dosya-sil',{'upload':restarted['upload']})
 empty=tmp/'empty.zip'
 with zipfile.ZipFile(empty,'w') as z:z.writestr('readme.txt','No supported images')
 t,_=transfer(empty,'zip',job);status,error=post('arsiv-devam',{'upload':t['upload']});check(status==422 and 'görsel bulunamadı' in error['message'],'An archive without images has a visible actionable error')
 page=request(route('/panel/tasima',job=job))[1];request(route('/panel/tasima/temizle',job=job),{},csrf(page));check('Yarım kalan' not in get('/panel/tasima') or t['upload'] not in get('/panel/tasima'),'Job cleanup removes associated partial upload metadata')
print('ZIP format HTTP checks completed:',DRIVER)
