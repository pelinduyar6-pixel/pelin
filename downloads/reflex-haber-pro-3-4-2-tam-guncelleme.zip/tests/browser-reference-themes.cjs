// Disposable localhost only: theme selection, headline controls and content routes.
const {chromium}=require('playwright'),fs=require('fs');
(async()=>{
 const base=process.argv[2];if(!/^http:\/\/(127\.0\.0\.1|localhost):/.test(base))throw Error('Local required');
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const admin=await browser.newPage({viewport:{width:1440,height:1000}}),reader=await browser.newPage();
 const preview=await browser.newPage({viewport:{width:1280,height:720},deviceScaleFactor:.5});
 const route=p=>base+'/index.php?'+new URLSearchParams({route:p}),errors=[];
 const check=(ok,label)=>{if(!ok)throw Error(label);console.log('PASS',label)};
 const out='/workspace/outputs/reflex-v340';fs.mkdirSync(out,{recursive:true});
 for(const page of [admin,reader,preview])page.on('pageerror',e=>errors.push(e.message));
 await admin.goto(route('/panel/giris'));await admin.locator('[name=email]').fill('test-admin@example.invalid');await admin.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD);
 await admin.getByRole('button',{name:'Giriş yap'}).click();await admin.waitForURL(/route=%2Fpanel$/);await admin.goto(route('/panel/tema'));
 check(await admin.locator('[name=theme_style]').count()===8,'All eight themes are selectable');
 const initial=await admin.locator('[name=theme_style]:checked').inputValue(),auto=await admin.locator('[name=slider_autoplay]').isChecked();
 const originalForm=await admin.locator('form:has([name=theme_style])').evaluate(f=>Object.fromEntries([...new FormData(f)].filter(([,v])=>typeof v==='string')));
 for(const theme of ['0','9']){const response=await admin.request.post(route('/panel/tema'),{form:{...originalForm,theme_style:theme}});check(response.status()===422,'Invalid theme '+theme+' is rejected');}
 for(const theme of ['5','6','7','8']){
  await admin.goto(route('/panel/tema'));await admin.locator('[name=theme_style][value="'+theme+'"]').check();await admin.locator('[name=slider_autoplay]').uncheck();await admin.getByRole('button',{name:'Tema ayarlarını kaydet'}).click();await admin.waitForLoadState('networkidle');
  check(await admin.locator('[name=theme_style]:checked').inputValue()===theme,'Theme '+theme+' persists after save');
  for(const width of [1720,1100,900,768,390,320]){
   await reader.setViewportSize({width,height:1000});await reader.goto(route('/'));await reader.evaluate(()=>document.fonts.ready);
   check(await reader.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'New theme '+theme+' fits '+width);
   check(await reader.locator('.reference-hero').count()===1,'One primary headline '+theme+'/'+width);
   check(await reader.locator('.reference-hero .hero-slide:not([hidden])').count()===1,'One active slide '+theme+'/'+width);
   check(await reader.locator('.reference-hero').evaluate(e=>{const stage=e.querySelector('.hero-stage').getBoundingClientRect(),text=e.querySelector('.hero-slide:not([hidden]) h2').getBoundingClientRect();return text.left>=stage.left&&text.right<=stage.right&&text.top>=stage.top&&text.bottom<=stage.bottom;}),'Title stays inside its image '+theme+'/'+width);
   check(await reader.locator('.carousel-dots').first().evaluate(e=>{const r=e.getBoundingClientRect(),buttons=[...e.querySelectorAll('button')].map(x=>x.getBoundingClientRect());return buttons.every(b=>b.left>=r.left-1&&b.right<=r.right+1&&b.top>=r.top-1)&&buttons.every((b,i)=>buttons.every((c,j)=>i===j||b.right<=c.left+1||c.right<=b.left+1||b.bottom<=c.top+1||c.bottom<=b.top+1));}),'Number buttons fit without overlapping '+theme+'/'+width);
   await reader.locator('.reference-hero .carousel-dots button').last().click();
   check(await reader.locator('.reference-hero .carousel-dots button').last().getAttribute('aria-pressed')==='true','Number buttons change the active headline '+theme+'/'+width);
   if(width===390)await reader.screenshot({path:out+'/tema-'+theme+'-mobil.png'});
  }
  await reader.setViewportSize({width:1440,height:1000});await reader.goto(route('/'));await reader.evaluate(()=>document.fonts.ready);await reader.screenshot({path:out+'/tema-'+theme+'.png'});
  const category=await reader.locator('.main-nav a[href*="kategori"]').first().getAttribute('href');await reader.goto(new URL(category,base).href);check(await reader.locator('.category-page-hero .hero-slide').count()>0,'Category slider renders in theme '+theme);
  const article=await reader.locator('.hero-slide').first().getAttribute('href');await reader.goto(new URL(article,base).href);check(await reader.locator('.article-sidebar .compact-story').count()>0,'Article sidebar renders in theme '+theme);
  await preview.goto(route('/'));await preview.evaluate(()=>document.fonts.ready);await preview.screenshot({path:out+'/tema-'+theme+'-onizleme.png'});
 }
 await admin.goto(route('/panel/ogeler'));const modules=await admin.locator('form:has([name=home_show_headline])').evaluate(f=>Object.fromEntries([...new FormData(f)].filter(([,v])=>typeof v==='string')));
 const disabled={...modules};delete disabled.home_show_headline;delete disabled.home_show_sidebar;delete disabled.home_show_top;
 const response=await admin.request.post(route('/panel/ogeler'),{form:disabled});check(response.ok(),'Home module flags save');await reader.goto(route('/'));
 check(await reader.locator('.reference-lead').count()===0&&await reader.locator('.reference-top').count()===0,'Disabled headline and top cards create no empty wrappers');
 check(await reader.locator('.reference-content').evaluate(e=>e.classList.contains('without-sidebar')),'Hidden sidebar releases the full content width');
 check(await reader.locator('.news-ticker').count()===1,'Ticker falls back to the header when headlines are hidden');
 await admin.request.post(route('/panel/ogeler'),{form:modules});
 await admin.goto(route('/panel/tema'));await admin.locator('[name=theme_style][value="'+initial+'"]').check();await admin.locator('[name=slider_autoplay]').setChecked(auto);await admin.getByRole('button',{name:'Tema ayarlarını kaydet'}).click();
 check(errors.length===0,'No browser script errors');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
