"""Separate SQL, ZIP and direct legacy uploads-folder acceptance, localhost only."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
import uuid, io, zipfile
assert urllib.parse.urlsplit(BASE).hostname in ['localhost','127.0.0.1']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
page=get('/panel/tasima');token=csrf(page)
check('name="image_zip"' in page and 'data-migration-directory' in page,'First migration screen exposes SQL, ZIP and folder uploads')
def files_post(path, fields, files, token=token):
    boundary='reflexFolderBoundary'+uuid.uuid4().hex;chunks=[]
    for key,value in {**fields,'csrf':token}.items():chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
    for key,name,data in files:chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"; filename="{name}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+data+b'\r\n')
    chunks.append(f'--{boundary}--\r\n'.encode())
    req=urllib.request.Request(BASE+'/'+path,data=b''.join(chunks),headers={'Content-Type':'multipart/form-data; boundary='+boundary,'Accept':'application/json'})
    try:
        with client.open(req) as r:return r.status,json.loads(r.read())
    except urllib.error.HTTPError as r:return r.code,json.loads(r.read()) if r.code!=419 else {}
photo=(Path(__file__).parents[1]/'assets/v6/demo/bogaz-5-2-400x225.jpg').read_bytes()
photo2=next(path.read_bytes() for path in (Path(__file__).parents[1]/'assets/v6/demo').glob('*.jpg') if path.read_bytes()!=photo)
stream=io.BytesIO()
with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as archive:archive.writestr('uploads/2020/kapak.jpg',photo)
sql=b"CREATE TABLE old_news (`title` VARCHAR(255),`body` TEXT,`image` VARCHAR(255));INSERT INTO old_news VALUES ('Folder upload fixture','<p>Test folder.</p><img src=\"/uploads/2020/kapak.jpg\">','https://old.invalid/uploads/2021/kapak.jpg');"
status,result=files_post(route('/panel/tasima/yukle'),{},[('sql_file','folder.sql',sql),('image_zip','uploads.zip',stream.getvalue())]);check(status==200 and result['images']==1,'SQL and optional image ZIP can be uploaded on the first screen')
job=urllib.parse.parse_qs(urllib.parse.urlsplit(result['redirect']).query)['job'][0]
try:
    endpoint=route('/panel/tasima/klasor',job=job)
    check(files_post(endpoint,{'image_paths[0]':'uploads/2021/kapak.jpg'},[('migration_files[0]','kapak.jpg',photo)],'bad')[0]==419,'Folder upload requires CSRF')
    for path,data in [('../bad.jpg',photo),('/absolute.jpg',photo),('uploads/not-image.jpg',b'<?php echo 1; ?>'),('uploads/shell.php',photo)]:
        check(files_post(endpoint,{'image_paths[0]':path},[('migration_files[0]','kapak.jpg',data)])[0]==422,'Directory upload rejects '+path)
    status,result=files_post(endpoint,{'image_paths[0]':'uploads/2021/kapak.jpg'},[('migration_files[0]','kapak.jpg',photo2)])
    check(status==200 and result['images']==2,'Independent folder upload preserves complete legacy uploads paths')
    check(files_post(endpoint,{'image_paths[0]':'uploads/2021/kapak.jpg'},[('migration_files[0]','kapak.jpg',photo2)])[1]['images']==2,'Repeating an uploaded folder batch does not duplicate mapped paths')
    page=request(route('/panel/tasima',job=job))[1]
    fields={'map[news_table]':'old_news','map[title]':'title','map[body]':'body','map[image]':'image'}
    status,page,_=request(route('/panel/tasima/eslestir',job=job),fields,csrf(page));check(status==200 and 'migration-preview-grid' in page and 'uploads/migration/' in page,'Folder and ZIP covers are available in the mapping preview')
    image=re.search(r'<article><img src="([^"]+)"',page).group(1)
    with client.open(BASE+image.replace("&amp;","&") if image.startswith('/') else image) as response:cover=response.read()
    check(cover==photo2,'Identical basenames in different uploads subfolders resolve to the correct image bytes')

finally:
    page=request(route('/panel/tasima',job=job))[1];request(route('/panel/tasima/temizle',job=job),{},csrf(page))
print('SQL/ZIP/folder HTTP checks completed:',DRIVER)
