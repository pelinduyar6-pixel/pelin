<?php
declare(strict_types=1);
function ai_model_choices():array{return ['gpt-5.6-sol'=>'GPT-5.6 Sol','gpt-5.6-terra'=>'GPT-5.6 Terra','gpt-5.6-luna'=>'GPT-5.6 Luna'];}
function save_ai_configuration():void{
    $model=text_input('ai_custom_model',80)?:text_input('ai_model',80,true);
    if(!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9._-]{1,79}$/',$model))throw new InvalidArgumentException('Geçerli OpenAI API model kimliği girin.');
    $words=isset($_POST['ai_target_words'])?integer_input('ai_target_words',700):(int)setting('ai_target_words','700');
    if($words<200||$words>2000)throw new InvalidArgumentException('Hedef 200–2000 kelime arasında olmalı.');
    $key=text_input('ai_api_key',500);if($key!==''&&preg_match('/\s/',$key))throw new InvalidArgumentException('API anahtarı boşluk içeremez.');
    if($key!==''||checked_input('remove_key')||$model!==setting('ai_model')){put_setting('ai_verified_model','');put_setting('ai_verified_at','');}
    if(checked_input('remove_key'))save_integration_key('');elseif($key!=='')save_integration_key($key);
    put_setting('ai_model',$model);put_setting('ai_target_words',(string)$words);
}
function source_next_run(array $source,?DateTimeImmutable $now=null):string{
    $zone=new DateTimeZone('Europe/Istanbul');$now=($now??new DateTimeImmutable('now',$zone))->setTimezone($zone);
    if(($source['schedule_mode']??'interval')==='daily'){
        $clock=$source['daily_time']??'';if(!is_string($clock)||!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D',$clock))throw new InvalidArgumentException('Günlük çalışma saati HH:MM biçiminde olmalı.');
        $next=$now->setTime((int)substr($clock,0,2),(int)substr($clock,3,2));if($next<=$now)$next=$next->modify('+1 day');return $next->format('Y-m-d H:i:s');
    }
    $step=max(5,(int)($source['interval_minutes']??60))*60;$anchor=!empty($source['next_run_at'])?strtotime($source['next_run_at']):false;
    if($anchor!==false&&$anchor>$now->getTimestamp())return $source['next_run_at'];
    $timestamp=$anchor===false?$now->getTimestamp()+$step:$anchor+(intdiv($now->getTimestamp()-$anchor,$step)+1)*$step;
    return (new DateTimeImmutable('@'.$timestamp))->setTimezone($zone)->format('Y-m-d H:i:s');
}
