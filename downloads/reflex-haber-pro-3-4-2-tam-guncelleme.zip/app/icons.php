<?php
function ui_icon(string $name):string{
    $paths=[
        'share'=>'<circle cx="6" cy="12" r="3"/><circle cx="18" cy="5" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4"/>',
        'dashboard'=>'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
        'news'=>'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h4M8 18h8"/>',
        'user'=>'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
        'folder'=>'<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10H3Z"/>',
        'comment'=>'<path d="M21 11a8 8 0 0 1-8 8H6l-4 3 1-6a8 8 0 1 1 18-5Z"/><path d="M7 9h9M7 13h6"/>',
        'ad'=>'<path d="m3 10 13-5v14L3 15Z"/><path d="M7 16v5h4l-1-4M20 8v8"/>',
        'media'=>'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="2"/><path d="m3 18 5-5 4 3 5-6 4 4"/>',
        'video'=>'<rect x="3" y="5" width="13" height="14" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
        'theme'=>'<path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 0-4h-1a2 2 0 0 1 0-4h3a6 6 0 0 0 6-6c0-3-5-4-9-4Z"/><path d="M7 8h.01M7 13h.01M12 7h.01M16 7h.01"/>',
        'settings'=>'<path d="m9 3-1 3-3 1 1 3-2 2 2 2-1 3 3 1 1 3h6l1-3 3-1-1-3 2-2-2-2 1-3-3-1-1-3Z"/><circle cx="12" cy="12" r="3"/>',
        'seo'=>'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6M8 10h4M10 8v4"/>',
        'bot'=>'<rect x="4" y="7" width="16" height="13" rx="3"/><path d="M12 3v4M1 11v5M23 11v5M8 15h8"/><circle cx="8" cy="11" r=".8"/><circle cx="16" cy="11" r=".8"/>',
        'code'=>'<path d="m8 6-6 6 6 6m8-12 6 6-6 6m-2-16-4 20"/>',
        'spark'=>'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z"/>',
        'sun'=>'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2"/>',
        'arrow'=>'<path d="M5 19 19 5M5 5h14v14"/>',
        'plus'=>'<path d="M12 4v16M4 12h16"/>',
        'printer'=>'<path d="M6 9V3h12v6M6 17H3V9h18v8h-3M6 14h12v7H6Z"/><path d="M17 11h1"/>',
        'email'=>'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
        'whatsapp'=>'<path d="M20.8 11.5A8.8 8.8 0 0 1 8 19.4L3 21l1.6-5A8.8 8.8 0 1 1 20.8 11.5Z"/><path d="m8 6 2 3-1.5 1.5a8 8 0 0 0 5 5L15 14l3 2c-1 3-4 3-8-1s-4-7-2-9Z"/>',
        'menu'=>'<path d="M4 6h16M4 12h10M4 18h16"/>'
    ];return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($paths[$name]??$paths['dashboard']).'</svg>';
}
