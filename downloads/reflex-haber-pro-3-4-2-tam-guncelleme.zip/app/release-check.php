<?php
declare(strict_types=1);
function release_check(string $root=ROOT):array {
    $file=$root.'/release-files.json';
    $manifest=is_file($file)?json_decode((string)file_get_contents($file),true):null;
    if(!is_array($manifest)||!is_string($manifest['version']??null)||!is_array($manifest['files']??null)||!$manifest['files'])return ['version'=>null,'checked'=>0,'issues'=>[['file'=>'release-files.json','status'=>'Eksik veya geçersiz']]];
    $issues=[];$checked=0;
    if($manifest['version']!==PRO_VERSION)$issues[]=['file'=>'app/pro.php','status'=>'Sürüm manifest ile farklı'];
    foreach($manifest['files'] as $path=>$expected){
        if(!is_string($path)||!preg_match('~^(?:(?:app|views|assets)/[a-zA-Z0-9_./-]+|[a-zA-Z0-9_-]+\.php|\.htaccess)$~D',$path)||str_contains($path,'..')||!is_string($expected)||!preg_match('/^[a-f0-9]{64}$/D',$expected)){$issues[]=['file'=>'release-files.json','status'=>'Geçersiz dosya kaydı'];continue;}
        $checked++;$target=$root.'/'.$path;
        if(!is_file($target)||!is_readable($target))$issues[]=['file'=>$path,'status'=>'Eksik veya okunamıyor'];
        elseif(!hash_equals($expected,(string)hash_file('sha256',$target)))$issues[]=['file'=>$path,'status'=>'Güncelleme paketinden farklı'];
    }
    return ['version'=>$manifest['version'],'checked'=>$checked,'issues'=>$issues];
}
