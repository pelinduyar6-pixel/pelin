<?php
declare(strict_types=1);
function migration_transfer_dir(string $id):string {if(!preg_match('/^[a-f0-9]{32}$/D',$id))throw new InvalidArgumentException('Yükleme numarası geçersiz.');$root=migration_root().'/transfers';if(!is_dir($root)&&!mkdir($root,0700))throw new RuntimeException('Yükleme klasörü oluşturulamadı.');return $root.'/'.$id;}
function migration_transfer_store(array $t):void {$p=migration_transfer_dir($t['id']).'/upload.json';$tmp=$p.'.tmp';$s=json_encode($t,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);if(file_put_contents($tmp,$s,LOCK_EX)!==strlen($s)||!rename($tmp,$p))throw new RuntimeException('Yükleme ilerlemesi kaydedilemedi.');chmod($p,0600);}
function migration_transfer_load(string $id,int $owner):array {$p=migration_transfer_dir($id).'/upload.json';$t=is_file($p)?json_decode(file_get_contents($p),true):null;if(!$t||$t['owner']!==$owner)throw new InvalidArgumentException('Yükleme bulunamadı veya hesabınıza ait değil.');return $t;}
function migration_transfer_response(array $t):array {return ['ok'=>true,'upload'=>$t['id'],'offset'=>$t['offset'],'size'=>$t['size'],'done'=>$t['state']==='complete','job'=>$t['job']?:null,'redirect'=>$t['job']?url('/panel/tasima',['job'=>$t['job']]):null,'kind'=>$t['kind'],'state'=>$t['state']];}
function migration_transfer_begin(int $owner):array {
    $kind=text_input('kind',10,true);$name=text_input('name',255,true);$key=text_input('client_key',1500,true);$jobId=text_input('job',32);$path=text_input('path',1000);$sizeRaw=$_POST['size']??'';
    if(!is_string($sizeRaw)||!ctype_digit($sizeRaw)||($size=filter_var($sizeRaw,FILTER_VALIDATE_INT))===false||$size<1)throw new InvalidArgumentException('Dosya boş veya boyutu geçersiz.');
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));$types=['sql'=>['sql'],'zip'=>['zip'],'image'=>['jpg','jpeg','png','gif','webp']];if(!isset($types[$kind])||!in_array($ext,$types[$kind],true))throw new InvalidArgumentException('Dosya biçimi desteklenmiyor.');
    if($kind==='sql'&&$jobId!=='')throw new InvalidArgumentException('SQL için yeni bir aktarım açın.');
    if($kind!=='sql'){$job=migration_load($jobId,$owner);if(!in_array($job['stage'],['mapping','preview'],true))throw new InvalidArgumentException('Önce SQL incelemesini tamamlayın.');}
    if($kind==='image'){$path=migration_safe_image_path($path?:$name);if(!in_array(strtolower(pathinfo($path,PATHINFO_EXTENSION)),$types['image'],true))throw new InvalidArgumentException('Görsel yolu geçersiz.');}
    $id=substr(hash('sha256',$owner.'|'.$kind.'|'.$jobId.'|'.$key),0,32);$dir=migration_transfer_dir($id);
    if(!is_dir($dir)&&!mkdir($dir,0700)&&!is_dir($dir))throw new RuntimeException('Yükleme klasörü oluşturulamadı.');
    $h=fopen($dir.'/upload.lock','c');if(!$h||!flock($h,LOCK_EX|LOCK_NB)){if($h)fclose($h);throw new InvalidArgumentException('Bu dosya yükleniyor. Tekrar deneyin.');}
    try{
        if(is_file($dir.'/upload.json')){$t=migration_transfer_load($id,$owner);foreach(['kind'=>$kind,'name'=>$name,'path'=>$path,'size'=>$size] as $k=>$v)if($t[$k]!==$v)throw new InvalidArgumentException('Devam edilen dosyanın bilgileri değişti.');return $t;}
        $t=['id'=>$id,'owner'=>$owner,'kind'=>$kind,'name'=>$name,'path'=>$path,'size'=>$size,'job'=>$jobId,'offset'=>0,'state'=>'uploading','updated'=>time()];migration_transfer_store($t);return $t;
    }finally{flock($h,LOCK_UN);fclose($h);}
}
function migration_transfer_chunk(array $t):array {
    if($t['state']!=='uploading')return $t;
    $file=$_FILES['chunk_file']??null;$raw=$_POST['offset']??'';
    if(!is_string($raw)||!ctype_digit($raw)||filter_var($raw,FILTER_VALIDATE_INT)===false)throw new InvalidArgumentException('Parça sırası geçersiz.');$offset=(int)$raw;
    if(!$file||($file['error']??null)!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name']))throw new InvalidArgumentException('Parça yüklenemedi. PHP yükleme ayarlarını veya bağlantıyı kontrol edin.');$size=filesize($file['tmp_name']);if(!$size||$size>migration_upload_budget())throw new InvalidArgumentException('Yükleme parçası sunucu isteği sınırını aşıyor.');
    $digest=hash_file('sha256',$file['tmp_name']);if($offset==($t['last_offset']??-1)&&$size===($t['last_size']??0)&&hash_equals($t['last_hash']??'',$digest))return $t;
    if($offset!==$t['offset']||$size>$t['size']-$offset)throw new InvalidArgumentException('Parça sırası uyuşmuyor. Aynı dosyayla yüklemeyi yeniden deneyin; kaldığı yerden devam eder.');
    $path=migration_transfer_dir($t['id']).'/payload.part';$out=fopen($path,'c+b');$in=fopen($file['tmp_name'],'rb');if(!$out||!$in)throw new RuntimeException('Dosya parçası yazılamadı.');
    try{if(!ftruncate($out,$offset)||fseek($out,$offset)!==0||stream_copy_to_stream($in,$out)!==$size)throw new RuntimeException('Disk yazma hatası. Yeterli alanı kontrol edin.');fflush($out);}finally{fclose($out);fclose($in);}chmod($path,0600);
    $t['last_offset']=$offset;$t['last_size']=$size;$t['last_hash']=$digest;$t['offset']+=$size;$t['updated']=time();migration_transfer_store($t);return $t;
}
function migration_transfer_finish(array $t,int $owner):array {
    if($t['state']!=='uploading')return $t;if($t['offset']!==$t['size'])throw new InvalidArgumentException('Dosyanın bütün parçaları henüz yüklenmedi.');$payload=migration_transfer_dir($t['id']).'/payload.part';
    if($t['kind']==='sql'){
        $id=$t['id'];$dir=migration_dir($id);if(is_file($dir.'/job.json'))$job=migration_load($id,$owner);else{
            if(!is_dir($dir)&&!mkdir($dir,0700))throw new RuntimeException('Aktarım klasörü oluşturulamadı.');$source=$dir.'/source.sql';if(is_file($payload)&&!rename($payload,$source))throw new RuntimeException('SQL kaydedilemedi.');if(!is_file($source)||filesize($source)!==$t['size'])throw new RuntimeException('SQL parçaları tamamlanmadı.');
            $job=['id'=>$id,'owner'=>$owner,'created_at'=>date('Y-m-d H:i:s'),'filename'=>$t['name'],'hash'=>hash_file('sha256',$source),'tables'=>[],'stage'=>'analyzing','mapping'=>[],'images'=>[],'cursor'=>0,'parse_offset'=>0,'imported'=>0,'duplicates'=>0,'skipped'=>0,'missing_images'=>0];migration_store($job);
        }$t['job']=$id;$t['state']='complete';
    }elseif($t['kind']==='image'){
        $job=migration_load($t['job'],$owner);$job['images']=array_merge($job['images'],migration_save_images([['file'=>$payload,'path'=>$t['path']]],$job));migration_store($job);$t['state']='complete';migration_transfer_store($t);if(is_file($payload))unlink($payload);return $t;
    }else{$info=migration_zip_info($payload);$t['state']='extracting';$t['zip_cursor']=$info['offset'];$t['zip_end']=$info['end'];$t['zip_count']=$info['count'];$t['zip_images_before']=count(migration_load($t['job'],$owner)['images']);}
    migration_transfer_store($t);return $t;
}
function migration_transfer_dispatch(string $action,array $currentUser):bool {
    if(!in_array($action,['dosya-baslat','dosya-parca','dosya-bitir','dosya-sil','arsiv-devam','incele'],true))return false;
    $locks=[];
    try{
        if(!is_post()){http_response_code(405);throw new InvalidArgumentException('Yükleme için POST gerekiyor.');}verify_csrf();$owner=(int)$currentUser['id'];
        if($action==='incele'){$id=text_input('job',32,true);$job=migration_load($id,$owner);$lock=fopen(migration_dir($id).'/job.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new InvalidArgumentException('Bu aktarım çalışıyor. Tekrar deneyin.');$locks[]=$lock;$job=migration_analyze($job);$result=['ok'=>true,'job'=>$id,'done'=>$job['stage']!=='analyzing','offset'=>$job['parse_offset']??filesize(migration_dir($id).'/source.sql'),'size'=>filesize(migration_dir($id).'/source.sql'),'records'=>array_sum(array_column($job['tables'],'count')),'redirect'=>url('/panel/tasima',['job'=>$id])];}
        else{
            if($action==='dosya-baslat'){$t=migration_transfer_begin($owner);$result=migration_transfer_response($t);$result['chunk_size']=min(524288,migration_upload_budget());}
            else{$id=text_input('upload',32,true);$t=migration_transfer_load($id,$owner);$lock=fopen(migration_transfer_dir($id).'/upload.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new InvalidArgumentException('Bu dosya yükleniyor. Tekrar deneyin.');$locks[]=$lock;$t=migration_transfer_load($id,$owner);
                if($t['job']&&$action!=='dosya-sil'){$job=migration_load($t['job'],$owner);if(!in_array($job['stage'],['mapping','preview'],true)&&$t['state']!=='complete')throw new InvalidArgumentException('Görselleri aktarımı başlatmadan önce yükleyin.');$lock=fopen(migration_dir($job['id']).'/job.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new InvalidArgumentException('Bu aktarım çalışıyor. Tekrar deneyin.');$locks[]=$lock;}
                if($action==='dosya-sil'){foreach(glob(migration_transfer_dir($id).'/*')?:[] as $file)if(is_file($file)&&basename($file)!=='upload.lock')unlink($file);$t['state']='complete';$t['offset']=0;}
                elseif($action==='dosya-parca')$t=migration_transfer_chunk($t);elseif($action==='dosya-bitir')$t=migration_transfer_finish($t,$owner);
                elseif($t['state']==='extracting'){$job=migration_load($t['job'],$owner);$batch=migration_zip_batch(migration_transfer_dir($id).'/payload.part',$job,$t['zip_cursor']);$t['zip_cursor']=$batch['cursor'];$t['zip_seen_image']=($t['zip_seen_image']??false)||$batch['found'];if($batch['done']){$t['state']='complete';if(!($t['zip_seen_image']??false))throw new InvalidArgumentException('ZIP içinde görsel bulunamadı.');}$t['updated']=time();migration_transfer_store($t);if($t['state']==='complete'&&is_file(migration_transfer_dir($id).'/payload.part'))unlink(migration_transfer_dir($id).'/payload.part');}
                $result=migration_transfer_response($t);if(isset($t['zip_end'])){$result['processed']=$t['zip_cursor'];$result['processing_size']=$t['zip_end'];}
            }
        }
    }catch(Throwable $e){if(http_response_code()<400)http_response_code($e instanceof InvalidArgumentException?422:500);if(!$e instanceof InvalidArgumentException&&http_response_code()!==419)log_failure($e);$result=['ok'=>false,'message'=>$e instanceof InvalidArgumentException||http_response_code()===419?$e->getMessage():'Dosya işlenemedi. Sunucunun boş disk alanını ve PHP hata kaydını kontrol edin. Aynı dosyayla tekrar deneyebilirsiniz.'];}
    finally{foreach(array_reverse($locks) as $lock){flock($lock,LOCK_UN);fclose($lock);}}
    header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);return true;
}
function migration_upload_attributes(string $job=''):string {$a=['job'=>$job,'begin'=>url('/panel/tasima/dosya-baslat'),'chunk'=>url('/panel/tasima/dosya-parca'),'finish'=>url('/panel/tasima/dosya-bitir'),'extract'=>url('/panel/tasima/arsiv-devam'),'analyze'=>url('/panel/tasima/incele')];$s='';foreach($a as $k=>$v)$s.=' data-'.$k.'="'.e($v).'"';return $s;}

function migration_pending_uploads(int $owner):array {$items=[];foreach(glob(migration_root(false).'/transfers/*/upload.json')?:[] as $p){$t=json_decode(file_get_contents($p),true);if(($t['owner']??null)===$owner&&($t['state']??'')!=='complete')$items[]=$t;}usort($items,fn($a,$b)=>($b['updated']??0)<=>($a['updated']??0));return $items;}
function migration_forget_transfers(array $job):void {foreach(glob(migration_root(false).'/transfers/*/upload.json')?:[] as $p){$t=json_decode(file_get_contents($p),true);if(($t['owner']??0)!==$job['owner']||($t['job']??'')!==$job['id'])continue;$dir=dirname($p);$h=fopen($dir.'/upload.lock','c');if(!$h||!flock($h,LOCK_EX|LOCK_NB)){if($h)fclose($h);continue;}foreach(glob($dir.'/*')?:[] as $f)if(is_file($f)&&basename($f)!=='upload.lock')unlink($f);flock($h,LOCK_UN);fclose($h);@unlink($dir.'/upload.lock');@rmdir($dir);}}
