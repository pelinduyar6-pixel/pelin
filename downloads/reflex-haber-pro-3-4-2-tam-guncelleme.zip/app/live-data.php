<?php
declare(strict_types=1);
function live_schema(PDO $pdo,string $driver):void {
    $tail=$driver==='sqlite'?'':' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $id=$driver==='sqlite'?'INTEGER PRIMARY KEY AUTOINCREMENT':'INT UNSIGNED AUTO_INCREMENT PRIMARY KEY';
    $pdo->exec('CREATE TABLE IF NOT EXISTS rh6_live_visitors (visitor VARCHAR(64) PRIMARY KEY,page_route VARCHAR(500) NOT NULL,page_title VARCHAR(255) NOT NULL,kind VARCHAR(12) NOT NULL,last_seen INTEGER NOT NULL)'.$tail);
    $pdo->exec('CREATE TABLE IF NOT EXISTS rh6_live_views (id '.$id.',viewed_at INTEGER NOT NULL)'.$tail);
    foreach(['rh6_live_visitors'=>'last_seen','rh6_live_views'=>'viewed_at'] as $table=>$column){
        $indexes=$driver==='sqlite'?array_column(Database::rows('PRAGMA index_list('.$table.')'),'name'):array_column(Database::rows('SHOW INDEX FROM '.$table),'Key_name');
        if(!in_array($table.'_time',$indexes,true))$pdo->exec('CREATE INDEX '.$table.'_time ON '.$table.' ('.$column.')');
    }
}
function live_touch(string $visitor,array $page,?int $now=null):void {
    $now??=time();$values=[$page['route'],$page['title'],$page['kind'],$now,$visitor];
    $updated=Database::query('UPDATE rh6_live_visitors SET page_route=?,page_title=?,kind=?,last_seen=? WHERE visitor=?',$values)->rowCount();
    if(!$updated){try{Database::query('INSERT INTO rh6_live_visitors (page_route,page_title,kind,last_seen,visitor) VALUES (?,?,?,?,?)',$values);}catch(PDOException $error){if(!in_array((string)$error->getCode(),['23000','23505'],true))throw $error;Database::query('UPDATE rh6_live_visitors SET page_route=?,page_title=?,kind=?,last_seen=? WHERE visitor=?',$values);}}
}
function live_capture(string $route,string $title,string $kind='other',?int $now=null):void {
    if(is_post()||user())return;
    $page=['route'=>mb_substr($route,0,500),'title'=>mb_substr(strip_tags($title),0,255),'kind'=>$kind];
    $_SESSION['live_pages'][$page['route']]=$page;$_SESSION['live_pages']=array_slice($_SESSION['live_pages'],-20,null,true);
    try{live_touch(visitor_hash(),$page,$now);Database::query('INSERT INTO rh6_live_views (viewed_at) VALUES (?)',[$now??time()]);}catch(Throwable $error){log_failure($error);}
}
function live_heartbeat(string $route,?int $now=null):bool {
    if(user())return false;
    $page=$_SESSION['live_pages'][$route]??null;
    if(!is_array($page))throw new InvalidArgumentException('Önce ziyaretçi sayfasını açın.');
    $now??=time();if($now-(int)($_SESSION['live_last_ping']??0)<10)return true;
    live_touch(visitor_hash(),$page,$now);$_SESSION['live_last_ping']=$now;return true;
}
function live_snapshot(?int $now=null):array {
    $now??=time();Database::query('DELETE FROM rh6_live_visitors WHERE last_seen<?',[$now-86400]);Database::query('DELETE FROM rh6_live_views WHERE viewed_at<?',[$now-86400]);
    $groups=['article'=>0,'home'=>0,'other'=>0];foreach(Database::rows('SELECT kind,COUNT(*) AS total FROM rh6_live_visitors WHERE last_seen>=? GROUP BY kind',[$now-300]) as $row)$groups[$row['kind']]=(int)$row['total'];
    $pages=Database::rows('SELECT page_route,page_title,kind,COUNT(*) AS total FROM rh6_live_visitors WHERE last_seen>=? GROUP BY page_route,page_title,kind ORDER BY total DESC,page_title LIMIT 8',[$now-300]);
    foreach($pages as &$page){$page['total']=(int)$page['total'];$page['url']=url($page['page_route']);}unset($page);
    return ['visitors'=>array_sum($groups),'article'=>$groups['article'],'home'=>$groups['home'],'other'=>$groups['other'],'views_30m'=>(int)Database::scalar('SELECT COUNT(*) FROM rh6_live_views WHERE viewed_at>=?',[$now-1800]),'pages'=>$pages,'updated'=>date('H:i:s',$now)];
}
