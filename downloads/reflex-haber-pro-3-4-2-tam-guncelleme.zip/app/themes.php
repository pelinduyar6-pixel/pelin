<?php
declare(strict_types=1);

/** One catalog for the panel, validation and public routing. */
function theme_catalog(): array {
    return [
        '1'=>['name'=>'Demo 6','hint'=>'Klasik manşet ve sağ haber sütunu','layout'=>'editorial'],
        '2'=>['name'=>'Demo 8','hint'=>'Ortada manşet, iki yanda haber kartları','layout'=>'showcase'],
        '3'=>['name'=>'Demo 5','hint'=>'Kırmızı menü ve geniş manşet','layout'=>'mosaic'],
        '4'=>['name'=>'Demo 1','hint'=>'Vitrin banner ve beşli haber şeridi','layout'=>'compact'],
        '5'=>['name'=>'Medyabar','hint'=>'Manşet yanında yayın akışı, geniş haber kartları','layout'=>'editorial'],
        '6'=>['name'=>'İmza Gazetesi','hint'=>'Gazete düzeni, ortalanmış marka ve çift vitrin','layout'=>'editorial'],
        '7'=>['name'=>'Kulga','hint'=>'Üç parçalı haber vitrini ve renkli kategori blokları','layout'=>'mosaic'],
        '8'=>['name'=>'EsenHaber Demo 3','hint'=>'Bölünmüş manşet, yatay numaralar ve dörtlü haber şeridi','layout'=>'showcase'],
    ];
}

function active_theme(): string {
    $theme=setting('theme_style','1');
    return array_key_exists($theme,theme_catalog())?$theme:'1';
}
