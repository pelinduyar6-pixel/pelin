<?php
declare(strict_types=1);
function record_filters(string $table,string $module,array $input):array{
    $where=[];$params=[];$query=[];
    foreach(['q','status','kind','category'] as $key)if(isset($input[$key])&&!is_string($input[$key]))throw new InvalidArgumentException('Filtre değeri geçersiz.');
    if(($q=trim(mb_substr($input['q']??'',0,100)))!==''){$where[]=($table==='news'||$table==='pages'?'title':($table==='comments'?'body':'name')).' LIKE ?';$params[]='%'.$q.'%';$query['q']=$q;}
    if($table==='news'){
        if($module==='makaleler'){$where[]='kind=?';$params[]='opinion';}
        elseif(in_array($input['kind']??'',['article','gallery','video','opinion'],true)){$where[]='kind=?';$params[]=$query['kind']=$input['kind'];}
        if(in_array($input['status']??'',['draft','published','scheduled'],true)){$where[]='status=?';$params[]=$query['status']=$input['status'];}
        if(($input['category']??'')!==''){if(!ctype_digit($input['category']))throw new InvalidArgumentException('Kategori filtresi geçersiz.');$where[]='category_id=?';$params[]=(int)$input['category'];$query['category']=$input['category'];}
    }
    return [$where?' WHERE '.implode(' AND ',$where):'',$params,$query];
}
function delete_records(string $table,array $ids,array $currentUser):int{
    if(!in_array($table,['news','users','categories','ads','pages','comments'],true))throw new InvalidArgumentException('Geçersiz kayıt türü.');
    if(!$ids)return 0;$marks=implode(',',array_fill(0,count($ids),'?'));$records=Database::rows('SELECT * FROM rh6_'.$table.' WHERE id IN ('.$marks.')',$ids);
    if($table==='users'){
        foreach($records as $record)if((int)$record['id']===(int)$currentUser['id'])throw new InvalidArgumentException('Kendi hesabınızı silemezsiniz.');
        $admins=(int)Database::scalar("SELECT COUNT(*) FROM rh6_users WHERE role='admin' AND active=1");$removed=count(array_filter($records,fn($r)=>$r['role']==='admin'&&$r['active']));if($admins-$removed<1)throw new InvalidArgumentException('En az bir aktif yönetici kalmalı.');
    }
    if($table==='news'){Database::query('DELETE FROM rh6_comments WHERE news_id IN ('.$marks.')',$ids);Database::query('DELETE FROM rh6_reactions WHERE news_id IN ('.$marks.')',$ids);}
    if($table==='categories')Database::query('UPDATE rh6_news SET category_id=NULL WHERE category_id IN ('.$marks.')',$ids);
    if($table==='users'){Database::query('UPDATE rh6_news SET author_id=NULL WHERE author_id IN ('.$marks.')',$ids);Database::query('UPDATE rh6_news SET editor_id=NULL WHERE editor_id IN ('.$marks.')',$ids);}
    Database::query('DELETE FROM rh6_'.$table.' WHERE id IN ('.$marks.')',$ids);return count($records);
}
function bulk_records(string $table,string $module,array $currentUser):never{
    verify_csrf();$operation=text_input('bulk_operation',20,true);$scope=text_input('scope',20,true);
    if(!in_array($operation,['delete','publish','draft','activate','deactivate'],true)||!in_array($scope,['selected','all'],true))throw new InvalidArgumentException('Toplu işlem geçersiz.');
    if($operation==='delete'&&text_input('delete_confirmation',10)!=='SİL')throw new InvalidArgumentException('Silme işlemini SİL yazarak onaylayın.');
    if(($scope==='all'||$table!=='news')&&$currentUser['role']!=='admin') {http_response_code(403);throw new InvalidArgumentException('Bu toplu işlem için yönetici yetkisi gerekiyor.');}
    if(in_array($operation,['publish','draft'],true)&&$table!=='news'||in_array($operation,['activate','deactivate'],true)&&!in_array($table,['ads','pages'],true))throw new InvalidArgumentException('Bu kayıt türünde işlem desteklenmiyor.');
    [$filter,$params,$query]=record_filters($table,$module,$_POST);$pdo=Database::connection();$pdo->beginTransaction();
    try{
        if($scope==='all'){
            if($table==='users'){$filter.=($filter?' AND':' WHERE')." role<>'admin' AND id<>?";$params[]=(int)$currentUser['id'];}
            $count=(int)Database::scalar('SELECT COUNT(*) FROM rh6_'.$table.$filter,$params);if($count!==integer_input('expected_total'))throw new InvalidArgumentException('Kayıt sayısı değişti. Listeyi yenileyip işlemi tekrar onaylayın.');
        }else{
            $ids=$_POST['selected']??[];if(!is_array($ids)||!$ids||count($ids)>500)throw new InvalidArgumentException('1–500 kayıt seçin.');foreach($ids as $id)if(!is_string($id)||!ctype_digit($id)||strlen($id)>10||(int)$id<1)throw new InvalidArgumentException('Kayıt seçimi geçersiz.');$ids=array_values(array_unique(array_map('intval',$ids)));$filter.=($filter?' AND':' WHERE').' id IN ('.implode(',',array_fill(0,count($ids),'?')).')';$params=array_merge($params,$ids);
        }
        $affected=0;
        // Bounded chunks avoid database parameter limits; all-module actions remain one transaction.
        while(true){$chunk=Database::rows('SELECT id FROM rh6_'.$table.$filter.($filter?' AND':' WHERE').' id>? ORDER BY id LIMIT 200',array_merge($params,[$last??0]));if(!$chunk)break;$ids=array_map('intval',array_column($chunk,'id'));$last=max($ids);$marks=implode(',',array_fill(0,count($ids),'?'));
            if($operation==='delete')$affected+=delete_records($table,$ids,$currentUser);
            elseif(in_array($operation,['publish','draft'],true)){if($operation==='publish')Database::query("UPDATE rh6_news SET status='published',published_at=CASE WHEN published_at IS NULL OR published_at>? THEN ? ELSE published_at END,updated_at=? WHERE id IN (".$marks.')',array_merge([date('Y-m-d H:i:s'),date('Y-m-d H:i:s'),date('Y-m-d H:i:s')],$ids));else Database::query("UPDATE rh6_news SET status='draft',updated_at=? WHERE id IN (".$marks.')',array_merge([date('Y-m-d H:i:s')],$ids));$affected+=count($ids);}
            else{Database::query('UPDATE rh6_'.$table.' SET active=? WHERE id IN ('.$marks.')',array_merge([$operation==='activate'?1:0],$ids));$affected+=count($ids);}
        }
        $pdo->commit();flash($affected.' kayıt için toplu işlem tamamlandı.');redirect('/panel/'.$module,$query);
    }catch(Throwable $ex){if($pdo->inTransaction())$pdo->rollBack();throw $ex;}
}
