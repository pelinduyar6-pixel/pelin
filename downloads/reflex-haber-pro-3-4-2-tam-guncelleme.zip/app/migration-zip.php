<?php
declare(strict_types=1);
function migration_read_exact($h,int $length):string {$s='';while(strlen($s)<$length&&!feof($h)){$x=fread($h,$length-strlen($s));if($x===false||$x==='')break;$s.=$x;}if(strlen($s)!==$length)throw new InvalidArgumentException('ZIP dosyası eksik veya bozuk.');return $s;}
function migration_u64(string $bytes):int {$v=unpack('P',$bytes)[1];if(!is_int($v)||$v<0)throw new InvalidArgumentException('ZIP kaydının boyutu sunucuda temsil edilemiyor.');return $v;}
function migration_zip_info(string $archive):array {
    $h=fopen($archive,'rb');if(!$h)throw new InvalidArgumentException('ZIP okunamadı.');
    try{$length=filesize($archive);fseek($h,max(0,$length-65557));$tail=fread($h,65557);$at=strrpos($tail,"PK\x05\x06");if($at===false||strlen($tail)-$at<22)throw new InvalidArgumentException('Standart bir ZIP dosyası kullanın.');$v=unpack('vdisk/vstart/vdisk_count/vcount/Vsize/Voffset/vcomment',substr($tail,$at+4,18));$end=max(0,$length-65557)+$at;
        if($end+22+$v['comment']!==$length||$v['disk']!==0||$v['start']!==0||$v['disk_count']!==$v['count'])throw new InvalidArgumentException('Çok parçalı veya bozuk ZIP desteklenmiyor.');
        if($v['count']===65535||$v['size']===4294967295||$v['offset']===4294967295){fseek($h,$end-20);$locator=migration_read_exact($h,20);if(substr($locator,0,4)!=="PK\x06\x07"||unpack('V',substr($locator,4,4))[1]!==0||unpack('V',substr($locator,16,4))[1]!==1)throw new InvalidArgumentException('ZIP64 dizini bozuk.');fseek($h,migration_u64(substr($locator,8,8)));$z=migration_read_exact($h,56);if(substr($z,0,4)!=="PK\x06\x06"||unpack('V',substr($z,16,4))[1]!==0||unpack('V',substr($z,20,4))[1]!==0||migration_u64(substr($z,24,8))!==migration_u64(substr($z,32,8)))throw new InvalidArgumentException('ZIP64 dizini bozuk.');$v['count']=migration_u64(substr($z,32,8));$v['size']=migration_u64(substr($z,40,8));$v['offset']=migration_u64(substr($z,48,8));}
        if($v['offset']>$length||$v['size']>$length-$v['offset'])throw new InvalidArgumentException('ZIP dizini dosya dışına çıkıyor.');return ['offset'=>$v['offset'],'end'=>$v['offset']+$v['size'],'count'=>$v['count']];
    }finally{fclose($h);}
}
function migration_zip_records(string $archive,int $cursor=0):Generator {
    $info=migration_zip_info($archive);$h=fopen($archive,'rb');fseek($h,$cursor?:$info['offset']);
    try{while(ftell($h)<$info['end']){$raw=migration_read_exact($h,46);if(substr($raw,0,4)!=="PK\x01\x02")throw new InvalidArgumentException('ZIP dizini bozuk.');$v=unpack('vmade/vneeded/vflags/vmethod/vtime/vdate/Vcrc/Vcompressed/Vsize/vname/vextra/vcomment/vdisk/vinternal/Vattributes/Vlocal',substr($raw,4));$name=migration_read_exact($h,$v['name']);$extra=migration_read_exact($h,$v['extra']);migration_read_exact($h,$v['comment']);
            if(($v['flags']&1)||!in_array($v['method'],[0,8],true)||(($v['attributes']>>16)&0170000)===0120000||$v['disk']!==0||$name==='')throw new InvalidArgumentException('ZIP içinde şifreli, bağlantı veya desteklenmeyen kayıt var.');
            for($i=0;$i+4<=strlen($extra);){$e=unpack('vid/vlength',substr($extra,$i,4));$data=substr($extra,$i+4,$e['length']);if($e['id']===1){$j=0;foreach(['size','compressed','local'] as $key)if($v[$key]===4294967295){if($j+8>strlen($data))throw new InvalidArgumentException('ZIP64 kaydı eksik.');$v[$key]=migration_u64(substr($data,$j,8));$j+=8;}}$i+=4+$e['length'];}
            if($v['local']>filesize($archive)||$v['compressed']>filesize($archive)-$v['local'])throw new InvalidArgumentException('ZIP kaydı dosya dışına çıkıyor.');$v['path']=migration_safe_image_path($name);$v['directory']=str_ends_with($name,'/');$v['cursor']=ftell($h);yield $v;
        }return $info['end'];
    }finally{fclose($h);}
}
function migration_zip_extract(string $archive,array $record,string $target):void {
    $free=disk_free_space(dirname($target));if($free!==false&&$record['size']>$free)throw new RuntimeException('Görseli açmak için yeterli disk alanı yok.');
    $in=fopen($archive,'rb');$out=fopen($target,'wb');if(!$in||!$out)throw new RuntimeException('ZIP görseli yazılamadı.');
    try{fseek($in,$record['local']);$local=migration_read_exact($in,30);if(substr($local,0,4)!=="PK\x03\x04")throw new InvalidArgumentException('ZIP yerel kaydı bozuk.');$sizes=unpack('vname/vextra',substr($local,26,4));$name=migration_read_exact($in,$sizes['name']);migration_read_exact($in,$sizes['extra']);if(migration_safe_image_path($name)!==$record['path'])throw new InvalidArgumentException('ZIP dosya yolları uyuşmuyor.');if(ftell($in)+$record['compressed']>filesize($archive))throw new InvalidArgumentException('ZIP verisi eksik.');
        $left=$record['compressed'];$written=0;$crc=hash_init('crc32b');$inflate=$record['method']===8?inflate_init(ZLIB_ENCODING_RAW):null;
        do{$n=min(2048,$left);$data=migration_read_exact($in,$n);$left-=$n;if($inflate!==null){$data=inflate_add($inflate,$data,$left?ZLIB_SYNC_FLUSH:ZLIB_FINISH);if($data===false)throw new InvalidArgumentException('ZIP sıkıştırılmış verisi bozuk.');}$written+=strlen($data);if($written>$record['size'])throw new InvalidArgumentException('ZIP açılmış boyutu dizinle uyuşmuyor.');hash_update($crc,$data);if(fwrite($out,$data)!==strlen($data))throw new RuntimeException('Disk yazma hatası.');}while($left>0);
        if($written!==$record['size']||hash_final($crc)!==str_pad(dechex($record['crc']),8,'0',STR_PAD_LEFT)||($inflate!==null&&inflate_get_status($inflate)!==ZLIB_STREAM_END))throw new InvalidArgumentException('ZIP bütünlük kontrolü başarısız.');
    }finally{fclose($in);fclose($out);}
}
function migration_zip_batch(string $archive,array &$job,int $cursor=0):array {
    $start=microtime(true);$n=0;$done=true;$next=$cursor;$images=[];$scratch=migration_dir($job['id']).'/extract-image.tmp';
    try{foreach(migration_zip_records($archive,$cursor) as $r){$next=$r['cursor'];if(!$r['directory']&&preg_match('/\.(jpe?g|png|gif|webp)$/i',$r['path'])){migration_zip_extract($archive,$r,$scratch);$images=array_merge($images,migration_save_images([['file'=>$scratch,'path'=>$r['path']]],$job));unlink($scratch);}if(++$n>=30||microtime(true)-$start>1.5){$done=false;break;}}$job['images']=array_merge($job['images'],$images);migration_store($job);return ['cursor'=>$next,'done'=>$done,'images'=>count($job['images']),'found'=>count($images)>0];}finally{if(is_file($scratch))unlink($scratch);}
}
