<?php
declare(strict_types=1);
function command_public(string $route):bool{
    if($route==='/api/veriler'){
        if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){http_response_code(405);header('Allow: GET');return true;}
        require_once __DIR__.'/integrations.php';public_rate_limit('public-data',30,60);session_write_close();
        refresh_markets();refresh_sports();$markets=[];$times=json_decode(setting('market_field_times','{}'),true)?:[];
        foreach(market_fields() as $key=>$label)$markets[$key]=['value'=>setting($key),'change'=>setting($key.'_change'),'updated'=>$times[$key]??''];
        header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode(['markets'=>$markets,'market_updated'=>setting('market_updated'),'btc_unit'=>setting('market_btc_unit','TRY'),'teams'=>json_decode(setting('sports_standings','[]'),true)?:[],'sports_updated'=>setting('sports_updated'),'sports_mode'=>setting('sports_mode')],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);return true;
    }
    if($route==='/anket/oy'){
        if(!is_post()){http_response_code(405);throw new InvalidArgumentException('Oy vermek için anket formunu kullanın.');}verify_csrf();public_rate_limit('poll',20,60);$id=integer_input('item_id');$rawChoice=$_POST['choice']??null;if(!is_scalar($rawChoice)||filter_var($rawChoice,FILTER_VALIDATE_INT)===false)throw new InvalidArgumentException('Geçerli seçenek seçin.');$choice=(int)$rawChoice;$poll=Database::row("SELECT * FROM rh6_module_items WHERE id=? AND module='anket' AND status='published' AND (ends_at IS NULL OR ends_at>=?)",[$id,date('Y-m-d H:i:s')]);if(!$poll||!module_enabled('anket')){http_response_code(404);throw new InvalidArgumentException('Anket bulunamadı veya oylama kapandı.');}$options=json_decode($poll['data'],true)['options']??[];if(!isset($options[$choice]))throw new InvalidArgumentException('Geçerli seçenek seçin.');$visitor=visitor_hash();$vote=Database::row('SELECT id FROM rh6_poll_votes WHERE item_id=? AND visitor_hash=?',[$id,$visitor]);if($vote)Database::save('poll_votes',['choice'=>$choice],(int)$vote['id']);else{try{Database::save('poll_votes',['item_id'=>$id,'visitor_hash'=>$visitor,'choice'=>$choice,'created_at'=>date('Y-m-d H:i:s')]);}catch(PDOException $ex){if((string)$ex->getCode()!=='23000')throw $ex;Database::query('UPDATE rh6_poll_votes SET choice=? WHERE item_id=? AND visitor_hash=?',[$choice,$id,$visitor]);}}flash('Oyunuz kaydedildi.');redirect('/modul/anket/'.$poll['slug']);
    }
    $screen='';$heading='';$error='';$moduleItem=null;$moduleItems=[];$type='';
    if(in_array($route,['/iletisim','/sayfa/iletisim'],true)){
        if(setting('contact_enabled','1')!=='1'){http_response_code(404);throw new InvalidArgumentException('İletişim formu şu anda kapalı.');}$heading='İletişim';$screen='contact';
        if(is_post()){
            try{verify_csrf();if(!empty($_POST['website']))throw new InvalidArgumentException('Mesaj gönderilemedi.');if(!checked_input('consent'))throw new InvalidArgumentException('Mesajın işlenmesi için onay kutusunu işaretleyin.');public_rate_limit('contact',5,900);$email=text_input('email',190,true);if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new InvalidArgumentException('Geçerli e-posta adresi girin.');Database::save('contacts',['name'=>text_input('name',100,true),'email'=>$email,'subject'=>text_input('subject',150,true),'message'=>text_input('message',5000,true),'status'=>'new','created_at'=>date('Y-m-d H:i:s')]);flash('Mesajınız yayın ekibine ulaştı. Teşekkür ederiz.');redirect('/iletisim');}catch(InvalidArgumentException $ex){$error=$ex->getMessage();if(http_response_code()<400)http_response_code(422);}
        }
    }elseif($route==='/moduller'){$screen='public-modules';$heading='Yaşam & içerik modülleri';}
    elseif(preg_match('~^/modul/([a-z-]+)(?:/([^/]+))?$~',$route,$match)){
        $type=$match[1];$definition=module_definitions()[$type]??null;if(!$definition||!module_enabled($type)){http_response_code(404);throw new InvalidArgumentException('Modül bulunamadı.');}$heading=$definition[0];$screen='public-module';
        if(isset($match[2])){$moduleItem=Database::row("SELECT * FROM rh6_module_items WHERE module=? AND slug=? AND status='published' AND (ends_at IS NULL OR ends_at>=?)",[$type,$match[2],date('Y-m-d H:i:s')]);if(!$moduleItem){http_response_code(404);throw new InvalidArgumentException('İçerik bulunamadı veya yayını sona erdi.');}$heading=$moduleItem['title'];if($type==='anket')$pollVisitor=visitor_hash();}
        else $moduleItems=Database::rows("SELECT * FROM rh6_module_items WHERE module=? AND status='published' AND (ends_at IS NULL OR ends_at>=?) ORDER BY id DESC LIMIT 100",[$type,date('Y-m-d H:i:s')]);
    }else return false;
    $categories=Database::rows('SELECT * FROM rh6_categories ORDER BY sort_order,id');$ticker=news_rows('AND n.is_breaking=1',[],8);$pageTitle=$heading.' · '.setting('site_name');$description=$moduleItem['summary']??setting('description');$canonical=absolute_url(url($route==='/sayfa/iletisim'?'/iletisim':$route));$ogImage=absolute_url(media($moduleItem['image']??setting('theme_logo')));$isArticle=false;track_view();
    view('site-header',get_defined_vars());view($screen,get_defined_vars());view('site-footer');return true;
}
