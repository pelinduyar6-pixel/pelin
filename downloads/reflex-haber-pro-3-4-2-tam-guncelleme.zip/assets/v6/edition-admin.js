(() => {
  'use strict';
  let trigger = null;
  const menu = document.createElement('div');
  menu.id = 'news-share-menu'; menu.className = 'news-share-menu';
  menu.setAttribute('role', 'menu'); menu.setAttribute('aria-label', 'Haberi paylaş'); menu.hidden = true;
  document.body.append(menu);
  const icons = {
    facebook: '<path d="M14 22v-9h3l.5-4H14V7c0-1 .3-2 2-2h2V1h-3c-4 0-5 2-5 6v2H7v4h3v9z"/>',
    x: '<path d="M3 3h4l14 18h-4zM20 3 4 21" fill="none" stroke="currentColor" stroke-width="2"/>',
    whatsapp: '<path d="M4 20l1-4a9 9 0 1 1 4 4z" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M8 7c-2 3 2 7 6 9l2-2-3-2-1 1-2-2 1-1z"/>',
    telegram: '<path d="M2 11 22 3l-4 19-7-6 7-8-10 6z"/>',
    linkedin: '<circle cx="5" cy="5" r="2"/><path d="M3 9h4v12H3zm7 0h4v2c4-4 8-1 8 3v7h-4v-7c0-3-4-3-4 0v7h-4z"/>',
    pinterest: '<path d="M8 22l2-9c-4-5 4-10 5-5 1 4-3 7-4 3l-2 7c12 5 19-18 4-18C1 0 0 14 6 17l1-3C0 5 17-5 18 8c1 5-3 8-5 7L10 22z"/>',
    reddit: '<ellipse cx="12" cy="15" rx="9" ry="6" fill="none" stroke="currentColor" stroke-width="2"/><path d="m12 9 2-6 5 1" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="20" cy="4" r="2"/><circle cx="8" cy="14" r="1.5"/><circle cx="16" cy="14" r="1.5"/><path d="M8 17q4 3 8 0" fill="none" stroke="currentColor"/>',
    mail: '<rect x="2" y="5" width="20" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m3 6 9 7 9-7" fill="none" stroke="currentColor" stroke-width="1.8"/>',
    copy: '<rect x="8" y="8" width="13" height="13" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M16 8V3H3v13h5" fill="none" stroke="currentColor" stroke-width="1.8"/>'
  };
  const icon = name => { const span = document.createElement('span'); span.className = 'share-brand share-' + name; span.setAttribute('aria-hidden', 'true'); span.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor">' + icons[name] + '</svg>'; return span; };
  function close(refocus = false) { if (!trigger) return; const old = trigger; old.setAttribute('aria-expanded', 'false'); trigger = null; menu.hidden = true; if (refocus) old.focus(); }
  function position() {
    if (!trigger) return;
    const r = trigger.getBoundingClientRect(), width = Math.min(240, innerWidth - 24);
    if (r.bottom < 0 || r.top > innerHeight) { close(); return; }
    menu.style.width = width + 'px'; menu.style.maxHeight = (innerHeight - 24) + 'px';
    const height = menu.offsetHeight;
    const top = innerHeight - r.bottom >= height + 8 ? r.bottom + 8 : r.top - height - 8;
    menu.style.left = Math.max(12, Math.min(r.left, innerWidth - width - 12)) + 'px';
    menu.style.top = Math.max(12, Math.min(top, innerHeight - height - 12)) + 'px';
  }
  document.querySelectorAll('[data-share-url]').forEach(button => {
    button.setAttribute('aria-controls', menu.id);
    button.addEventListener('click', () => {
      if (trigger === button) { close(); return; } close(); trigger = button;
      const url = button.dataset.shareUrl, title = button.dataset.shareTitle || '', u = encodeURIComponent(url), t = encodeURIComponent(title), message = encodeURIComponent(title + '\n' + url);
      const services = [
        ['facebook', 'Facebook', 'https://www.facebook.com/sharer/sharer.php?u=' + u],
        ['x', 'X (Twitter)', 'https://twitter.com/intent/tweet?url=' + u + '&text=' + t],
        ['whatsapp', 'WhatsApp', 'https://api.whatsapp.com/send?text=' + message],
        ['telegram', 'Telegram', 'https://t.me/share/url?url=' + u + '&text=' + t],
        ['linkedin', 'LinkedIn', 'https://www.linkedin.com/sharing/share-offsite/?url=' + u],
        ['pinterest', 'Pinterest', 'https://www.pinterest.com/pin/create/button/?url=' + u + '&description=' + t],
        ['reddit', 'Reddit', 'https://www.reddit.com/submit?url=' + u + '&title=' + t],
        ['mail', 'E-posta', 'mailto:?subject=' + t + '&body=' + message]
      ];
      menu.replaceChildren();
      services.forEach(([name, label, href]) => { const link = document.createElement('a'); link.href = href; link.setAttribute('role', 'menuitem'); link.tabIndex = -1; if (name !== 'mail') { link.target = '_blank'; link.rel = 'noopener noreferrer'; } link.append(icon(name), document.createTextNode(label)); link.addEventListener('click', () => close()); menu.append(link); });
      const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'share-copy'; copy.setAttribute('role', 'menuitem'); copy.tabIndex = -1; copy.append(icon('copy'), document.createTextNode('Linki kopyala'));
      copy.addEventListener('click', async () => { try { await navigator.clipboard.writeText(url); copy.replaceChildren(icon('copy'), document.createTextNode('Kopyalandı')); } catch { prompt('Haber bağlantısını kopyalayın:', url); } }); menu.append(copy);
      menu.hidden = false; button.setAttribute('aria-expanded', 'true'); position(); menu.querySelector('[role=menuitem]').focus();
    });
  });
  menu.addEventListener('keydown', e => { const items = [...menu.querySelectorAll('[role=menuitem]')], index = items.indexOf(document.activeElement); if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) { e.preventDefault(); const next = e.key === 'Home' ? 0 : e.key === 'End' ? items.length - 1 : (index + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length; items[next].focus(); } });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && trigger) { e.preventDefault(); close(true); } });
  document.addEventListener('pointerdown', e => { if (trigger && !menu.contains(e.target) && !trigger.contains(e.target)) close(); });
  document.addEventListener('focusin', e => { if (trigger && !menu.contains(e.target) && e.target !== trigger) close(); });
  addEventListener('resize', position); addEventListener('scroll', position, true);
  document.querySelector('[name=schedule_mode]')?.addEventListener('change', e => { const daily = e.target.value === 'daily'; document.querySelector('[data-daily-schedule]')?.toggleAttribute('hidden', !daily); document.querySelectorAll('[data-interval-schedule]').forEach(label => label.toggleAttribute('hidden', daily)); });
})();
(() => {
  const mapping = document.querySelector('[data-migration-mapping]');
  if (mapping) {
    const columns = JSON.parse(document.getElementById('migration-columns').textContent);
    mapping.querySelectorAll('[data-source-table]').forEach(table => table.addEventListener('change', () => {
      mapping.querySelectorAll(`[data-field-group="${table.dataset.sourceTable}"]`).forEach(select => {
        const old = select.value;
        select.replaceChildren(new Option('Aktarma / boş bırak', ''), ...(columns[table.value] || []).map(column => new Option(column, column)));
        if ((columns[table.value] || []).includes(old)) select.value = old;
      });
    }));
  }
  const form = document.querySelector('[data-migration-continue]');
  if (form) {
    const checkbox = form.querySelector('[data-migration-auto]');
    const key = 'reflex-migration-auto:' + new URL(form.action).searchParams.get('job');
    const schedule = () => { if (checkbox.checked) setTimeout(() => { if (checkbox.checked) form.requestSubmit(); }, 800); };
    checkbox.checked = sessionStorage.getItem(key) === '1';
    checkbox.addEventListener('change', () => { sessionStorage.setItem(key, checkbox.checked ? '1' : '0'); schedule(); });
    if (!document.querySelector('.alert.error')) schedule();
    form.addEventListener('submit', () => { form.querySelector('button').disabled = true; form.querySelector('button').textContent = 'Aktarılıyor…'; });
  }
})();
