/* SQL, ZIP and images use bounded requests; retries resume acknowledged bytes. */
(()=>{'use strict';
 const pretty=n=>{const units=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<units.length-1){n/=1024;i++;}return n.toLocaleString('tr-TR',{maximumFractionDigits:1})+' '+units[i];};
 function post(url,data,onProgress){return new Promise((resolve,reject)=>{const xhr=new XMLHttpRequest();xhr.open('POST',url);xhr.setRequestHeader('Accept','application/json');xhr.timeout=60000;if(onProgress)xhr.upload.onprogress=e=>{if(e.lengthComputable)onProgress(e.loaded/e.total);};xhr.onload=()=>{let result;try{result=JSON.parse(xhr.responseText);}catch{const error=new Error('Sunucu yanıtı okunamadı (HTTP '+xhr.status+'). Oturum veya hosting hata kaydını kontrol edin. Yükleme düğmesiyle tekrar deneyin.');error.retry=xhr.status>=500;return reject(error);}if(xhr.status<200||xhr.status>=300||!result.ok){const error=new Error(result.message||'Yükleme başarısız (HTTP '+xhr.status+').');error.retry=xhr.status>=500;return reject(error);}resolve(result);};xhr.onerror=xhr.ontimeout=()=>{const error=new Error('Bağlantı kesildi veya yanıt gecikti. Aynı dosyayla tekrar deneyin; yüklenen parçalar korunur.');error.retry=true;reject(error);};xhr.send(data);});}
 document.querySelectorAll('.migration-directory-form').forEach(form=>{
  const input=form.querySelector('[data-migration-directory]'),status=form.querySelector('.migration-directory-status'),progress=form.querySelector('progress'),button=form.querySelector('button[type=submit],button:not([type])');if(!status||!progress||!button)return;
  let busy=false,job=form.dataset.job||'',resume='';const original=button.textContent;const supported=f=>/\.(jpe?g|png|gif|webp)$/i.test(f.name);
  if(input)input.addEventListener('change',()=>{const files=[...input.files].filter(supported);status.textContent=files.length+' görsel seçildi · '+pretty(files.reduce((n,f)=>n+f.size,0))+'. Alt klasör yolları korunacak.';});
  form.addEventListener('submit',async event=>{
   event.preventDefault();if(busy)return;const csrf=form.querySelector('[name=csrf]').value;const send=(url,values={},file=null,onProgress)=>{const data=new FormData();data.set('csrf',csrf);Object.entries(values).forEach(([k,v])=>data.set(k,String(v)));if(file)data.set('chunk_file',file,'chunk.part');return post(url,data,onProgress);};
   let total=0,completed=0;
   const show=(message,bytes=completed)=>{status.textContent=message;progress.value=total?Math.min(100,Math.round(bytes/total*100)):0;};
   const analyze=async id=>{let result;do{show('SQL inceleniyor… Alan eşleştirme hazırlanıyor.');result=await send(form.dataset.analyze,{job:id});status.textContent='SQL inceleniyor: %'+Math.min(100,Math.round(result.offset/result.size*100))+' · '+result.records.toLocaleString('tr-TR')+' kayıt okundu.';}while(!result.done);resume=result.redirect;};
   async function upload(file,kind,path=''){
    const key=[file.name,file.size,file.lastModified,path].join('|');let result=await send(form.dataset.begin,{kind,name:file.name,size:file.size,client_key:key,job:kind==='sql'?'':job,path});const id=result.upload,chunkSize=result.chunk_size;let offset=result.offset;if(result.job){job=result.job;resume=result.redirect;}
    if(chunkSize<1)throw new Error('Sunucunun POST sınırı bir yükleme parçasını kabul edemiyor. Hosting yükleme ayarlarını kontrol edin.');
    while(offset<file.size){const end=Math.min(file.size,offset+chunkSize);show(file.name+' yükleniyor: '+pretty(offset)+' / '+pretty(file.size)+' · Toplam %'+progress.value,completed+offset);let retry=0;
     for(;;){try{result=await send(form.dataset.chunk,{upload:id,offset},file.slice(offset,end),fraction=>show(file.name+' yükleniyor: '+pretty(offset+fraction*(end-offset))+' / '+pretty(file.size)+' · Toplam %'+Math.round((completed+offset+fraction*(end-offset))/total*100),completed+offset+fraction*(end-offset)));break;}catch(error){if(!error.retry||retry++>=2)throw error;status.textContent='Bağlantı tekrar deneniyor… '+file.name;result=await send(form.dataset.begin,{kind,name:file.name,size:file.size,client_key:key,job:kind==='sql'?'':job,path});if(result.offset!==offset)break;}}
     if(result.offset<=offset||result.offset>file.size)throw new Error('Sunucu parça ilerlemesini doğrulayamadı. Aynı dosyayla yeniden deneyin.');offset=result.offset;
    }
    result=await send(form.dataset.finish,{upload:id});if(result.job){job=result.job;resume=result.redirect;}
    if(kind==='sql')await analyze(job);
    if(kind==='zip'){while(!result.done){show('ZIP açılıyor ve görseller eşleştiriliyor…');result=await send(form.dataset.extract,{upload:id});if(result.processing_size)status.textContent='ZIP görselleri eşleştiriliyor: %'+Math.min(100,Math.round(result.processed/result.processing_size*100))+'.';}resume=result.redirect;}
    completed+=file.size;show(file.name+' tamamlandı · '+pretty(completed)+' / '+pretty(total));
   }
   try{
    const initial=form.dataset.directoryMode==='initial';const sql=form.querySelector('[name=sql_file]')?.files[0],zip=form.querySelector('[name=image_zip]')?.files[0],images=input?[...input.files].filter(supported):[];
    if(initial&&!sql)throw new Error('Eski sitenizin veri içeren SQL dosyasını seçin.');if(!initial&&!zip&&!images.length)throw new Error('Bir ZIP veya görsel klasörü seçin.');
    total=(initial?sql.size:0)+(zip?.size||0)+images.reduce((n,f)=>n+f.size,0);busy=true;button.disabled=true;button.textContent='Yükleme sürüyor…';progress.hidden=false;progress.value=0;status.textContent='Yükleme başlatılıyor… '+pretty(total);
    if(initial)await upload(sql,'sql');if(zip)await upload(zip,'zip');for(let i=0;i<images.length;i++){show((i+1)+' / '+images.length+' görsel · '+images[i].name);await upload(images[i],'image',images[i].webkitRelativePath||images[i].name);}
    progress.value=100;status.textContent='Yükleme tamamlandı. Alan eşleştirme ekranı açılıyor…';if(resume)location.assign(resume);
   }catch(error){status.textContent=error.message;if(resume){const link=document.createElement('a');link.href=resume;link.textContent=' Aktarıma dön';status.append(link);}button.textContent='Yüklemeye devam et';busy=false;button.disabled=false;}
  });
 });
 document.querySelectorAll('[data-migration-remove]').forEach(form=>form.addEventListener('submit',async event=>{event.preventDefault();const button=form.querySelector('button');button.disabled=true;try{await post(form.action,new FormData(form));form.remove();}catch(e){form.querySelector('output').textContent=e.message;button.disabled=false;}}));
 document.querySelectorAll('[data-migration-analyze]').forEach(form=>{let busy=false;form.addEventListener('submit',async event=>{event.preventDefault();if(busy)return;busy=true;const button=form.querySelector('button'),status=form.querySelector('output'),progress=form.querySelector('progress');button.disabled=true;try{let result;do{const data=new FormData(form);result=await post(form.action,data);progress.value=result.size?result.offset/result.size*100:100;status.textContent='%'+Math.round(progress.value)+' · '+result.records.toLocaleString('tr-TR')+' kayıt okundu.';}while(!result.done);location.assign(result.redirect);}catch(e){status.textContent=e.message;busy=false;button.disabled=false;}});});
})();
