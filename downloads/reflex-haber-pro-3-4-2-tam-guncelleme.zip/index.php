<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
ob_start();
try {
    $route = request_route();
    if (str_starts_with($route, '/panel')) { header('Cache-Control: no-store, private');header('X-Robots-Tag: noindex,nofollow'); require __DIR__ . '/app/admin.php'; }
    else { require __DIR__ . '/app/site.php'; }
} catch (Throwable $exception) {
    ob_clean();
    $reference=log_failure($exception);
    $status = http_response_code();
    if ($status < 400) http_response_code($exception instanceof InvalidArgumentException ? 422 : 500);
    view('error', ['message'=>$exception instanceof InvalidArgumentException || $status===419 ? $exception->getMessage() : 'İşlem tamamlanamadı. Lütfen tekrar deneyin.','reference'=>$reference]);
}
