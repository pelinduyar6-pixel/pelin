<?php
// Standalone deployment check and authenticated, site-only OPcache refresh.
ini_set('display_errors','0');
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, private, max-age=0');
header('X-Robots-Tag: noindex,nofollow');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'");
$root=__DIR__;
function reflex_check_escape($value){return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8');}
function reflex_check_text($file){return is_file($file)&&is_readable($file)&&!is_link($file)?(string)file_get_contents($file):'';}
$pro=reflex_check_text($root.'/app/pro.php');
$sourceVersion=preg_match("/const\\s+PRO_VERSION\\s*=\\s*'([^']+)'/",$pro,$match)?$match[1]:'Bulunamadı';
$errorCode=strpos(reflex_check_text($root.'/views/error.php'),'Hata kodu:')!==false;
$indexReference=strpos(reflex_check_text($root.'/index.php'),"'reference'=>\$reference")!==false;
$manifest=json_decode(reflex_check_text($root.'/release-files.json'),true);
$issues=[];$checked=0;$manifestValid=is_array($manifest)&&isset($manifest['version'],$manifest['files'])&&is_string($manifest['version'])&&is_array($manifest['files'])&&count($manifest['files'])>0&&count($manifest['files'])<=1000;
if($manifestValid){
    foreach($manifest['files'] as $path=>$expected){
        if(!is_string($path)||!preg_match('~^(?:(?:app|views|assets)/[a-zA-Z0-9_./-]+|[a-zA-Z0-9_-]+\\.php|\\.htaccess)$~D',$path)||strpos($path,'..')!==false||!is_string($expected)||!preg_match('/^[a-f0-9]{64}$/D',$expected)){
            $issues[]=['file'=>'release-files.json','status'=>'Geçersiz dosya kaydı'];continue;
        }
        $checked++;$file=$root.'/'.$path;$resolved=realpath($file);
        if(!$resolved||strpos($resolved,$root.'/')!==0||!is_file($file)||!is_readable($file))$issues[]=['file'=>$path,'status'=>'Eksik veya okunamıyor'];
        elseif(!hash_equals($expected,(string)hash_file('sha256',$file)))$issues[]=['file'=>$path,'status'=>'Paket ile farklı'];
    }
}else $issues[]=['file'=>'release-files.json','status'=>'Eksik veya geçersiz'];
$documentRoot=realpath(isset($_SERVER['DOCUMENT_ROOT'])?$_SERVER['DOCUMENT_ROOT']:'');
$siteDirectory=$documentRoot&&$root===$documentRoot?'Alan adının ana web klasörü':($documentRoot&&strpos($root,$documentRoot.'/')===0?substr($root,strlen($documentRoot)+1):'Alan adı web klasörüyle karşılaştırılamadı');
$extensions=[];
foreach(['pdo','pdo_mysql','dom','mbstring','fileinfo','curl','openssl'] as $extension)$extensions[$extension]=extension_loaded($extension);
$serverReady=PHP_VERSION_ID>=80100;
foreach($extensions as $extension=>$enabled)if(!$enabled&&$extension!=='pdo_mysql')$serverReady=false;
$opcacheEnabled=filter_var(ini_get('opcache.enable'),FILTER_VALIDATE_BOOLEAN);
$timestamps=filter_var(ini_get('opcache.validate_timestamps'),FILTER_VALIDATE_BOOLEAN);
$packageReady=$sourceVersion==='3.4.2'&&$manifestValid&&$manifest['version']==='3.4.2'&&!$issues&&$errorCode&&$indexReference;
$checks=[
    ['Diskteki uygulama sürümü',$sourceVersion,$sourceVersion==='3.4.2'],
    ['Paket manifesti',$manifestValid?$manifest['version']:'Bulunamadı',$manifestValid&&$manifest['version']==='3.4.2'],
    ['Hata ekranında yeni kod alanı',$errorCode?'Var':'Yok',$errorCode],
    ['Ana girişte hata kodu bağlantısı',$indexReference?'Var':'Yok',$indexReference],
    ['Dosya denetimi',$checked.' dosya · '.count($issues).' sorun',!$issues],
    ['PHP sürümü',PHP_VERSION,PHP_VERSION_ID>=80100],
    ['Uygulama oturum klasörü',is_dir($root.'/storage/sessions')&&is_writable($root.'/storage/sessions')?'Yazılabilir':'Eksik veya yazılamıyor',is_dir($root.'/storage/sessions')&&is_writable($root.'/storage/sessions')],
    ['Uygulama günlük klasörü',is_dir($root.'/storage/logs')&&is_writable($root.'/storage/logs')?'Yazılabilir':'Eksik veya yazılamıyor',is_dir($root.'/storage/logs')&&is_writable($root.'/storage/logs')]
];
$candidate=false;$refreshToken='';$refreshNotice='';$refreshError='';
if(isset($_COOKIE['reflex6_session'])&&is_string($_COOKIE['reflex6_session'])&&preg_match('/^[a-zA-Z0-9,-]{16,128}$/D',$_COOKIE['reflex6_session'])&&is_dir($root.'/storage/sessions')){
    session_save_path($root.'/storage/sessions');session_name('reflex6_session');ini_set('session.use_strict_mode','1');
    $path=str_replace('\\','/',dirname(isset($_SERVER['SCRIPT_NAME'])?$_SERVER['SCRIPT_NAME']:'/'));
    session_set_cookie_params(['lifetime'=>0,'path'=>$path==='/'?'/':$path.'/','httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Lax']);
    if(@session_start()){
        $candidate=isset($_SESSION['user_id'],$_SESSION['last_activity'])&&is_scalar($_SESSION['user_id'])&&(int)$_SESSION['user_id']>0&&time()-(int)$_SESSION['last_activity']<7200;
        if($candidate){
            if(empty($_SESSION['reflex_cache_refresh_token']))$_SESSION['reflex_cache_refresh_token']=bin2hex(random_bytes(32));
            $refreshToken=$_SESSION['reflex_cache_refresh_token'];
        }
    }
}
function reflex_refresh_is_admin($root){
    try{
        if(!is_file($root.'/storage/site.php'))return false;
        $config=require $root.'/storage/site.php';$db=$config['db'];
        if(isset($db['driver'])&&$db['driver']==='sqlite')$pdo=new PDO('sqlite:'.$db['path']);
        else $pdo=new PDO('mysql:host='.$db['host'].';port='.$db['port'].';dbname='.$db['database'].';charset=utf8mb4',$db['username'],$db['password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $statement=$pdo->prepare('SELECT role,active FROM rh6_users WHERE id=?');$statement->execute([(int)$_SESSION['user_id']]);$account=$statement->fetch(PDO::FETCH_ASSOC);
        return $account&&$account['role']==='admin'&&(int)$account['active']===1;
    }catch(Throwable $error){return false;}
}
if(isset($_SERVER['REQUEST_METHOD'])&&$_SERVER['REQUEST_METHOD']==='POST'){
    if(!$candidate||!isset($_POST['csrf'])||!is_string($_POST['csrf'])||!hash_equals($refreshToken,$_POST['csrf'])||!reflex_refresh_is_admin($root)){
        http_response_code(403);$refreshError='Mevcut yönetici oturumu ve geçerli işlem kodu gerekiyor. Önce panel girişini yapın, sonra bu ekranı yeniden açın.';
    }elseif(!$packageReady){
        http_response_code(422);$refreshError='Önbellek yenilenmedi. Önce aşağıdaki eksik veya farklı güncelleme dosyalarını tamamlayın.';
    }elseif(!$opcacheEnabled){
        $refreshNotice='PHP önbelleği kapalı. Dosyalar diskteki sürümlerinden çalışır; panel bağlantısını yeniden açabilirsiniz.';
    }elseif(!function_exists('opcache_invalidate')){
        http_response_code(503);$refreshError='Hosting bu önbellek işlevini kapatmış. Hosting desteğinden yalnız bu sitenin PHP önbelleğini yenilemesini isteyin.';
    }else{
        $refreshed=0;$failed=0;
        foreach($manifest['files'] as $path=>$expected){
            if(substr($path,-4)!=='.php')continue;
            $file=$root.'/'.$path;
            $cached=function_exists('opcache_is_script_cached')?@opcache_is_script_cached($file):null;
            $ok=@opcache_invalidate($file,true);
            if($ok)$refreshed++;elseif($cached)$failed++;
        }
        if($failed){http_response_code(503);$refreshError=$failed.' dosyanın PHP önbelleği yenilenemedi. Hosting desteğinden bu sitenin PHP sürecini yeniden başlatmasını isteyin.';}
        elseif($refreshed){$refreshNotice='Bu sitenin '.$refreshed.' PHP dosyası için önbellek yenilendi. Şimdi yönetim panelini açın.';$_SESSION['last_activity']=time();}
        else{$refreshNotice='Yenileme çağrısı tamamlandı; bu sunucuda temizlenecek önbellek kaydı doğrulanamadı. Panel aynı hatayı verirse hosting desteğinden bu sitenin PHP sürecini yeniden başlatmasını isteyin.';}
    }
}
if(session_status()===PHP_SESSION_ACTIVE)session_write_close();
?>
<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reflex panel kurtarma</title><style>
*{box-sizing:border-box}body{margin:0;background:#f2f5fa;color:#172c41;font:17px/1.55 Arial,sans-serif}main{max-width:960px;margin:30px auto;padding:24px}section{background:#fff;border:1px solid #dae2ee;border-radius:14px;padding:24px;margin:18px 0}h1{font-size:30px;margin:0}h2{font-size:23px;margin-top:0}.help{color:#50667b}.status{border-left:5px solid #16a36e}.warning{border-left-color:#dc3344}dl{margin:0}.row{display:grid;grid-template-columns:1fr 1fr;gap:18px;padding:13px 0;border-bottom:1px solid #edf0f5}.row:last-child{border:0}dt{font-weight:700}dd{margin:0;overflow-wrap:anywhere}.ok{color:#087745}.bad{color:#ba2333}code{font-size:15px;overflow-wrap:anywhere}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:12px 8px;border-bottom:1px solid #edf0f5;overflow-wrap:anywhere}th:first-child{width:65%}@media(max-width:600px){main{margin:0;padding:15px}section{padding:18px}.row{grid-template-columns:1fr;gap:3px}h1{font-size:26px}}
</style></head><body><main><h1>Reflex panel kurtarma · 3.4.2</h1><p class="help">Dosya bütünlüğünü ve PHP ayarlarını kontrol eder. Önbellek yenilemesi yalnız yönetici oturumu doğrulanarak yapılır. Site dosyaları, haberler, ayarlar ve görseller değiştirilmez; parolalar, API anahtarları ve günlükler gösterilmez.</p>
<?php if($refreshNotice):?><section class="status"><p><?=reflex_check_escape($refreshNotice)?></p><p><a href="panel.php">Yönetim panelini aç</a></p></section><?php endif ?>
<?php if($refreshError):?><section class="status warning"><p><?=reflex_check_escape($refreshError)?></p></section><?php endif ?>
<section class="status <?=$packageReady&&$serverReady?'':'warning'?>"><h2><?=reflex_check_escape($packageReady?'Diskteki 3.4.2 dosyaları eksiksiz':'Güncelleme dosyalarını kontrol edin')?></h2>
<?php if(!$packageReady):?><p>3.4.2 tam güncelleme ZIP’ini bu alan adının <code>index.php</code> dosyasının bulunduğu klasöre çıkarın. Aşağıdaki eksik veya farklı dosyaları paketteki sürümleriyle yenileyin.</p>
<?php else:?><p>Bu sonuç diskteki kaynak dosyalarını doğrular; çalışan PHP önbelleğini doğrulamaz. Panel eski hata ekranını gösteriyorsa hosting desteğiyle bu alan adının web klasörünü ve PHP önbelleğini kontrol edin.</p><?php endif ?>
<?php if(!$serverReady):?><p class="bad">Sunucu için PHP 8.1 veya üzeri ve aşağıdaki gerekli uzantılar etkin olmalı.</p><?php endif ?>
<?php if($opcacheEnabled&&!$timestamps):?><p class="bad">OPcache dosya değişikliklerini otomatik denetlemiyor. Hosting panelinden yalnız bu sitenin PHP sürecini yeniden başlatın veya hosting desteğinden önbelleğin yenilenmesini isteyin.</p><?php endif ?>
<p>Çalışma konumu: <b><?=reflex_check_escape($siteDirectory)?></b></p></section>
<section><h2>Bu sitenin PHP önbelleğini yenile</h2><p>Eski başlatıcı sosyal medya modülünü yüklemeden çağırıyorsa panel hata verebilir. Güncelleme dosyaları eksiksizken bu işlem, yalnız paketteki bu siteye ait PHP dosyalarını yeniler. Diğer sitelerin önbelleği sıfırlanmaz.</p>
<?php if($candidate):?><form method="post"><input type="hidden" name="csrf" value="<?=reflex_check_escape($refreshToken)?>"><button type="submit" style="font:700 17px Arial;padding:15px 22px;border:0;border-radius:9px;background:#c71931;color:white;cursor:pointer">Güncelleme önbelleğini yenile</button></form>
<?php else:?><p>Önce mevcut yönetici hesabınızla panel girişini yapın; ardından bu ekranı yeniden açın. Giriş sonrasında panel hata verse bile oluşan oturumla burada devam edebilirsiniz.</p><p><a href="index.php?route=%2Fpanel%2Fgiris">Panel girişini aç</a></p><?php endif ?></section>
<section><h2>Dosyalar ve sunucu</h2><dl><?php foreach($checks as $check):?><div class="row"><dt><?=reflex_check_escape($check[0])?></dt><dd class="<?=$check[2]?'ok':'bad'?>"><?=reflex_check_escape($check[1])?></dd></div><?php endforeach ?></dl></section>
<?php if($issues):?><section><h2>Eksik veya farklı dosyalar</h2><table><thead><tr><th>Dosya</th><th>Durum</th></tr></thead><tbody><?php foreach($issues as $issue):?><tr><td><code><?=reflex_check_escape($issue['file'])?></code></td><td><?=reflex_check_escape($issue['status'])?></td></tr><?php endforeach ?></tbody></table></section><?php endif ?>
<section><h2>PHP uzantıları ve önbellek</h2><dl><?php foreach($extensions as $extension=>$enabled):?><div class="row"><dt><?=reflex_check_escape($extension)?></dt><dd class="<?=$enabled?'ok':'bad'?>"><?=$enabled?'Etkin':'Etkin değil'?></dd></div><?php endforeach ?><div class="row"><dt>OPcache</dt><dd><?=$opcacheEnabled?'Etkin':'Kapalı'?></dd></div><div class="row"><dt>Dosya değişiklikleri denetleniyor</dt><dd><?=$opcacheEnabled?($timestamps?'Evet':'Hayır'):'Önbellek kapalı'?></dd></div></dl></section>
<p class="help">Kontrol tamamlanınca yalnız bu kontrol dosyasını site kökünden kaldırabilirsiniz.</p></main></body></html>
