<?php $initial=$initial??false; ?>
<div class="migration-file-options"><div class="migration-file-option"><h3>Görselleri ZIP olarak yükle</h3>
<?php if(!$initial):?><form class="migration-directory-form" data-directory-mode="zip" <?=migration_upload_attributes($job['id'])?> method="post" enctype="multipart/form-data" action="<?=e(url('/panel/tasima/gorseller',['job'=>$job['id']]))?>"><?=csrf_field()?><?php endif ?>
<label>Görsel ZIP dosyası <?=$initial?'(isteğe bağlı)':''?><input type="file" name="image_zip" accept=".zip" <?=$initial?'':'required'?>></label>
<p class="help">ZIP küçük parçalarla yüklenir ve aşamalar hâlinde açılır. Uygulama toplam boyut veya dosya adedi sınırı koymaz. SQL ve görseller farklı zamanlarda yüklenebilir.</p>
<?php if(!$initial):?><output class="migration-directory-status" role="status" aria-live="polite"></output><progress max="100" value="0" hidden></progress><button class="btn">Görselleri eşleştir</button></form><?php endif ?>
</div><div class="migration-file-option"><h3>Veya klasörü doğrudan seç</h3>
<?php if(!$initial):?><form class="migration-directory-form" data-directory-mode="images" <?=migration_upload_attributes($job['id'])?> method="post" enctype="multipart/form-data" action="<?=e(url('/panel/tasima/klasor',['job'=>$job['id']]))?>"><?=csrf_field()?><?php endif ?>
<label>Eski uploads / resim klasörü<input type="file" data-migration-directory webkitdirectory directory multiple accept="image/jpeg,image/png,image/gif,image/webp"></label>
<p class="help">JPG, PNG, GIF ve WebP desteklenir. Büyük görseller de parçalara bölünür; alt klasörler korunur. Toplam boyut ve görsel adedi sınırı yoktur.</p>
<?php if(!$initial):?><output class="migration-directory-status" role="status" aria-live="polite"></output><progress max="100" value="0" hidden></progress><button class="btn">Klasörü yükle ve eşleştir</button></form><?php endif ?>
</div></div>
<?php if($initial):?><output class="migration-directory-status" role="status" aria-live="polite"></output><progress max="100" value="0" hidden></progress><?php endif ?>
