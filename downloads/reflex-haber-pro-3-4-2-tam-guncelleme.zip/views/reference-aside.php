<?php show_ad('sidebar');show_ad('sidebar_mid');if($popular): ?>
<section class="side-block reference-popular">
    <div class="sidebar-heading"><span class="eyebrow">OKURLARIN SEÇİMİ</span><h2>En çok okunanlar</h2></div>
    <?php foreach($popular as $rank=>$item): ?>
    <a class="ranked-story" href="<?=e(news_link($item))?>"><span class="story-rank"><?=str_pad((string)($rank+1),2,'0',STR_PAD_LEFT)?></span><div><small><?=e($item['category_name'])?></small><h3><?=e($item['title'])?></h3></div></a>
    <?php endforeach ?>
</section>
<?php endif;show_ad('sidebar_bottom'); ?>
