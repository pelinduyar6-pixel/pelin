<?php if($referenceTop): ?>
<section class="reference-top" aria-label="Öne çıkan haberler">
    <?php foreach($referenceTop as $item): ?>
    <a class="reference-top-card" href="<?=e(news_link($item))?>">
        <div><img src="<?=e(media($item['image']))?>" alt="" width="400" height="225" loading="lazy"><span><?=e($item['category_name'])?></span></div>
        <h2><?=e($item['title'])?></h2>
    </a>
    <?php endforeach ?>
</section>
<?php endif ?>
