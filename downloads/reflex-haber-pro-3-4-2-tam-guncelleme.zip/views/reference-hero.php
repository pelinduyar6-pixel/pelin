<?php if($headlines): ?>
<section class="headline-carousel carousel reference-hero" data-autoplay="<?=e(setting('slider_autoplay','1'))?>" data-interval="<?=e(setting('slider_interval','3'))?>" aria-label="Manşetler">
    <?php view('ticker',['ticker'=>news_rows('AND n.is_breaking=1',[],8)]); ?>
    <div class="hero-stage">
        <?php foreach($headlines as $i=>$item): ?>
        <a class="hero-slide" href="<?=e(news_link($item))?>" <?=$i?'hidden':''?>>
            <img src="<?=e(media($item['image']))?>" alt="" width="1100" height="620" <?=$i?'loading="lazy"':'fetchpriority="high"'?>>
            <span class="hero-shade"></span>
            <div class="reference-hero-text">
                <span class="reference-tag"><?=e($item['category_name']?:$primaryHeading)?></span>
                <?php if(active_theme()==='8'&&!empty($item['summary'])): ?><span class="reference-kicker"><?=e(mb_substr($item['summary'],0,75))?></span><?php endif ?>
                <h2><?=e($item['title'])?></h2>
            </div>
        </a>
        <?php endforeach ?>
        <?php if(count($headlines)>1): ?>
        <button class="carousel-arrow prev" type="button" aria-label="Önceki manşet">‹</button>
        <button class="carousel-arrow next" type="button" aria-label="Sonraki manşet">›</button>
        <button class="carousel-toggle" type="button" aria-label="Otomatik geçişi durdur" aria-pressed="false">II</button>
        <?php endif ?>
    </div>
    <div class="carousel-dots" role="group" aria-label="Manşet seçimi">
        <?php foreach($headlines as $i=>$item): ?><button type="button" class="<?=$i?'':'active'?>" aria-label="<?=$i+1?>. manşet" aria-pressed="<?=$i?'false':'true'?>"><?=$i+1?></button><?php endforeach ?>
    </div>
</section>
<?php endif ?>
