<?php
$edition=active_theme();
$headlineVisible=setting('home_show_headline','1')!=='0'&&!empty($headlines);
$sidebarVisible=setting('home_show_sidebar','1')!=='0';
$leadId=$headlineVisible?(int)$headlines[0]['id']:0;
$referenceTop=array_slice(array_values(array_filter($topFeature,fn($n)=>(int)$n['id']!==$leadId)),0,4);
$vitrineItems=array_slice(array_values(array_filter($boxes,fn($n)=>(int)$n['id']!==$leadId)),0,2);
show_ad('home_top');
if($edition==='5'&&setting('home_show_top','1')!=='0')view('reference-top',get_defined_vars());
if($headlineVisible):
    $hasLeadAside=$sidebarVisible&&($edition==='5'?!empty($latest):(in_array($edition,['6','7'],true)&&!empty($vitrineItems)));
?>
<section class="reference-lead edition-<?=$edition?> <?=$hasLeadAside?'with-lead-aside':''?>" aria-label="<?=e($primaryHeading)?> manşetleri">
    <?php view('reference-hero',get_defined_vars()); ?>
    <?php if($hasLeadAside): ?>
    <aside class="reference-lead-aside">
        <?php if($edition==='5'): ?>
        <section class="reference-live-list"><div class="sidebar-heading"><span class="eyebrow">YAYIN AKIŞI</span><h2>Son haberler</h2></div>
            <?php foreach(array_slice($latest,0,5) as $item): ?><a class="latest-row" href="<?=e(news_link($item))?>"><time><?=e(date('H:i',strtotime($item['published_at']??$item['created_at'])))?></time><b><?=e($item['title'])?></b></a><?php endforeach ?>
            <a class="sidebar-more" href="<?=e(url('/son-haberler'))?>">Tüm haberler <?=ui_icon('arrow')?></a>
        </section>
        <?php else:foreach($vitrineItems as $item): ?>
        <a class="picture-card reference-vitrine" href="<?=e(news_link($item))?>"><img src="<?=e(media($item['image']))?>" alt="" loading="lazy"><span class="reference-tag"><?=e($item['category_name'])?></span><h2><?=e($item['title'])?></h2></a>
        <?php endforeach;endif ?>
    </aside>
    <?php endif ?>
</section>
<?php endif;
if($edition!=='5'&&setting('home_show_top','1')!=='0')view('reference-top',get_defined_vars());
ob_start();if($sidebarVisible)view('reference-aside',get_defined_vars());$referenceAside=trim((string)ob_get_clean());$contentAside=$sidebarVisible&&$referenceAside!=='';
if($boxes||$contentAside): ?>
<div class="home-grid reference-content <?=!$contentAside?'without-sidebar':''?>">
    <div class="main-column">
        <?php if($boxes): ?><section class="reference-news"><div class="portal-heading"><h2><?=e($primaryHeading)?></h2><a href="<?=e($primaryStories?url('/kategori/'.$primaryCategory['slug']):url('/son-haberler'))?>">Tümü »</a></div><div class="news-grid"><?php foreach(array_slice($boxes,0,$edition==='7'?6:4) as $item):view('card',['item'=>$item]);endforeach ?></div></section><?php endif;show_ad('content'); ?>
    </div>
    <?php if($contentAside): ?><aside class="right-column"><?=$referenceAside?></aside><?php endif ?>
</div>
<?php endif;view('home-sections',get_defined_vars()); ?>
