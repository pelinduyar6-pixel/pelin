<?php $initial=$initial??false; ?>
<div class="migration-file-options">
<div class="migration-file-option">
<h3>Görselleri ZIP olarak yükle</h3>
<?php if(!$initial):?><form method="post" enctype="multipart/form-data" action="<?=e(url('/panel/tasima/gorseller',['job'=>$job['id']]))?>"><?=csrf_field()?><?php endif ?>
<label>Görsel ZIP dosyası <?=$initial?'(isteğe bağlı)':''?><input type="file" name="image_zip" accept=".zip" <?=$initial?'':'required'?>></label>
<p class="help">Eski uploads / resim klasörünü alt klasörleriyle birlikte ZIP yapın. En fazla 64 MB; sunucu sınırı <?=e(ini_get('upload_max_filesize'))?>. SQL ve görselleri farklı zamanlarda yükleyebilirsiniz.</p>
<?php if(!$initial):?><button class="btn">Görselleri eşleştir</button></form><?php endif ?>
</div>
<div class="migration-file-option">
<h3>Veya klasörü doğrudan seç</h3>
<?php if(!$initial):?><form class="migration-directory-form" data-directory-mode="images" data-upload-budget="<?=migration_upload_budget()?>" method="post" enctype="multipart/form-data" action="<?=e(url('/panel/tasima/klasor',['job'=>$job['id']]))?>"><?=csrf_field()?><?php endif ?>
<label>Eski uploads / resim klasörü<input type="file" data-migration-directory webkitdirectory directory multiple accept="image/jpeg,image/png,image/gif,image/webp"></label>
<p class="help">ZIP gerekmez. JPG, PNG, GIF ve WebP dosyaları küçük gruplar hâlinde yüklenir. Alt klasörler korunur. Bu aktarım için en fazla 5.000 görsel / 256 MB; tek dosya sunucu sınırını aşamaz.</p>
<noscript><p>Klasör seçimi için JavaScript’i açın veya ZIP seçeneğini kullanın.</p></noscript>
<?php if(!$initial):?><output class="migration-directory-status" role="status" aria-live="polite"></output><progress max="100" value="0" hidden></progress><button class="btn">Klasörü yükle ve eşleştir</button></form><?php endif ?>
</div>
</div>
<?php if($initial):?><output class="migration-directory-status" role="status" aria-live="polite"></output><progress max="100" value="0" hidden></progress><?php endif ?>
