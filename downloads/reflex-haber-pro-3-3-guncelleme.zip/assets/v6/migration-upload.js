/* Upload browser-selected folders in bounded, resumable batches. */
(() => {
  'use strict';
  document.querySelectorAll('.migration-directory-form').forEach(form => {
    const input = form.querySelector('[data-migration-directory]');
    if (!input) return;
    const status = form.querySelector('.migration-directory-status'), progress = form.querySelector('progress'), button = form.querySelector('button[type=submit],button:not([type])');
    let busy = false;
    const supported = file => /\.(jpe?g|png|gif|webp)$/i.test(file.name);
    input.addEventListener('change', () => {
      const count = [...input.files].filter(supported).length;
      status.textContent = count ? count + ' görsel seçildi. Alt klasörlerin yolları eşleştirmede kullanılacak.' : 'Seçilen klasörde desteklenen görsel bulunamadı.';
    });
    async function post(url, data) {
      const response = await fetch(url, {method: 'POST', body: data, headers: {'Accept': 'application/json'}, credentials: 'same-origin'});
      let result;
      try { result = await response.json(); } catch { throw new Error('Yükleme tamamlanamadı. Sunucu dosya sınırını ve oturumunuzu kontrol edin.'); }
      if (!response.ok || !result.ok) {
        const error = new Error(result.message || 'Yükleme tamamlanamadı.'); error.resume = result.redirect; throw error;
      }
      return result;
    }
    form.addEventListener('submit', async event => {
      const files = [...input.files].filter(supported), initial = form.dataset.directoryMode === 'initial';
      if (initial && !input.files.length) return; // Normal SQL + optional ZIP upload works without JavaScript.
      event.preventDefault(); if (busy) return;
      const budget = Number(form.dataset.uploadBudget) || 0;
      let resume = null;
      try {
        if (!files.length) throw new Error('Önce görsel klasörünü seçin.');
        if (files.length > 5000 || files.reduce((sum, file) => sum + file.size, 0) > 268435456) throw new Error('En fazla 5.000 görsel ve toplam 256 MB yükleyin.');
        const oversized = files.find(file => file.size > budget);
        if (oversized) throw new Error(oversized.name + ' sunucunun tek dosya yükleme sınırını aşıyor. Görseli küçültüp tekrar seçin.');
        busy = true; button.disabled = true; progress.hidden = false; progress.value = 0;
        let uploadUrl = form.action;
        if (initial) {
          status.textContent = 'SQL dosyası inceleniyor…';
          const result = await post(form.action, new FormData(form));
          uploadUrl = result.upload_url; resume = result.redirect;
        }
        let completed = 0;
        while (completed < files.length) {
          const data = new FormData(), batch = []; let bytes = 0;
          data.append('csrf', new FormData(form).get('csrf'));
          for (let i = completed; i < files.length && batch.length < 10; i++) {
            const file = files[i]; if (batch.length && bytes + file.size > budget) break;
            bytes += file.size; batch.push(file);
            data.append('migration_files[]', file, file.name); data.append('image_paths[]', file.webkitRelativePath || file.name);
          }
          status.textContent = completed + ' / ' + files.length + ' görsel yüklendi. Yükleme sürüyor…';
          const result = await post(uploadUrl, data); resume = result.redirect;
          completed += batch.length; progress.value = Math.round(completed / files.length * 100);
        }
        status.textContent = files.length + ' görsel yüklendi. Eşleştirme ekranı açılıyor…';
        location.assign(resume);
      } catch (error) {
        status.textContent = error.message || 'Görseller yüklenemedi.';
        const target = error.resume || resume;
        if (target) {
          const link = document.createElement('a'); link.href = target; link.textContent = ' Aktarıma dön ve yüklemeye devam et'; status.append(link);
        }
        progress.hidden = true; busy = false; button.disabled = false;
      }
    });
  });
})();
