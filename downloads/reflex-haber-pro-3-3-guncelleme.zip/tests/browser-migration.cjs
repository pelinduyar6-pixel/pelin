const { chromium } = require('playwright'), fs = require('fs');
(async () => {
  const base = process.argv[2]; if (!/^http:\/\/(localhost|127\.0\.0\.1):/.test(base)) throw Error('Local disposable installation required');
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } }), errors = [];
  page.on('pageerror', e => errors.push(e.message)); const route = p => base + '/index.php?' + new URLSearchParams({ route: p });
  const check = (ok, label) => { if (!ok) throw Error(label); console.log('PASS', label); };
  await page.goto(route('/panel/giris')); await page.locator('[name=email]').fill('test-admin@example.invalid'); await page.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD); await page.getByRole('button', { name: 'Giriş yap' }).click(); await page.waitForURL(/route=%2Fpanel$/);
  await page.goto(route('/panel/tasima'));
  await page.locator('[name=sql_file]').setInputFiles({ name: 'old-news.sql', mimeType: 'text/plain', buffer: Buffer.from("CREATE TABLE old_categories (`id` INT, `name` VARCHAR(100), `slug` VARCHAR(100)); INSERT INTO old_categories VALUES (17001,'Yerel Gündem','migration-browser-fixture'); CREATE TABLE old_news (`id` INT, `title` VARCHAR(255), `body` TEXT, `category_id` INT, `image` VARCHAR(1000)); INSERT INTO old_news VALUES (1,'Eski arşiviniz yeni yayın merkezinde','<p>Örnek aktarım önizlemesi. Bu haber yayına alınmadan önce editör tarafından kontrol edilir.</p>',17001,'resimler/cover.jpg');") });
  await page.getByRole('button', { name: /SQL dosyasını incele/ }).click(); await page.waitForURL(/job=/);
  const job = new URL(page.url()).searchParams.get('job');
  await page.getByRole('button', { name: 'Eşleştirmeyi kaydet ve önizle' }).click(); await page.getByRole('heading', { name: 'Haber önizlemesi' }).waitFor();
  await page.locator('[name=image_zip]').setInputFiles('/tmp/reflex-migration-browser.zip'); await page.getByRole('button', { name: 'Görselleri eşleştir' }).click(); await page.locator('.migration-preview-grid img').waitFor();
  check(await page.locator('.migration-preview-grid img').evaluate(e => e.complete && e.naturalWidth > 0), 'Preview resolves a separately uploaded local image');
  for (const width of [1440, 768, 390, 320]) { await page.setViewportSize({ width, height: 1000 }); check(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'Mapping, category ID table and preview fit ' + width + 'px'); }
  await page.setViewportSize({ width: 1440, height: 1100 }); fs.mkdirSync('/workspace/outputs/reflex-edition', { recursive: true }); await page.addStyleTag({ content: '.admin-topbar{visibility:hidden}' }); await page.locator('.migration-preview').screenshot({ path: '/workspace/outputs/reflex-edition/veri-tasima-onizleme.png' }); await page.locator('.migration-mapping').screenshot({ path: '/workspace/outputs/reflex-edition/veri-tasima-eslestirme.png' });
  await page.getByRole('button', { name: 'Aktarım dosyalarını temizle' }).click(); await page.waitForURL(url => !url.searchParams.get('job'));
  check(!errors.length, 'Migration controls have no browser errors: ' + errors.join('; ')); await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
