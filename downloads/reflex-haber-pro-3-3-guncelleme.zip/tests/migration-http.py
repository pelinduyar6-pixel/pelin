"""Public-content migration acceptance on a disposable local installation only."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
import io, zipfile, time, html
assert urllib.parse.urlsplit(BASE).hostname in ['localhost','127.0.0.1']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
page=get('/panel/tasima');check('Veri Taşıma' in page and 'SQL dosyasını incele' in page,'Administrator has a staged SQL and image migration menu')
check(request(route('/panel/tasima/yukle'),{},'invalid')[0]==419,'SQL upload requires CSRF')
suffix=str(time.time_ns());title='Aktarım testi '+suffix
sql=f"""CREATE TABLE source_categories (`id` INT, `name` VARCHAR(100), `slug` VARCHAR(100));
INSERT INTO source_categories VALUES (15001,'Aktarım {suffix}','aktarim-{suffix}'),(1,'Çakışan {suffix}','cakisan-{suffix}');
CREATE TABLE source_news (`id` INT, `title` VARCHAR(255), `body` TEXT, `category_id` INT, `image` VARCHAR(1000));
INSERT INTO source_news VALUES (1,'{title}','<p>Görselli aktarım içeriği.</p><p><img src="https://old.invalid/resimler/cover.jpg"></p>',15001,'https://old.invalid/resimler/cover.jpg'),(2,'{title} ikinci','<p>İkinci kaynak haber.</p>',1,NULL);
DROP TABLE rh6_users;
""".encode()
status,page,location=request(route('/panel/tasima/yukle'),{},csrf(page),file=('sql_file','archive.sql',sql));check(status==200 and 'Alan eşleştirme' in page,'Uploaded MySQL dump becomes a mapping preview')
job=urllib.parse.parse_qs(urllib.parse.urlsplit(location).query)['job'][0]
mapping={'news_table':'source_news','category_table':'source_categories','id':'id','title':'title','body':'body','category_id':'category_id','image':'image','category_legacy_id':'id','category_name':'name','category_slug':'slug'}
status,page,_=request(route('/panel/tasima/eslestir',job=job),{'map['+k+']':v for k,v in mapping.items()},csrf(page));check(status==200 and 'Haber önizlemesi' in page and title in page,'Field mapping and category ID preview are reviewable before import')
def zip_bytes(entries):
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as archive:
        for name,data in entries.items():archive.writestr(name,data)
    return stream.getvalue()
photo=(Path(__file__).parents[1]/'assets/v6/demo/bogaz-5-2-400x225.jpg').read_bytes()
for label,entries in [('traversal',{'../escape.jpg':photo}),('fake image',{'resimler/cover.jpg':b'<?php echo 1; ?>'})]:
    status,bad,_=request(route('/panel/tasima/gorseller',job=job),{},csrf(page),file=('image_zip','images.zip',zip_bytes(entries)));check(status==422,'Image ZIP rejects '+label)
status,page,_=request(route('/panel/tasima/gorseller',job=job),{},csrf(page),file=('image_zip','images.zip',zip_bytes({'resimler/cover.jpg':photo,'readme.txt':b'ignored'})));check(status==200 and '1 görsel' in page,'Image folder ZIP uploads independently and maps by preserved paths')
preview_image=re.search(r'<article><img src="([^"]+)"',page).group(1);check(request(html.unescape(preview_image))[0]==200,'Mapped preview image is served from local uploads')
check(request(route('/panel/tasima/baslat',job=job),{},csrf(page))[0]==422,'Import cannot start without preview acknowledgement')
status,page,_=request(route('/panel/tasima/baslat',job=job),{'reviewed':'1'},csrf(page));check(status==200 and 'Arşiv aktarılıyor' in page,'Reviewed migration starts without publishing news')
status,page,_=request(route('/panel/tasima/devam',job=job),{},csrf(page));check(status==200 and 'Arşiviniz taslak olarak hazır' in page,'Batch finishes with progress and count summary')
records=request(route('/panel/haberler',q=title,status='draft'))[1]
rows=[m.group(1) for m in re.finditer(r'<tr[^>]*>(.*?)</tr>',records,re.S) if title in m.group(1)]
check(len(rows)==2,'Both migrated stories appear as drafts')
news_ids=[re.search(r'name="selected\[\]" value="(\d+)"',row).group(1) for row in rows]
edit=request(route('/panel/haberler/duzenle',id=news_ids[1]))[1];check('uploads/migration/' in edit and 'value="15001" selected' in edit,'Imported cover and free legacy category ID survive in the editor')
editor=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
elogin=request(route('/panel/giris'),opener=editor)[1];request(route('/panel/giris'),{'email':'test-editor@example.invalid','password':PASSWORD},csrf(elogin),opener=editor)
check(request(route('/panel/tasima',job=job),opener=editor)[0]==403,'Editors cannot access the migration menu or staged archive')
for nid in news_ids:request(route('/panel/haberler/sil',id=nid),{},csrf(get('/panel/haberler')))
categories=get('/panel/kategoriler');catrows=[m.group(1) for m in re.finditer(r'<tr[^>]*>(.*?)</tr>',categories,re.S) if suffix in m.group(1)]
for row in catrows:
    cid=re.search(r'name="selected\[\]" value="(\d+)"',row).group(1);request(route('/panel/kategoriler/sil',id=cid),{},csrf(categories))
request(route('/panel/tasima/temizle',job=job),{},csrf(page));check('SQL dosyasını incele' in get('/panel/tasima'),'Private staging files can be cleaned after review')
print('Migration HTTP checks completed:',DRIVER)
