<?php
declare(strict_types=1);

const ROOT = __DIR__ . '/..';
const TABLE_PREFIX = 'rh6_';

function e(mixed $value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function base_path(): string {
    $path = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    return $path === '/' || $path === '.' ? '' : rtrim($path, '/');
}
function url(string $route = '/', array $query = []): string {
    return base_path() . '/index.php?' . http_build_query(['route' => $route] + $query);
}
function asset(string $path): string { return base_path() . '/assets/v6/' . ltrim($path, '/'); }
function media(?string $path): string {
    if (!$path) return asset('placeholder.svg');
    if (preg_match('~^https?://~i', $path)) return $path;
    if (str_starts_with($path, 'uploads/')) return base_path() . '/' . $path;
    return asset('demo/' . basename($path));
}
function redirect(string $route, array $query = []): never { header('Location: ' . url($route, $query), true, 303); exit; }
function request_route(): string {
    if (isset($_GET['route'])) {
        if(!is_string($_GET['route'])) throw new InvalidArgumentException('Geçersiz sayfa adresi.');
        return '/' . trim($_GET['route'], '/');
    }
    $path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
    $base = base_path();
    if ($base && str_starts_with($path, $base . '/')) $path = substr($path, strlen($base));
    return in_array($path, ['', '/', '/index.php', '/panel.php'], true) ? '/' : '/' . trim($path, '/');
}
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void {
    if (!is_string($_POST['csrf'] ?? null) || !hash_equals(csrf_token(), $_POST['csrf'])) {
        http_response_code(419);
        throw new RuntimeException('Oturum doğrulanamadı. Sayfayı yenileyip tekrar deneyin.');
    }
}
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
function flash(string $message): void { $_SESSION['flash'] = $message; }
function take_flash(): ?string { $message = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $message; }
function slugify(string $text): string {
    $text = strtr($text, ['ı'=>'i','İ'=>'I','ş'=>'s','Ş'=>'S','ğ'=>'g','Ğ'=>'G','ü'=>'u','Ü'=>'U','ö'=>'o','Ö'=>'O','ç'=>'c','Ç'=>'C']);
    if (function_exists('iconv')) $text = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
    return trim(strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $text) ?? ''), '-');
}
function text_input(string $key, int $max = 1000, bool $required = false): string {
    $value = $_POST[$key] ?? '';
    if (!is_string($value)) throw new InvalidArgumentException('Geçersiz alan: ' . $key);
    $value = trim($value);
    if ($required && $value === '') throw new InvalidArgumentException('Lütfen zorunlu alanları doldurun.');
    $length = function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
    if ($length > $max) throw new InvalidArgumentException('Alan uzunluk sınırını aşıyor: ' . $key);
    return $value;
}
function password_input(string $key, bool $required=false): string {
    $value=$_POST[$key]??'';
    if(!is_string($value)||strlen($value)>72||($required&&$value==='')) throw new InvalidArgumentException('Geçerli bir şifre girin.');
    return $value;
}
function url_input(string $key): string {
    $value = text_input($key, 1000);
    if ($value !== '' && (!filter_var($value, FILTER_VALIDATE_URL) || !in_array(strtolower(parse_url($value, PHP_URL_SCHEME) ?? ''), ['http','https'], true))) throw new InvalidArgumentException('Geçerli bir http/https adresi girin.');
    return $value;
}
function checked_input(string $key): int { return isset($_POST[$key]) ? 1 : 0; }
function integer_input(string $key, int $default = 0): int {
    $value = $_POST[$key] ?? '';
    if ($value === '') return $default;
    if (!is_scalar($value) || filter_var($value, FILTER_VALIDATE_INT) === false || (int)$value < 0) throw new InvalidArgumentException('Geçerli bir pozitif sayı girin.');
    return (int)$value;
}
function date_input(string $key): ?string {
    $value = text_input($key, 30);
    if ($value === '') return null;
    $date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $value);
    $errors = DateTimeImmutable::getLastErrors();
    if (!$date || ($errors && ($errors['warning_count'] || $errors['error_count']))) throw new InvalidArgumentException('Geçerli bir tarih girin.');
    return $date->format('Y-m-d H:i:s');
}
function safe_html(string $input): string {
    $document = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $document->loadHTML('<?xml encoding="UTF-8"><div id="safe-body">' . $input . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors(); libxml_use_internal_errors($previous);
    $root = $document->getElementById('safe-body');
    if (!$root) return e($input);
    $allowed = ['p','br','b','strong','i','em','u','h2','h3','h4','ul','ol','li','blockquote','a','img','figure','figcaption','hr'];
    $clean = function (DOMNode $node) use (&$clean, $allowed): void {
        foreach (iterator_to_array($node->childNodes) as $child) {
            if ($child instanceof DOMElement) {
                $tag = strtolower($child->tagName);
                if (!in_array($tag, $allowed, true)) {
                    if (in_array($tag, ['script','style','iframe','object','embed','svg','math'], true)) { $node->removeChild($child); continue; }
                    $clean($child);
                    while ($child->firstChild) $node->insertBefore($child->firstChild, $child);
                    $node->removeChild($child); continue;
                }
                foreach (iterator_to_array($child->attributes) as $attribute) {
                    $name = strtolower($attribute->name);
                    if (!in_array($name, ['href','src','alt','title'], true)) { $child->removeAttribute($attribute->name); continue; }
                    if (in_array($name, ['href','src'], true) && !preg_match('~^(https?://|/|uploads/)~i', $attribute->value)) $child->removeAttribute($attribute->name);
                }
                if ($tag === 'a') $child->setAttribute('rel', 'noopener');
                $clean($child);
            }
        }
    };
    $clean($root);
    $html = ''; foreach ($root->childNodes as $child) $html .= $document->saveHTML($child);
    return $html;
}
function view(string $name, array $data = []): void { extract($data, EXTR_SKIP); require ROOT . '/views/' . $name . '.php'; }
function inline_asset(string $name): string { return (string)file_get_contents(ROOT . '/assets/v6/' . $name); }
function log_failure(Throwable $exception): void {
    $line = date('c') . ' ' . get_class($exception) . ' code=' . $exception->getCode() . ' ' . $exception->getFile() . ':' . $exception->getLine() . PHP_EOL;
    @file_put_contents(ROOT . '/storage/logs/app.log', $line, FILE_APPEND | LOCK_EX);
}
function installation_in_progress(): bool {
    if (!is_file(ROOT.'/storage/install.lock')) return false;
    $lock = @fopen(ROOT.'/storage/install.lock', 'r');
    if (!$lock) return true;
    $ready = flock($lock, LOCK_SH | LOCK_NB);
    if ($ready) flock($lock, LOCK_UN);
    fclose($lock);
    return !$ready;
}

final class Database {
    private static ?PDO $connection = null;
    public static function connect(array $config): PDO {
        if (($config['driver'] ?? 'mysql') === 'sqlite') {
            $pdo = new PDO('sqlite:' . $config['path']);
        } else {
            $dsn = 'mysql:host=' . $config['host'] . ';port=' . $config['port'] . ';dbname=' . $config['database'] . ';charset=utf8mb4';
            $pdo = new PDO($dsn, $config['username'], $config['password']);
        }
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        return $pdo;
    }
    public static function use(PDO $pdo): void { self::$connection = $pdo; unset($GLOBALS['reflex_settings_cache']); }
    public static function connection(): PDO {
        if (!self::$connection) self::$connection = self::connect((require ROOT . '/storage/site.php')['db']);
        return self::$connection;
    }
    public static function query(string $sql, array $parameters = []): PDOStatement {
        $statement = self::connection()->prepare($sql); $statement->execute($parameters); return $statement;
    }
    public static function rows(string $sql, array $parameters = []): array { return self::query($sql, $parameters)->fetchAll(); }
    public static function row(string $sql, array $parameters = []): ?array { return self::query($sql, $parameters)->fetch() ?: null; }
    public static function scalar(string $sql, array $parameters = []): mixed { return self::query($sql, $parameters)->fetchColumn(); }
    public static function save(string $table, array $data, ?int $id = null): int {
        $allowed = ['users','categories','news','ads','pages','settings','comments','news_sources','feed_items','source_runs','daily_stats','media','reactions','contacts','module_items','poll_votes','members','agencies','agency_items','agency_runs','agenda_items','agenda_health'];
        if (!in_array($table, $allowed, true)) throw new LogicException('Unknown table');
        $columns = array_keys($data);
        foreach ($columns as $column) if (!preg_match('/^[a-z_]+$/', $column)) throw new LogicException('Unknown column');
        if ($id) {
            self::query('UPDATE ' . TABLE_PREFIX . $table . ' SET ' . implode(', ', array_map(fn($column) => '`'.$column.'` = ?', $columns)) . ' WHERE id = ?', [...array_values($data), $id]);
            return $id;
        }
        self::query('INSERT INTO ' . TABLE_PREFIX . $table . ' (`' . implode('`,`', $columns) . '`) VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')', array_values($data));
        return (int)self::connection()->lastInsertId();
    }
}
function unique_slug(string $table, string $value, ?int $ignore = null): string {
    if (!in_array($table, ['users','categories','news','pages'], true)) throw new LogicException('Unknown table');
    $base = substr(slugify($value) ?: 'icerik', 0, 170); $slug = $base; $suffix = 2;
    while (Database::scalar('SELECT COUNT(*) FROM ' . TABLE_PREFIX . $table . ' WHERE slug = ? AND id <> ?', [$slug, $ignore ?? 0])) $slug = $base . '-' . $suffix++;
    return $slug;
}
function setting(string $key, string $fallback = ''): string {
    $GLOBALS['reflex_settings_cache'] ??= array_column(Database::rows('SELECT name, value FROM rh6_settings'), 'value', 'name');
    return (string)($GLOBALS['reflex_settings_cache'][$key] ?? $fallback);
}
function user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    return Database::row('SELECT id,name,email,role,active FROM rh6_users WHERE id = ?', [(int)$_SESSION['user_id']]);
}
function require_admin(): array {
    $user = user();
    if (!$user || !$user['active'] || !in_array($user['role'], ['admin','editor'], true)) redirect('/panel/giris');
    if (time() - (int)($_SESSION['last_activity'] ?? time()) > 7200) { session_destroy(); redirect('/panel/giris'); }
    $_SESSION['last_activity'] = time(); return $user;
}
function published_condition(string $alias = 'n'): string { return $alias . ".status = 'published' AND (" . $alias . '.published_at IS NULL OR ' . $alias . '.published_at <= ?)'; }
function news_rows(string $extra = '', array $parameters = [], int $limit = 20, int $offset=0, string $sort='latest'): array {
    $limit = max(1, min(100, $limit));
    $order=$sort==='popular'?'n.views DESC,n.published_at DESC,n.id DESC':'n.published_at DESC,n.id DESC';
    return Database::rows('SELECT n.*, c.name AS category_name,c.slug AS category_slug,u.name AS author_name,u.slug AS author_slug,u.public_profile AS author_public FROM rh6_news n LEFT JOIN rh6_categories c ON c.id = n.category_id LEFT JOIN rh6_users u ON u.id = n.author_id WHERE ' . published_condition() . ' ' . $extra . ' ORDER BY '.$order.' LIMIT ' . $limit.' OFFSET '.max(0,$offset), [date('Y-m-d H:i:s'), ...$parameters]);
}
function upload_image(string $field, ?string $current = null): ?string {
    $file = $_FILES[$field] ?? null;
    if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) return $current;
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 5 * 1024 * 1024) throw new InvalidArgumentException('Görsel yüklenemedi. En fazla 5 MB dosya seçin.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $extensions = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    if (!isset($extensions[$mime]) || !getimagesize($file['tmp_name'])) throw new InvalidArgumentException('JPG, PNG, WebP veya GIF görseli seçin.');
    $name = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($file['tmp_name'], ROOT . '/uploads/' . $name)) throw new RuntimeException('Görsel kaydedilemedi. uploads klasörünün yazma iznini kontrol edin.');
    if(function_exists('migrate_pro_schema')) Database::save('media',['path'=>'uploads/'.$name,'name'=>mb_substr(basename((string)$file['name']),0,255),'kind'=>'image','created_at'=>date('Y-m-d H:i:s')]);
    return 'uploads/' . $name;
}
function news_link(array $item): string { return url('/haber/'.$item['slug']); }
function format_date(?string $date): string { return $date ? date('d.m.Y H:i',strtotime($date)) : ''; }
function show_ad(string $placement): void {
    $now=date('Y-m-d H:i:s');$ads=Database::rows('SELECT * FROM rh6_ads WHERE active=1 AND placement=? AND (starts_at IS NULL OR starts_at<=?) AND (ends_at IS NULL OR ends_at>=?) ORDER BY priority DESC,id DESC',[$placement,$now,$now]);
    $pick=function(string $device)use($ads):?array{$matching=array_values(array_filter($ads,fn($a)=>in_array($a['device'],['all',$device],true)));if(!$matching)return null;$priority=$matching[0]['priority'];$matching=array_values(array_filter($matching,fn($a)=>(int)$a['priority']===(int)$priority));return $matching[random_int(0,count($matching)-1)];};
    $desktop=$pick('desktop');$mobile=$pick('mobile');$selected=[];
    if($desktop&&$mobile&&$desktop['id']===$mobile['id']){$desktop['device']='all';$selected[]=$desktop;}else{if($desktop){$desktop['device']='desktop';$selected[]=$desktop;}if($mobile){$mobile['device']='mobile';$selected[]=$mobile;}}
    foreach($selected as $ad){if(!$ad['image']&&!$ad['code'])continue;
        echo '<div class="ad device-'.e($ad['device']).' ad-slot-'.e($placement).'" data-slot="'.e($placement).'"><span>REKLAM</span>';
        if($ad['code'])echo $ad['code'];
        else{if($ad['target_url'])echo '<a href="'.e($ad['target_url']).'" target="_blank" rel="sponsored noopener">';echo '<img src="'.e(media($ad['image'])).'" alt="'.e($ad['name']).'">';if($ad['target_url'])echo '</a>';}
        if($placement==='mobile_sticky')echo '<button type="button" class="ad-close" aria-label="Reklamı kapat">×</button>';echo '</div>';
    }
}
