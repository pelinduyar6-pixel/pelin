<?php
declare(strict_types=1);
function render_article_body(string $html):void{
    $html=safe_html($html);$doc=new DOMDocument();$previous=libxml_use_internal_errors(true);
    try{$doc->loadHTML('<?xml encoding="utf-8"?><div id="article-body-root">'.$html.'</div>',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);$root=$doc->getElementById('article-body-root');
        if(!$root){echo $html;return;}$paragraphs=0;foreach($root->childNodes as $node)if($node instanceof DOMElement&&$node->tagName==='p'&&trim($node->textContent)!=='')$paragraphs++;
        $after=min(3,max(1,$paragraphs));$seen=0;foreach($root->childNodes as $node){echo $doc->saveHTML($node);if($node instanceof DOMElement&&$node->tagName==='p'&&trim($node->textContent)!==''&&++$seen===$after)show_ad('article_inline');}
        if(!$paragraphs)show_ad('article_inline');
    }finally{libxml_clear_errors();libxml_use_internal_errors($previous);}
}
function category_layouts():array{return ['auto'=>'Temaya göre otomatik','editorial'=>'Büyük haber + dört kart','showcase'=>'İki büyük + dört küçük','mosaic'=>'Asimetrik vitrin','compact'=>'Kompakt haber akışı'];}
function homepage_categories(array $categories):array{
    $config=json_decode(setting('home_categories','{}'),true)?:[];
    foreach($categories as &$category){$entry=$config[(string)$category['id']]??[];$category['home_enabled']=$entry['enabled']??1;$category['home_position']=$entry['position']??($category['sort_order']?:$category['id']);$category['home_layout']=$entry['layout']??'auto';}unset($category);
    usort($categories,fn($a,$b)=>($a['home_position']<=>$b['home_position'])?:($a['id']<=>$b['id']));return $categories;
}
function save_home_categories(array $categories):void{
    if(!isset($_POST['categories_present']))return; // Older clients keep their category selections.
    $primary=null;if(isset($_POST['home_primary_category'])){$primary=integer_input('home_primary_category');if($primary<0||($primary&&!in_array($primary,array_column($categories,'id'))))throw new InvalidArgumentException('Ana haber kategorisi bulunamadı.');}
    $config=[];foreach($categories as $category){$id=(int)$category['id'];$entry=$_POST['home_category'][$id]??[];if(!is_array($entry))throw new InvalidArgumentException('Kategori ayarı geçersiz.');$position=$entry['position']??50;$layout=$entry['layout']??'auto';if(!is_scalar($position)||filter_var($position,FILTER_VALIDATE_INT)===false||(int)$position<1||(int)$position>99||!is_string($layout)||!isset(category_layouts()[$layout]))throw new InvalidArgumentException('Kategori sırası 1–99 olmalı; geçerli görünüm seçin.');$config[$id]=['enabled'=>isset($entry['enabled'])?1:0,'position'=>(int)$position,'layout'=>$layout];}put_setting('home_categories',json_encode($config));if($primary!==null)put_setting('home_primary_category',(string)$primary);
}
function initialize_primary_category():void{
    if(setting('layout_v33_initialized'))return;
    $category=Database::row("SELECT * FROM rh6_categories WHERE slug='turkiye-gundemi'")?:Database::row("SELECT * FROM rh6_categories WHERE slug='gundem'");
    if(!$category)return; // The installer seeds categories after creating the schema.
    if($category['name']==='Gündem')Database::save('categories',['name'=>'Türkiye Gündemi'],(int)$category['id']);
    if(!Database::scalar("SELECT id FROM rh6_settings WHERE name='home_primary_category'"))put_setting('home_primary_category',(string)$category['id']);
    put_setting('layout_v33_initialized','1');
}
function layout_schema():void{
    initialize_primary_category();
    if(!setting('ai_v33_initialized')){if(!str_starts_with(setting('ai_model'),'gpt-5.6'))put_setting('ai_model','gpt-5.6-sol');put_setting('ai_v33_initialized','1');}
    foreach(['home_categories'=>'{}','market_refresh_minutes'=>'10','sports_refresh_minutes'=>'15','sports_mode'=>'ntv','market_attempt'=>'','sports_attempt'=>'','market_status'=>'','sports_status'=>'','market_btc_unit'=>'TRY','market_field_times'=>'{}','footer_highlights'=>'1','app_google_play'=>'','app_app_store'=>'','app_gallery'=>''] as $key=>$value)if(!Database::scalar('SELECT id FROM rh6_settings WHERE name=?',[$key]))put_setting($key,$value);
    if(!setting('layout_v32_initialized')){
        // Enable complete automatic feeds only if no manual values were entered.
        $manual=false;foreach(array_keys(market_fields()) as $key)if(setting($key)!=='')$manual=true;
        if(setting('market_mode','manual')==='manual'&&!$manual)put_setting('market_mode','public');
        put_setting('layout_v32_initialized','1');
    }
}
