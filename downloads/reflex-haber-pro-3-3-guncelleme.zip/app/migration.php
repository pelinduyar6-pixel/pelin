<?php
declare(strict_types=1);

/* Public-content migration. Uploaded SQL is data, never executable SQL. */
const MIGRATION_SQL_LIMIT=33554432;
const MIGRATION_ZIP_LIMIT=67108864;

function migration_statements(string $sql):Generator {
    $statement='';$quote='';$line=false;$block=false;$escaped=false;$length=strlen($sql);
    for($i=0;$i<$length;$i++){
        $c=$sql[$i];$next=$sql[$i+1]??'';
        if($line){if($c==="\n"){$line=false;$statement.=' ';}continue;}
        if($block){if($c==='*'&&$next==='/'){$block=false;$i++;$statement.=' ';}continue;}
        if($quote!==''){
            $statement.=$c;
            if($escaped){$escaped=false;continue;}
            if($c==='\\'){$escaped=true;continue;}
            if($c===$quote){if($next===$quote){$statement.=$next;$i++;}else $quote='';}
        }elseif($c==='-'&&$next==='-'&&ctype_space($sql[$i+2]??' ')){$line=true;$i++;}
        elseif($c==='#')$line=true;
        elseif($c==='/'&&$next==='*'){$block=true;$i++;}
        elseif(in_array($c,["'",'"','`'],true)){$quote=$c;$statement.=$c;}
        elseif($c===';'){if(trim($statement)!=='')yield trim($statement);$statement='';}
        else $statement.=$c;
        if(strlen($statement)>12582912)throw new InvalidArgumentException('Tek SQL kaydı çok büyük. Dökümü daha küçük INSERT gruplarıyla dışa aktarın.');
    }
    if($quote!==''||$block)throw new InvalidArgumentException('SQL dosyası eksik veya kapanmamış bir metin içeriyor.');
    if(trim($statement)!=='')yield trim($statement);
}
function migration_identifier(string $value):string {
    $value=trim($value," \t\r\n`");
    if(!preg_match('/^[a-zA-Z_][a-zA-Z0-9_$]{0,127}$/D',$value))throw new InvalidArgumentException('Desteklenmeyen tablo veya alan adı.');
    return $value;
}
function migration_literals(string $values):Generator {
    $i=0;$length=strlen($values);$space=static function()use(&$i,$length,$values){while($i<$length&&ctype_space($values[$i]))$i++;};
    while(true){
        $space();if($i===$length)return;
        if($values[$i]!=='(')throw new InvalidArgumentException('INSERT kaydında yalnızca düz VALUES verisi desteklenir.');$i++;$row=[];
        while(true){
            $space();$c=$values[$i]??'';$value='';
            if($c==="'"||$c==='"'){
                $quote=$c;$i++;$closed=false;
                while($i<$length){$c=$values[$i++];
                    if($c==='\\'){$x=$values[$i++]??'';$value.=match($x){'n'=>"\n",'r'=>"\r",'t'=>"\t",'0'=>"\0",'Z'=>chr(26),default=>$x};}
                    elseif($c===$quote){if(($values[$i]??'')===$quote){$value.=$quote;$i++;}else{$closed=true;break;}}
                    else $value.=$c;
                    if(strlen($value)>1048576)throw new InvalidArgumentException('Bir kaynak alanı 1 MB sınırını aşıyor.');
                }
                if(!$closed)throw new InvalidArgumentException('SQL metni kapanmamış.');
            }else{
                $start=$i;while($i<$length&&!in_array($values[$i],[',',')'],true))$i++;$token=trim(substr($values,$start,$i-$start));
                if(strcasecmp($token,'NULL')===0)$value=null;
                elseif(preg_match('/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/iD',$token))$value=$token;
                else throw new InvalidArgumentException('SQL içinde fonksiyon veya ifade var. Metin/sayı/NULL içeren bir MySQL INSERT dökümü kullanın.');
            }
            $row[]=$value;if(count($row)>200)throw new InvalidArgumentException('Bir tabloda en fazla 200 alan desteklenir.');
            $space();$separator=$values[$i++]??'';if($separator===')')break;if($separator!==',')throw new InvalidArgumentException('SQL kayıt ayracı geçersiz.');
        }
        yield $row;$space();if($i===$length)return;if($values[$i++]!==',')throw new InvalidArgumentException('INSERT sonunda desteklenmeyen işlem var.');
    }
}
function migration_parse_sql(string $file,string $directory):array {
    if(!is_file($file)||filesize($file)>MIGRATION_SQL_LIMIT)throw new InvalidArgumentException('SQL dosyası en fazla 32 MB olabilir.');
    $sql=file_get_contents($file);if(!mb_check_encoding($sql,'UTF-8'))throw new InvalidArgumentException('SQL dosyasını UTF-8 olarak dışa aktarın.');$sql=preg_replace('/^\xEF\xBB\xBF/','',$sql);
    $tables=[];$total=0;
    foreach(migration_statements($sql) as $statement){
        if(preg_match('/^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(`?[a-zA-Z_][a-zA-Z0-9_$]*`?)\s*\((.*)\)\s*.*$/isD',$statement,$match)){
            $table=migration_identifier($match[1]);$columns=[];
            foreach(preg_split('/,\s*(?:\r?\n|(?=`?[a-zA-Z_][a-zA-Z0-9_$]*`?\s+))/', $match[2]) as $definition){
                if(preg_match('/^\s*(`?[a-zA-Z_][a-zA-Z0-9_$]*`?)\s+(?:tinyint|smallint|mediumint|bigint|int|integer|varchar|char|text|tinytext|mediumtext|longtext|datetime|timestamp|date|time|decimal|float|double|enum|set|boolean|bool|blob|json|varbinary|binary)\b/i',$definition,$column))$columns[]=migration_identifier($column[1]);
            }
            $tables[$table]??=['columns'=>$columns,'count'=>0,'file'=>hash('sha256',$table).'.jsonl'];
            if(!$tables[$table]['columns'])$tables[$table]['columns']=$columns;
        }elseif(preg_match('/^INSERT\s+(?:IGNORE\s+)?INTO\s+(`?[a-zA-Z_][a-zA-Z0-9_$]*`?)\s*(?:\(([^)]*)\))?\s*VALUES\s*(.*)$/isD',$statement,$match)){
            $table=migration_identifier($match[1]);$columns=trim($match[2]??'')!==''?array_map('migration_identifier',explode(',',$match[2])):($tables[$table]['columns']??[]);
            if(!$columns||count($columns)>200||count(array_unique($columns))!==count($columns))throw new InvalidArgumentException('Tablo alanları okunamadı: '.$table.'. CREATE TABLE veya alan adlı INSERT kullanın.');
            $tables[$table]??=['columns'=>$columns,'count'=>0,'file'=>hash('sha256',$table).'.jsonl'];
            $handle=fopen($directory.'/'.$tables[$table]['file'],'ab');if(!$handle)throw new RuntimeException('Aktarım verileri yazılamadı.');chmod($directory.'/'.$tables[$table]['file'],0600);
            try{foreach(migration_literals($match[3]) as $values){
                if(count($values)!==count($columns))throw new InvalidArgumentException('Alan ve değer sayısı uyuşmuyor: '.$table);
                if(++$total>150000)throw new InvalidArgumentException('Tek dosyada en fazla 150.000 kayıt desteklenir. Dosyayı parçalara ayırın.');
                fwrite($handle,json_encode(array_combine($columns,$values),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)."\n");$tables[$table]['count']++;
                $tables[$table]['columns']=array_values(array_unique([...$tables[$table]['columns'],...$columns]));
            }}finally{fclose($handle);}
        }elseif(preg_match('/^(?:INSERT|REPLACE|COPY)\b/i',$statement))throw new InvalidArgumentException('Bu döküm biçimi desteklenmiyor. MySQL INSERT VALUES biçiminde dışa aktarın.');
        if(count($tables)>150)throw new InvalidArgumentException('Tek dosyada en fazla 150 tablo desteklenir.');
        // DDL, SET, triggers and procedures are deliberately not executed.
    }
    $tables=array_filter($tables,fn($table)=>$table['count']>0);
    if(!$tables)throw new InvalidArgumentException('Dosyada okunabilir INSERT kaydı bulunamadı.');
    return $tables;
}
function migration_root(bool $create=true):string {
    $root=ROOT.'/storage/migrations';if($create&&!is_dir($root)&&!@mkdir($root,0700,true))throw new RuntimeException('Taşıma klasörü oluşturulamadı.');
    return $root;
}
function migration_dir(string $id):string {
    if(!preg_match('/^[a-f0-9]{32}$/D',$id))throw new InvalidArgumentException('Aktarım numarası geçersiz.');return migration_root().'/'.$id;
}
function migration_load(string $id,int $owner):array {
    $path=migration_dir($id).'/job.json';$job=is_file($path)?json_decode(file_get_contents($path),true):null;
    if(!$job||($job['owner']??0)!==$owner)throw new InvalidArgumentException('Aktarım bulunamadı veya bu hesaba ait değil.');return $job;
}
function migration_store(array $job):void {
    $path=migration_dir($job['id']).'/job.json';$temp=$path.'.tmp';
    if(file_put_contents($temp,json_encode($job,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),LOCK_EX)===false||!rename($temp,$path))throw new RuntimeException('Aktarım ilerlemesi kaydedilemedi.');chmod($path,0600);
}
function migration_rows(array $job,string $table,int $offset=0,int $limit=PHP_INT_MAX,int $byteOffset=0):Generator {
    if(!isset($job['tables'][$table]))throw new InvalidArgumentException('Kaynak tablosu bulunamadı.');
    $handle=fopen(migration_dir($job['id']).'/'.$job['tables'][$table]['file'],'rb');if(!$handle)throw new RuntimeException('Aktarım kayıtları bulunamadı.');
    try{$index=0;$count=0;if($byteOffset>0){fseek($handle,$byteOffset);$index=$offset;}while($count<$limit&&($line=fgets($handle,8388608))!==false){if($index++<$offset)continue;$count++;yield $index-1=>json_decode($line,true,512,JSON_THROW_ON_ERROR);}return ftell($handle);}finally{fclose($handle);}
}
function migration_upload(string $field,int $limit,array $extensions):array {
    $file=$_FILES[$field]??null;if(!$file||!is_scalar($file['error']??null)||$file['error']!==UPLOAD_ERR_OK)throw new InvalidArgumentException('Dosya yüklenemedi. PHP yükleme sınırını ve dosyayı kontrol edin.');
    if($file['size']>$limit||!is_uploaded_file($file['tmp_name'])||!in_array(strtolower(pathinfo($file['name'],PATHINFO_EXTENSION)),$extensions,true))throw new InvalidArgumentException('Dosya biçimi veya boyutu desteklenmiyor.');return $file;
}
function migration_create(array $upload,int $owner):array {
    $id=bin2hex(random_bytes(16));$dir=migration_dir($id);mkdir($dir,0700);$path=$dir.'/source.sql';
    try{
        if(!move_uploaded_file($upload['tmp_name'],$path))throw new RuntimeException('SQL dosyası kaydedilemedi.');chmod($path,0600);
        $tables=migration_parse_sql($path,$dir);
        $job=['id'=>$id,'owner'=>$owner,'created_at'=>date('Y-m-d H:i:s'),'filename'=>mb_substr(basename($upload['name']),0,150),'hash'=>hash_file('sha256',$path),'tables'=>$tables,'stage'=>'mapping','mapping'=>[],'images'=>[],'cursor'=>0,'imported'=>0,'duplicates'=>0,'skipped'=>0,'missing_images'=>0];
        migration_store($job);return $job;
    }catch(Throwable $error){foreach(glob($dir.'/*')?:[] as $file)if(is_file($file))unlink($file);rmdir($dir);throw $error;}
}
function migration_guess(array $job):array {
    $mapping=['news_table'=>'','category_table'=>'','author_id'=>'','fallback_category'=>''];
    $names=['title'=>['title','baslik','haber_baslik','post_title'],'body'=>['body','icerik','content','haber_icerik','post_content'],'id'=>['id','haber_id','ID'],'category_id'=>['category_id','kategori_id','kat_id'],'summary'=>['summary','spot','ozet','description','post_excerpt'],'slug'=>['slug','seo_url','sef','post_name'],'image'=>['image','resim','foto','kapak','picture'],'date'=>['published_at','tarih','date','post_date'],'seo_title'=>['seo_title','meta_title'],'seo_description'=>['seo_description','meta_description'],'category_name'=>['name','adi','kategori_adi','kategori','title'],'category_legacy_id'=>['id','kategori_id','cat_id'],'category_slug'=>['slug','sef','seo_url']];
    foreach($job['tables'] as $table=>$info){$lower=array_map('strtolower',$info['columns']);if(!$mapping['news_table']&&array_intersect($lower,array_map('strtolower',$names['title']))&&array_intersect($lower,$names['body']))$mapping['news_table']=$table;if(!$mapping['category_table']&&preg_match('/categor|kategori|katlar/i',$table))$mapping['category_table']=$table;}
    foreach($names as $key=>$candidates){$table=str_starts_with($key,'category_')&&$key!=='category_id'?$mapping['category_table']:$mapping['news_table'];$mapping[$key]='';foreach($job['tables'][$table]['columns']??[] as $column)if(in_array(strtolower($column),array_map('strtolower',$candidates),true)){$mapping[$key]=$column;break;}}
    return $mapping;
}
function migration_validate_mapping(array $job,array $input):array {
    $fields=['news_table','category_table','id','title','body','category_id','summary','slug','image','date','seo_title','seo_description','category_legacy_id','category_name','category_slug','fallback_category','author_id'];$map=[];
    foreach($fields as $field){$value=$input[$field]??'';if(!is_scalar($value))throw new InvalidArgumentException('Alan seçimi geçersiz.');$map[$field]=(string)$value;}
    if(!isset($job['tables'][$map['news_table']]))throw new InvalidArgumentException('Haber tablosunu seçin.');
    if($map['category_table']!==''&&!isset($job['tables'][$map['category_table']]))throw new InvalidArgumentException('Kategori tablosu geçersiz.');
    foreach(['id','title','body','category_id','summary','slug','image','date','seo_title','seo_description','category_legacy_id','category_name','category_slug'] as $field){$table=str_starts_with($field,'category_')&&$field!=='category_id'?$map['category_table']:$map['news_table'];if($map[$field]!==''&&!in_array($map[$field],$job['tables'][$table]['columns']??[],true))throw new InvalidArgumentException('Seçilen kaynak alanı tabloda yok.');}
    if(!$map['title']||!$map['body'])throw new InvalidArgumentException('Haber başlığı ve içerik alanını seçin.');
    if($map['category_table']!==''&&(!$map['category_legacy_id']||!$map['category_name']||!$map['category_id']))throw new InvalidArgumentException('Kategori ilişkisi için eski kategori ID, kategori adı ve haberin kategori ID alanlarını seçin.');
    foreach(['fallback_category'=>'categories','author_id'=>'users'] as $field=>$table){if($map[$field]!==''&&(!ctype_digit($map[$field])||!Database::scalar('SELECT id FROM rh6_'.$table.' WHERE id=?',[(int)$map[$field]])))throw new InvalidArgumentException('Hedef kategori veya yazar bulunamadı.');}
    return $map;
}
function migration_category_plan(array $job,array $map,array $targets=[]):array {
    if($map['category_table']==='')return [];$plan=[];
    foreach(migration_rows($job,$map['category_table']) as $row){
        $old=(string)($row[$map['category_legacy_id']]??'');$name=mb_substr(trim((string)($row[$map['category_name']]??'')),0,100);
        if($old===''||$name==='')continue;if(isset($plan[$old]))throw new InvalidArgumentException('Kaynakta aynı kategori ID birden fazla kez geçiyor.');if(count($plan)>=2000)throw new InvalidArgumentException('En fazla 2.000 kategori desteklenir.');
        $slug=slugify((string)($row[$map['category_slug']]??$name));$slug=substr($slug?:slugify($name),0,170)?:'kategori';
        $chosen=(string)($targets[$old]??'');$existing=$chosen!==''?Database::row('SELECT * FROM rh6_categories WHERE id=?',[(int)$chosen]):Database::row('SELECT * FROM rh6_categories WHERE slug=?',[$slug]);
        if($chosen!==''&&(!ctype_digit($chosen)||!$existing))throw new InvalidArgumentException('Kategori eşleştirme seçimi geçersiz.');
        $free=ctype_digit($old)&&(int)$old>0&&(int)$old<=2147483647&&!Database::scalar('SELECT id FROM rh6_categories WHERE id=?',[(int)$old]);
        $plan[$old]=['name'=>$name,'slug'=>$slug,'target'=>$existing?(int)$existing['id']:null,'target_name'=>$existing['name']??'Yeni kategori','preserve'=>$free&&!$existing,'choice'=>$chosen];
    }
    return $plan;
}
function migration_safe_image_path(string $path):string {
    $path=str_replace('\\','/',rawurldecode($path));if(str_contains($path,"\0")||preg_match('~^(?:/|[a-zA-Z]:)~',$path))throw new InvalidArgumentException('ZIP içinde mutlak dosya yolu var.');
    $parts=explode('/',$path);if(in_array('..',$parts,true))throw new InvalidArgumentException('ZIP içinde üst klasöre çıkan dosya yolu var.');return implode('/',array_filter($parts,fn($part)=>$part!==''&&$part!=='.'));
}
function migration_import_images(string $archive,array $job):array {
    if(filesize($archive)>MIGRATION_ZIP_LIMIT)throw new InvalidArgumentException('Görsel ZIP dosyası en fazla 64 MB olabilir.');
    if(!class_exists('PharData'))throw new InvalidArgumentException('Görsel ZIP işlemi için hostingde PHP Phar uzantısını etkinleştirin.');
    migration_validate_zip($archive);
    $manifest=[];$total=0;$count=0;$zip=new PharData($archive);$base='phar://'.str_replace('\\','/',realpath($archive)).'/';
    foreach(new RecursiveIteratorIterator($zip,RecursiveIteratorIterator::SELF_FIRST) as $entry){
        $path=migration_safe_image_path(substr(str_replace('\\','/',$entry->getPathname()),strlen($base)));
        if($entry->isLink())throw new InvalidArgumentException('ZIP içinde bağlantı dosyası desteklenmiyor.');if($entry->isDir())continue;
        if(++$count>5000||$entry->getSize()>10485760||($total+=$entry->getSize())>268435456)throw new InvalidArgumentException('ZIP açıldığında boyut veya dosya sayısı sınırını aşıyor.');
        $extension=strtolower(pathinfo($path,PATHINFO_EXTENSION));if(!in_array($extension,['jpg','jpeg','png','gif','webp'],true))continue;
        $manifest[]=['entry'=>$entry,'path'=>$path,'extension'=>$extension];
    }
    if($total>max(10485760,filesize($archive)*100))throw new InvalidArgumentException('ZIP sıkıştırma oranı çok yüksek.');
    return migration_save_images($manifest,$job);
}
function migration_upload_budget():int {
    $parse=static function(string $value):int {$value=trim($value);$number=(float)$value;return (int)($number*match(strtolower(substr($value,-1))){'g'=>1073741824,'m'=>1048576,'k'=>1024,default=>1});};
    $limits=[8388608];$post=$parse(ini_get('post_max_size'));$file=$parse(ini_get('upload_max_filesize'));
    if($post>0)$limits[]=max(0,$post-262144);if($file>0)$limits[]=$file;return min($limits);
}
function migration_import_directory(array $job):array {
    $files=$_FILES['migration_files']??null;$paths=$_POST['image_paths']??null;
    if(!is_array($files)||!is_array($files['name']??null)||!is_array($paths)||count($files['name'])!==count($paths)||count($paths)<1||count($paths)>10)throw new InvalidArgumentException('Klasör yüklemesinde her istekte 1–10 görsel gönderin.');
    $entries=[];
    foreach($paths as $index=>$path){
        if(!is_string($path)||strlen($path)>1000)throw new InvalidArgumentException('Görselin klasör yolu geçersiz.');
        $path=migration_safe_image_path($path);$tmp=$files['tmp_name'][$index]??null;$error=$files['error'][$index]??null;
        if($error!==UPLOAD_ERR_OK||!is_string($tmp)||!is_uploaded_file($tmp)||filesize($tmp)>10485760||!in_array(strtolower(pathinfo($path,PATHINFO_EXTENSION)),['jpg','jpeg','png','gif','webp'],true))throw new InvalidArgumentException('Klasördeki görsel yüklenemedi. Dosya biçimini ve sunucu yükleme sınırını kontrol edin.');
        $entries[]=['path'=>$path,'file'=>$tmp];
    }
    return migration_save_images($entries,$job);
}
function migration_save_images(array $entries,array $job):array {
    if(!$entries)throw new InvalidArgumentException('JPG, PNG, GIF veya WebP görsel bulunamadı.');
    $validated=[];$mime=new finfo(FILEINFO_MIME_TYPE);$sizes=[];
    foreach($job['images'] as $path=>$target)$sizes[$path]=is_file(ROOT.'/'.$target)?filesize(ROOT.'/'.$target):0;
    foreach($entries as $item){$bytes=isset($item['file'])?file_get_contents($item['file']):$item['entry']->getContent();$type=$mime->buffer($bytes);$image=@getimagesizefromstring($bytes);$extensions=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
        if(!$image||!isset($extensions[$type])||strlen($bytes)>10485760||$image[0]*$image[1]>40000000)throw new InvalidArgumentException('Görsel doğrulanamadı: '.mb_substr($item['path'],0,100));
        $sizes[$item['path']]=strlen($bytes);$validated[]=array_merge($item,['name'=>hash('sha256',$bytes).'.'.$extensions[$type]]);
    }
    if(count($sizes)>5000||array_sum($sizes)>268435456)throw new InvalidArgumentException('Bu aktarımda en fazla 5.000 görsel ve toplam 256 MB desteklenir.');
    $dir=ROOT.'/uploads/migration/'.$job['id'];if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new RuntimeException('Görsel klasörü yazılamıyor.');$images=[];
    foreach($validated as $item){$bytes=isset($item['file'])?file_get_contents($item['file']):$item['entry']->getContent();if(file_put_contents($dir.'/'.$item['name'],$bytes,LOCK_EX)===false)throw new RuntimeException('Görsel kaydedilemedi.');chmod($dir.'/'.$item['name'],0644);$images[$item['path']]='uploads/migration/'.$job['id'].'/'.$item['name'];}
    return $images;
}
function migration_validate_zip(string $archive):void {
    $handle=fopen($archive,'rb');if(!$handle)throw new InvalidArgumentException('ZIP okunamadı.');
    try{
        $length=filesize($archive);fseek($handle,max(0,$length-65557));$end=fread($handle,65557);$position=strrpos($end,"PK\x05\x06");
        if($position===false||strlen($end)-$position<22)throw new InvalidArgumentException('Standart bir ZIP dosyası kullanın.');
        $header=unpack('vdisk/vstart/vdisk_count/vcount/Vsize/Voffset/vcomment',substr($end,$position+4,18));
        if($header['disk']!==0||$header['start']!==0||$header['count']!==$header['disk_count']||$header['count']>5000||$header['count']===65535||$header['offset']+$header['size']>$length)throw new InvalidArgumentException('ZIP64, çok parçalı veya 5.000 dosyayı aşan ZIP desteklenmiyor.');
        fseek($handle,$header['offset']);$total=0;
        for($i=0;$i<$header['count'];$i++){
            $record=fread($handle,46);if(strlen($record)!==46||substr($record,0,4)!=="PK\x01\x02")throw new InvalidArgumentException('ZIP dizini bozuk.');
            $flags=unpack('v',substr($record,8,2))[1];$method=unpack('v',substr($record,10,2))[1];$size=unpack('V',substr($record,24,4))[1];$nameSize=unpack('v',substr($record,28,2))[1];$extra=unpack('v',substr($record,30,2))[1];$comment=unpack('v',substr($record,32,2))[1];$attributes=unpack('V',substr($record,38,4))[1];
            if(($flags&1)||!in_array($method,[0,8],true)||(($attributes>>16)&0170000)===0120000||$size>10485760||($total+=$size)>268435456||$nameSize===0)throw new InvalidArgumentException('ZIP içinde desteklenmeyen veya boyut sınırını aşan kayıt var.');
            $name=fread($handle,$nameSize);migration_safe_image_path($name);if($extra+$comment)fseek($handle,$extra+$comment,SEEK_CUR);
        }
        if($total>max(10485760,$length*100))throw new InvalidArgumentException('ZIP sıkıştırma oranı çok yüksek.');
    }finally{fclose($handle);}
}
function migration_image(string $old,array $images):?string {
    $path=parse_url(trim($old),PHP_URL_PATH);if(!is_string($path)||$path==='')return null;$path=ltrim(rawurldecode(str_replace('\\','/',$path)),'/');
    if(in_array('..',explode('/',$path),true)||str_contains($path,"\0"))return null;
    if(isset($images[$path]))return $images[$path];$matches=[];
    foreach($images as $source=>$new)if(str_ends_with('/'.$path,'/'.$source)||str_ends_with('/'.$source,'/'.$path))$matches[$new]=true;
    if(count($matches)===1)return array_key_first($matches);
    if($matches)return null;foreach($images as $source=>$new)if(basename($source)===basename($path))$matches[$new]=true;
    return count($matches)===1?array_key_first($matches):null;
}
function migration_body(string $body,array $images):string {
    $body=safe_html(mb_substr($body,0,200000));if($body===''||!str_contains($body,'<img'))return $body;
    $doc=new DOMDocument();$previous=libxml_use_internal_errors(true);$doc->loadHTML('<?xml encoding="UTF-8"><div id="migration-body">'.$body.'</div>',LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD);libxml_clear_errors();libxml_use_internal_errors($previous);
    foreach(iterator_to_array($doc->getElementsByTagName('img')) as $image){$mapped=migration_image($image->getAttribute('src'),$images);if($mapped){$image->setAttribute('src',media($mapped));$image->removeAttribute('srcset');}else $image->parentNode->removeChild($image);}
    $html='';foreach($doc->getElementById('migration-body')->childNodes as $node)$html.=$doc->saveHTML($node);return $html;
}
function migration_start(array $job):array {
    if($job['stage']!=='preview')throw new InvalidArgumentException('Önce alan eşleştirmesini kaydedip önizlemeyi kontrol edin.');
    $plan=migration_category_plan($job,$job['mapping'],$job['targets']??[]);$pdo=Database::connection();$pdo->beginTransaction();$map=[];
    // Reserve all free legacy IDs before allocating automatic IDs for collisions.
    uasort($plan,fn($a,$b)=>(int)$b['preserve']<=>(int)$a['preserve']);
    try{foreach($plan as $old=>$category){
        if($category['target']){$map[$old]=$category['target'];continue;}
        $data=['name'=>$category['name'],'slug'=>unique_slug('categories',$category['slug']),'sort_order'=>0];if($category['preserve'])$data['id']=(int)$old;
        $map[$old]=Database::save('categories',$data);
        $home=json_decode(setting('home_categories','{}'),true)?:[];$home[(string)$map[$old]]=['enabled'=>0,'position'=>1000+(int)$map[$old],'layout'=>'auto'];put_setting('home_categories',json_encode($home));
    }$pdo->commit();}catch(Throwable $error){$pdo->rollBack();unset($GLOBALS['reflex_settings_cache']);throw $error;}
    $job['category_map']=$map;$job['stage']='importing';migration_store($job);return $job;
}
function migration_batch(array $job,int $size=100):array {
    if($job['stage']!=='importing')throw new InvalidArgumentException('Aktarım başlatılmadı.');$map=$job['mapping'];$pdo=Database::connection();$pdo->beginTransaction();
    $stream=migration_rows($job,$map['news_table'],$job['cursor'],max(1,min(100,$size)),$job['byte_offset']??0);
    try{foreach($stream as $index=>$row){
        $job['cursor']=$index+1;$key=hash('sha256',$job['hash'].'|'.$map['news_table'].'|'.$index);
        if(Database::scalar('SELECT id FROM rh6_news WHERE migration_key=?',[$key])){$job['duplicates']++;continue;}
        $title=mb_substr(trim(strip_tags((string)($row[$map['title']]??''))),0,255);$rawBody=(string)($row[$map['body']]??'');
        if($title===''||trim(strip_tags($rawBody))===''){$job['skipped']++;continue;}
        $oldCategory=(string)($row[$map['category_id']]??'');$category=$job['category_map'][$oldCategory]??($map['fallback_category']!==''?(int)$map['fallback_category']:null);
        $oldImage=(string)($row[$map['image']]??'');$image=migration_image($oldImage,$job['images']);if($oldImage!==''&&!$image)$job['missing_images']++;
        $now=date('Y-m-d H:i:s');$date=null;$rawDate=(string)($row[$map['date']]??'');if(preg_match('/^\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?$/D',$rawDate)&&($timestamp=strtotime($rawDate))!==false&&$timestamp>0)$date=date('Y-m-d H:i:s',$timestamp);
        $data=['title'=>$title,'slug'=>unique_slug('news',(string)($row[$map['slug']]??'')?:$title),'body'=>migration_body($rawBody,$job['images']),'summary'=>mb_substr(strip_tags((string)($row[$map['summary']]??'')),0,1000),'image'=>$image,'category_id'=>$category,'author_id'=>$map['author_id']!==''?(int)$map['author_id']:null,'editor_id'=>$job['owner'],'status'=>'draft','kind'=>'article','published_at'=>$date,'created_at'=>$date??$now,'updated_at'=>$now,'seo_title'=>mb_substr(strip_tags((string)($row[$map['seo_title']]??'')),0,255),'seo_description'=>mb_substr(strip_tags((string)($row[$map['seo_description']]??'')),0,500),'seo_autofill'=>1,'allow_comments'=>1,'is_demo'=>0,'migration_key'=>$key];
        Database::save('news',seo_autofill($data));$job['imported']++;
    }$job['byte_offset']=$stream->getReturn();$pdo->commit();}catch(Throwable $error){$pdo->rollBack();throw $error;}
    if($job['cursor']>=$job['tables'][$map['news_table']]['count'])$job['stage']='complete';migration_store($job);return $job;
}
function migration_forget(array $job):void {
    $dir=migration_dir($job['id']);foreach(glob($dir.'/*')?:[] as $path)if(is_file($path))unlink($path);rmdir($dir);
    // Public images referenced by imported records are retained. Before import, remove only this job's images.
    if(!in_array($job['stage'],['importing','complete'],true)){$images=ROOT.'/uploads/migration/'.$job['id'];foreach(glob($images.'/*')?:[] as $path)if(is_file($path))unlink($path);if(is_dir($images))rmdir($images);}
}
