<?php
declare(strict_types=1);
function migration_admin_dispatch(string $module,string $action,array $currentUser,array $categories,array $allAuthors):bool {
    if($module!=='tasima')return false;
    if($currentUser['role']!=='admin'){http_response_code(403);view('error',['message'=>'Veri taşıma için yönetici yetkisi gerekiyor.']);return true;}
    $title='Veri Taşıma';$error='';$job=null;$id=is_scalar($_GET['job']??null)?(string)($_GET['job']??''):'';$lock=null;$json=is_post()&&str_contains($_SERVER['HTTP_ACCEPT']??'','application/json');
    try{
        if($id!=='')$job=migration_load($id,(int)$currentUser['id']);
        if(is_post()){
            verify_csrf();if(!in_array($action,['yukle','eslestir','gorseller','klasor','baslat','devam','temizle'],true))throw new InvalidArgumentException('Taşıma işlemi geçersiz.');
            if($action==='yukle'){
                $job=migration_create(migration_upload('sql_file',MIGRATION_SQL_LIMIT,['sql']),(int)$currentUser['id']);$id=$job['id'];
                if(($_FILES['image_zip']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE)migration_admin_zip($job);
            }
            else{
                if(!$job)throw new InvalidArgumentException('Önce SQL dosyasını yükleyin.');
                $lock=fopen(migration_dir($id).'/job.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new InvalidArgumentException('Bu aktarım çalışıyor. Biraz sonra tekrar deneyin.');$job=migration_load($id,(int)$currentUser['id']);
                if($action==='eslestir'){
                    if(!in_array($job['stage'],['mapping','preview'],true))throw new InvalidArgumentException('Başlamış aktarımın eşleştirmesi değiştirilemez. Yeni aktarım açın.');
                    $map=migration_validate_mapping($job,is_array($_POST['map']??null)?$_POST['map']:[]);$targets=is_array($_POST['targets']??null)?$_POST['targets']:[];migration_category_plan($job,$map,$targets);$job['mapping']=$map;$job['targets']=$targets;$job['stage']='preview';migration_store($job);
                }elseif(in_array($action,['gorseller','klasor'],true)){
                    if(!in_array($job['stage'],['mapping','preview'],true))throw new InvalidArgumentException('Görselleri aktarımı başlatmadan önce yükleyin.');
                    if($action==='gorseller')migration_admin_zip($job);
                    else{$job['images']=array_merge($job['images'],migration_import_directory($job));migration_store($job);}
                }elseif($action==='baslat'){
                    if(($_POST['reviewed']??'')!=='1')throw new InvalidArgumentException('Önizlemeyi kontrol ettiğinizi işaretleyin.');
                    $job=migration_start($job);
                }
                elseif($action==='devam')$job=migration_batch($job);
                elseif($action==='temizle'){migration_forget($job);$job=null;}
            }
            if($lock){flock($lock,LOCK_UN);fclose($lock);$lock=null;}
            if($json){header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>true,'redirect'=>url('/panel/tasima',['job'=>$job['id']]),'upload_url'=>url('/panel/tasima/klasor',['job'=>$job['id']]),'images'=>count($job['images'])],JSON_UNESCAPED_UNICODE);return true;}
            flash($action==='temizle'?'Aktarım dosyaları temizlendi. Aktarılmış haberler korundu.':'Taşıma adımı kaydedildi.');redirect('/panel/tasima',$job?['job'=>$job['id']]:[]);
        }
    }catch(InvalidArgumentException|UnexpectedValueException $exception){$error=$exception->getMessage();http_response_code(422);}
    finally{if($lock){flock($lock,LOCK_UN);fclose($lock);}}
    if($json){header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'message'=>$error,'redirect'=>$job?url('/panel/tasima',['job'=>$job['id']]):null],JSON_UNESCAPED_UNICODE);return true;}
    $recent=[];foreach(glob(migration_root(false).'/*/job.json')?:[] as $path){$item=json_decode(file_get_contents($path),true);if(($item['owner']??0)===(int)$currentUser['id'])$recent[]=$item;}usort($recent,fn($a,$b)=>strcmp($b['created_at'],$a['created_at']));$recent=array_slice($recent,0,8);
    $map=$job?($job['mapping']?:migration_guess($job)):[];$plan=$job&&$job['mapping']&&in_array($job['stage'],['mapping','preview'],true)?migration_category_plan($job,$map,$job['targets']??[]):[];
    view('admin/header',compact('title','module','currentUser','error'));view('admin/migration',compact('job','recent','map','plan','categories','allAuthors'));view('admin/footer');return true;
}
function migration_admin_zip(array &$job):void {
    $upload=migration_upload('image_zip',MIGRATION_ZIP_LIMIT,['zip']);$archive=migration_dir($job['id']).'/images.zip';if(!move_uploaded_file($upload['tmp_name'],$archive))throw new RuntimeException('ZIP kaydedilemedi.');
    try{$job['images']=array_merge($job['images'],migration_import_images($archive,$job));migration_store($job);}finally{if(is_file($archive))unlink($archive);}
}
