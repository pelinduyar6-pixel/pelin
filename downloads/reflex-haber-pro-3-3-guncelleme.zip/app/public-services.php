<?php
declare(strict_types=1);
function public_json(array $data,int $status=200):never{
    http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($data,JSON_UNESCAPED_UNICODE);exit;
}
function reaction_options():array{return ['like'=>['👍','Beğendim'],'love'=>['❤️','Sevdim'],'surprise'=>['😮','Şaşırdım'],'sad'=>['😢','Üzüldüm'],'angry'=>['😠','Kızdım']];}
function reaction_counts(int $id):array{
    $counts=array_fill_keys(array_keys(reaction_options()),0);
    foreach(Database::rows('SELECT kind,COUNT(*) AS total FROM rh6_reactions WHERE news_id=? GROUP BY kind',[$id]) as $row)if(isset($counts[$row['kind']]))$counts[$row['kind']]=(int)$row['total'];return $counts;
}
function visitor_hash():string{
    $token=$_COOKIE['reflex_reader']??'';
    if(!is_string($token)||!preg_match('/^[a-f0-9]{64}$/',$token)){
        $token=bin2hex(random_bytes(32));$_COOKIE['reflex_reader']=$token;
        $config=require ROOT.'/storage/site.php';setcookie('reflex_reader',$token,['expires'=>time()+31536000,'path'=>base_path().'/','secure'=>parse_url($config['site_url'],PHP_URL_SCHEME)==='https','httponly'=>true,'samesite'=>'Lax']);
    }return hash('sha256',$token);
}
function public_service(string $route):bool{
    if($route==='/tepki'){
        try{
            if(!is_post())public_json(['ok'=>false,'error'=>'POST isteği gerekli.'],405);verify_csrf();
            $id=integer_input('news_id');$kind=text_input('kind',20,true);
            if(!isset(reaction_options()[$kind]))throw new InvalidArgumentException('Geçerli tepki seçin.');
            if(!news_rows('AND n.id=?',[$id],1))public_json(['ok'=>false,'error'=>'Haber bulunamadı.'],404);
            if(microtime(true)-(float)($_SESSION['last_reaction']??0)<0.7)public_json(['ok'=>false,'error'=>'Biraz bekleyip tekrar deneyin.'],429);
            $hash=visitor_hash();$row=Database::row('SELECT id FROM rh6_reactions WHERE news_id=? AND visitor_hash=?',[$id,$hash]);
            $data=['kind'=>$kind,'created_at'=>date('Y-m-d H:i:s')];
            if($row)Database::save('reactions',$data,(int)$row['id']);
            else{try{Database::save('reactions',$data+['news_id'=>$id,'visitor_hash'=>$hash]);}catch(PDOException $ex){if((string)$ex->getCode()!=='23000')throw $ex;Database::query('UPDATE rh6_reactions SET kind=? WHERE news_id=? AND visitor_hash=?',[$kind,$id,$hash]);}}
            $_SESSION['last_reaction']=microtime(true);public_json(['ok'=>true,'counts'=>reaction_counts($id),'selected'=>$kind]);
        }catch(Throwable $ex){log_failure($ex);public_json(['ok'=>false,'error'=>$ex instanceof InvalidArgumentException?$ex->getMessage():'İşlem tamamlanamadı. Sayfayı yenileyin.'],http_response_code()===419?419:422);}
    }
    if(!in_array($route,['/sitemap.xml','/news-sitemap.xml','/robots.txt','/rss.xml','/sitemap-haberler.xml','/sitemap-kategoriler.xml','/sitemap-sayfalar.xml','/sitemap-moduller.xml'],true)&&!preg_match('~^/sitemap-haberler-[0-9]+\.xml$~',$route))return false;
    $config=require ROOT.'/storage/site.php';$site=rtrim($config['site_url'],'/');$xml=fn($value)=>htmlspecialchars((string)$value,ENT_XML1|ENT_QUOTES,'UTF-8');
    if($route==='/robots.txt'){
        header('Content-Type: text/plain; charset=utf-8');$prefix=base_path();
        echo "User-agent: *\n";
        if(setting('seo_robots')==='noindex,nofollow')echo "Disallow: /\n";
        else{foreach(['panel','panel.php','kurulum.php','cron.php','storage/','app/','views/','tests/','database/'] as $path)echo 'Disallow: '.$prefix.'/'.$path."\n";echo 'Disallow: '.$prefix.'/index.php?route=%2Fpanel' ."\n";}
        echo 'Sitemap: '.$site.'/index.php?route=%2Fsitemap.xml'."\n";return true;
    }
    header('Content-Type: application/xml; charset=utf-8');echo '<?xml version="1.0" encoding="UTF-8"?>';
    $condition=published_condition();$params=[date('Y-m-d H:i:s')];
    if($route==='/rss.xml'){
        echo '<rss version="2.0"><channel><title>'.$xml(setting('site_name')).'</title><link>'.$xml($site).'</link><description>'.$xml(setting('description')).'</description><language>tr-TR</language>';
        foreach(news_rows('AND n.is_demo=0',[],30) as $news){$link=absolute_url(news_link($news));echo '<item><title>'.$xml($news['title']).'</title><link>'.$xml($link).'</link><guid isPermaLink="true">'.$xml($link).'</guid><description>'.$xml($news['summary']).'</description><pubDate>'.date(DATE_RSS,strtotime($news['published_at']??$news['created_at'])).'</pubDate></item>';}
        echo '</channel></rss>';return true;
    }
    if($route==='/sitemap.xml'){
        $total=(int)Database::scalar("SELECT COUNT(*) FROM rh6_news n WHERE ".$condition." AND n.is_demo=0",$params);$parts=max(1,(int)ceil($total/45000));
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        $paths=['/sitemap-kategoriler.xml','/sitemap-sayfalar.xml','/sitemap-moduller.xml'];for($page=1;$page<=$parts;$page++)$paths[]=$page===1?'/sitemap-haberler.xml':'/sitemap-haberler-'.$page.'.xml';
        foreach($paths as $path)echo '<sitemap><loc>'.$xml(absolute_url(url($path))).'</loc></sitemap>';echo '</sitemapindex>';return true;
    }
    $newsMap=$route==='/news-sitemap.xml';
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"'.($newsMap?' xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"':'').'>';
    $paths=[];
    if($route==='/sitemap-kategoriler.xml')$paths=array_map(fn($row)=>'/kategori/'.$row['slug'],Database::rows('SELECT slug FROM rh6_categories'));
    if($route==='/sitemap-sayfalar.xml')$paths=array_merge(['/','/son-haberler','/foto-galeri','/video-galeri','/yazarlar','/makaleler','/iletisim'],array_map(fn($row)=>'/sayfa/'.$row['slug'],Database::rows("SELECT slug FROM rh6_pages WHERE active=1 AND slug<>'iletisim'")));
    if($route==='/sitemap-moduller.xml'){
        $paths=['/moduller'];foreach(module_definitions() as $key=>$value)if(module_enabled($key))$paths[]='/modul/'.$key;
        foreach(Database::rows("SELECT module,slug FROM rh6_module_items WHERE status='published' AND (ends_at IS NULL OR ends_at>=?) ORDER BY id LIMIT 45000",[date('Y-m-d H:i:s')]) as $item)if(module_enabled($item['module']))$paths[]='/modul/'.$item['module'].'/'.$item['slug'];
    }
    if(in_array($route,['/sitemap-kategoriler.xml','/sitemap-sayfalar.xml','/sitemap-moduller.xml'],true)){
        foreach($paths as $path)echo '<url><loc>'.$xml(absolute_url(url($path))).'</loc></url>';echo '</urlset>';return true;
    }
    if($newsMap){$condition.=' AND n.published_at>=?';$params[]=date('Y-m-d H:i:s',time()-172800);}
    // The cap stays below the protocol's 50,000-URL limit. Demo articles are never submitted.
    $mapPage=preg_match('~^/sitemap-haberler-([0-9]+)\.xml$~',$route,$matches)?max(1,min(1000000,(int)$matches[1])):1;
    $rows=Database::rows('SELECT n.slug,n.title,n.published_at,n.created_at,n.updated_at FROM rh6_news n WHERE '.$condition.' AND n.is_demo=0 ORDER BY n.published_at DESC,n.id DESC LIMIT '.($newsMap?'1000':'45000').' OFFSET '.($newsMap?0:($mapPage-1)*45000),$params);
    foreach($rows as $news){echo '<url><loc>'.$xml(absolute_url(news_link($news))).'</loc><lastmod>'.date('c',strtotime($news['updated_at'])).'</lastmod>';
        if($newsMap)echo '<news:news><news:publication><news:name>'.$xml(setting('site_name')).'</news:name><news:language>tr</news:language></news:publication><news:publication_date>'.date('c',strtotime($news['published_at']??$news['created_at'])).'</news:publication_date><news:title>'.$xml($news['title']).'</news:title></news:news>';
        echo '</url>';
    }echo '</urlset>';return true;
}
function pagination(int $page,int $pages,string $route,array $query=[]):void{
    if($pages<=1)return;echo '<nav class="pagination" aria-label="Sayfalar">';
    if($page>1)echo '<a rel="prev" href="'.e(url($route,array_replace($query,['page'=>$page-1]))).'">← Önceki</a>';
    $numbers=array_unique(array_merge([1,$pages],range(max(1,$page-2),min($pages,$page+2))));sort($numbers);$last=0;
    foreach($numbers as $number){if($last&&$number-$last>1)echo '<span>…</span>';echo $number===$page?'<span class="current" aria-current="page">'.$number.'</span>':'<a href="'.e(url($route,array_replace($query,['page'=>$number]))).'">'.$number.'</a>';$last=$number;}
    if($page<$pages)echo '<a rel="next" href="'.e(url($route,array_replace($query,['page'=>$page+1]))).'">Sonraki →</a>';echo '</nav>';
}
