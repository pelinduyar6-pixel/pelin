<?php
declare(strict_types=1);
require_once __DIR__.'/integrations.php';
function dashboard_data():array{
    $start=date('Y-m-d',strtotime('-29 days'));$previous=date('Y-m-d',strtotime('-59 days'));
    $views=(int)Database::scalar('SELECT COALESCE(SUM(views),0) FROM rh6_daily_stats WHERE day>=?',[$start]);$oldViews=(int)Database::scalar('SELECT COALESCE(SUM(views),0) FROM rh6_daily_stats WHERE day>=? AND day<?',[$previous,$start]);
    $published=(int)Database::scalar("SELECT COUNT(*) FROM rh6_news WHERE status='published' AND published_at>=? AND published_at<=?",[$start,date('Y-m-d H:i:s')]);
    $metrics=['views'=>['label'=>'Görüntülenme','value'=>$views,'icon'=>'◉','tone'=>'green','note'=>'Önceki 30 gün: '.number_format($oldViews,0,',','.')],'published'=>['label'=>'Yayımlanan haber','value'=>$published,'icon'=>'▤','tone'=>'blue','note'=>'Son 30 gün'],'drafts'=>['label'=>'Taslak haber','value'=>(int)Database::scalar("SELECT COUNT(*) FROM rh6_news WHERE status='draft'"),'icon'=>'▱','tone'=>'amber','note'=>'Editör onayı bekliyor'],'scheduled'=>['label'=>'Planlanan yayın','value'=>(int)Database::scalar("SELECT COUNT(*) FROM rh6_news WHERE status='scheduled'"),'icon'=>'◷','tone'=>'purple','note'=>'Yayın takvimindeki haberler'],'comments'=>['label'=>'Bekleyen yorum','value'=>(int)Database::scalar("SELECT COUNT(*) FROM rh6_comments WHERE status='pending'"),'icon'=>'☏','tone'=>'red','note'=>'Moderasyon gerekli'],'imports'=>['label'=>'Kaynaktan alınan','value'=>(int)Database::scalar('SELECT COUNT(*) FROM rh6_news WHERE source_id IS NOT NULL AND created_at>=?',[$start]),'icon'=>'⇣','tone'=>'teal','note'=>'Son 30 gün'],'ads'=>['label'=>'Aktif reklam','value'=>(int)Database::scalar('SELECT COUNT(*) FROM rh6_ads WHERE active=1 AND (starts_at IS NULL OR starts_at<=?) AND (ends_at IS NULL OR ends_at>=?)',[date('Y-m-d H:i:s'),date('Y-m-d H:i:s')]),'icon'=>'⚑','tone'=>'green','note'=>count(ad_slots()).' kullanılabilir konum'],'media'=>['label'=>'Medya dosyası','value'=>(int)Database::scalar('SELECT COUNT(*) FROM rh6_media'),'icon'=>'▧','tone'=>'blue','note'=>'Görsel ve video arşivi']];
    if((user()['role']??'')==='admin')$metrics+=['messages'=>['label'=>'Yeni iletişim mesajı','value'=>(int)Database::scalar("SELECT COUNT(*) FROM rh6_contacts WHERE status='new'"),'icon'=>'✉','tone'=>'teal','note'=>'Gelen kutusunda okunmayı bekliyor'],'opinions'=>['label'=>'Yayımlanan makale','value'=>(int)Database::scalar("SELECT COUNT(*) FROM rh6_news WHERE kind='opinion' AND status='published' AND published_at<=?",[date('Y-m-d H:i:s')]),'icon'=>'✎','tone'=>'blue','note'=>'Makale ve köşe yazıları'],'modules'=>['label'=>'Yayındaki modül içeriği','value'=>(int)Database::scalar("SELECT COUNT(*) FROM rh6_module_items WHERE status='published' AND (ends_at IS NULL OR ends_at>=?)",[date('Y-m-d H:i:s')]),'icon'=>'⌘','tone'=>'purple','note'=>'İlan, anket ve yaşam içerikleri'],'agencies'=>['label'=>'Aktif ajans kaynağı','value'=>(int)Database::scalar('SELECT COUNT(*) FROM rh6_agencies WHERE active=1'),'icon'=>'⇣','tone'=>'green','note'=>'Otomatik taraması açık bağlantılar']];
    $distribution=['excellent'=>0,'good'=>0,'improve'=>0,'poor'=>0];$total=0;$sample=Database::rows('SELECT * FROM rh6_news ORDER BY id DESC LIMIT 50');
    foreach($sample as $news){$score=seo_evaluate($news)['score'];$total+=$score;$distribution[$score>=90?'excellent':($score>=70?'good':($score>=50?'improve':'poor'))]++;}
    $chart=[];for($i=13;$i>=0;$i--){$day=date('Y-m-d',strtotime('-'.$i.' days'));$chart[]=['day'=>$day,'value'=>(int)Database::scalar('SELECT COALESCE(SUM(views),0) FROM rh6_daily_stats WHERE day=?',[$day])];}
    return ['metrics'=>$metrics,'seo_average'=>$sample?(int)round($total/count($sample)):0,'seo_distribution'=>$distribution,'chart'=>$chart,'updated'=>date('H:i:s'),'period'=>date('d.m.Y',strtotime($start)).' – '.date('d.m.Y'),'sample_count'=>count($sample)];
}
function admin_json(array $data,int $status=200):never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
function pro_admin_dispatch(string $module,string $action,array $currentUser,array $categories,array $allAuthors):bool{
    if($module==='ai'&&!is_post())redirect('/panel/api-merkezi');
    if(in_array($module,['foto-galeri','videolar'],true)){redirect('/panel/haberler',['kind'=>$module==='foto-galeri'?'gallery':'video']);}
    if($module==='api'){
        try{
            if($action==='metrics'){if(is_post())throw new InvalidArgumentException('Geçersiz yöntem.');admin_json(['ok'=>true,'data'=>dashboard_data()]);}
            if(!is_post())admin_json(['ok'=>false,'error'=>'POST isteği gerekli.'],405);verify_csrf();
            $news=[];foreach(['title'=>255,'summary'=>1000,'body'=>200000,'slug'=>190,'seo_title'=>255,'seo_description'=>500,'focus_keyword'=>150] as $key=>$max)$news[$key]=text_input($key,$max);
            $news['body']=safe_html($news['body']);$news['has_image']=checked_input('has_image');
            if($action==='seo-fill')admin_json(['ok'=>true,'data'=>seo_autofill($news)]);
            if($action==='seo-score')admin_json(['ok'=>true,'data'=>seo_evaluate($news)]);
            if($action==='ai-seo'){if(time()-(int)($_SESSION['last_ai_request']??0)<20)admin_json(['ok'=>false,'error'=>'Yeni bir AI isteği için 20 saniye bekleyin.'],429);$_SESSION['last_ai_request']=time();admin_json(['ok'=>true,'data'=>openai_seo($news)]);}
            admin_json(['ok'=>false,'error'=>'Araç bulunamadı.'],404);
        }catch(Throwable $ex){log_failure($ex);admin_json(['ok'=>false,'error'=>!($ex instanceof PDOException)&&($ex instanceof InvalidArgumentException||$ex instanceof RuntimeException)?$ex->getMessage():'İşlem tamamlanamadı.'],http_response_code()===419?419:422);}
    }
    $screens=['tema'=>'theme','ogeler'=>'elements','ozel-kodlar'=>'codes','botlar'=>'sources','seo'=>'seo-center','ai'=>'ai-settings','medya'=>'media','guvenlik'=>'security'];
    if(!isset($screens[$module]))return false;
    $titles=['tema'=>'Tema ve Logo','ogeler'=>'Ana Sayfa Öğeleri','ozel-kodlar'=>'Özel Kod Alanları','botlar'=>'Haber Botları','seo'=>'SEO Merkezi','ai'=>'OpenAI Ayarları','medya'=>'Medya Kütüphanesi','guvenlik'=>'Güvenlik Durumu'];
    $title=$titles[$module];$screen=$screens[$module];$error='';$record=[];$rows=[];
    $id=isset($_GET['id'])&&is_scalar($_GET['id'])?(int)$_GET['id']:0;
    if($module==='botlar'&&$id){$record=Database::row('SELECT * FROM rh6_news_sources WHERE id=?',[$id]);if(!$record){http_response_code(404);throw new InvalidArgumentException('Kaynak bulunamadı.');}}
    if(is_post()){
        verify_csrf();
        try{
            if($module==='tema'){
                $values=[];foreach(['theme_primary','theme_accent'] as $key){$values[$key]=text_input($key,7,true);if(!preg_match('/^#[0-9a-fA-F]{6}$/',$values[$key]))throw new InvalidArgumentException('Geçerli renk seçin.');}
                $values['theme_width']=(string)integer_input('theme_width',1180);if(!in_array($values['theme_width'],['1100','1180','1280','1380'],true))throw new InvalidArgumentException('Geçerli sayfa genişliği seçin.');
                foreach(['theme_density'=>['comfortable','compact'],'theme_header'=>['classic','centered']] as $key=>$allowed){$values[$key]=text_input($key,30,true);if(!in_array($values[$key],$allowed,true))throw new InvalidArgumentException('Geçersiz tema seçeneği.');}
                $seconds=integer_input('slider_interval',3);if($seconds<2||$seconds>20)throw new InvalidArgumentException('Manşet süresi 2–20 saniye olmalı.');$values['slider_interval']=(string)$seconds;
                foreach(['theme_dark','slider_autoplay','breaking_animation'] as $key)$values[$key]=(string)checked_input($key);
                $values['theme_footer_text']=text_input('theme_footer_text',500);$values['footer_phone']=text_input('footer_phone',40);$values['footer_address']=text_input('footer_address',200);$values['theme_style']=(string)integer_input('theme_style',1);if(!in_array($values['theme_style'],['1','2','3','4'],true))throw new InvalidArgumentException('Tema 1–4 arasında seçilmeli.');
                foreach(['app_google_play','app_app_store','app_gallery'] as $key)if(isset($_POST[$key]))$values[$key]=url_input($key);
                foreach(['theme_logo','theme_logo_dark','theme_favicon'] as $key)$values[$key]=isset($_POST['remove_'.$key])?'':(upload_image($key,setting($key))??'');
                foreach($values as $key=>$value)put_setting($key,$value);flash('Tema ayarları ve logo kaydedildi.');redirect('/panel/tema');
            }elseif($module==='ogeler'){
                save_home_categories($categories);$enabled=[];$positions=[];foreach(home_section_names() as $key=>$label){$enabled[$key]=checked_input('active_'.$key);$value=$_POST['position'][$key]??50;if(!is_scalar($value)||filter_var($value,FILTER_VALIDATE_INT)===false||(int)$value<1||(int)$value>99)throw new InvalidArgumentException('Bölüm sırası 1–99 arasında olmalı.');$positions[$key]=(int)$value;}
                asort($positions,SORT_NUMERIC);put_setting('home_sections',json_encode($enabled));put_setting('home_order',json_encode(array_keys($positions)));
                foreach(['home_show_top','home_show_headline','home_show_sidebar'] as $key)put_setting($key,(string)checked_input($key));flash('Ana sayfa öğeleri kaydedildi.');redirect('/panel/ogeler');
            }elseif($module==='ozel-kodlar'){
                foreach(['code_head','code_body_start','code_body_end','code_footer'] as $key)put_setting($key,text_input($key,100000));flash('Özel kod alanları kaydedildi.');redirect('/panel/ozel-kodlar');
            }elseif($module==='ai'){
                save_ai_configuration();flash('OpenAI ayarları kaydedildi.');redirect('/panel/ai');
            }elseif($module==='seo'){
                if($currentUser['role']!=='admin')throw new InvalidArgumentException('Site SEO ayarları için yönetici yetkisi gerekiyor.');
                $robots=text_input('seo_robots',30,true);if(!in_array($robots,['index,follow','noindex,nofollow'],true))throw new InvalidArgumentException('Geçerli indeksleme seçeneği seçin.');put_setting('seo_robots',$robots);flash('Site SEO ayarları kaydedildi.');redirect('/panel/seo');
            }elseif($module==='medya'){
                if($action==='sil'){
                    $media=Database::row('SELECT * FROM rh6_media WHERE id=?',[$id]);if(!$media)throw new InvalidArgumentException('Medya bulunamadı.');$path=$media['path'];
                    $used=(int)Database::scalar('SELECT COUNT(*) FROM rh6_news WHERE image=? OR video_file=? OR pdf_file=? OR gallery LIKE ?',[$path,$path,$path,'%"'.$path.'"%'])+(int)Database::scalar('SELECT COUNT(*) FROM rh6_users WHERE image=?',[$path])+(int)Database::scalar('SELECT COUNT(*) FROM rh6_ads WHERE image=?',[$path])+(int)Database::scalar('SELECT COUNT(*) FROM rh6_settings WHERE value=?',[$path]);
                    if($used)throw new InvalidArgumentException('Bu dosya içerikte kullanılıyor. Önce ilgili içerikteki seçimi kaldırın.');
                    if(str_starts_with($path,'uploads/')&&preg_match('~^uploads/[a-f0-9]{32}\.(jpg|png|gif|webp|mp4|webm|pdf)$~',$path))@unlink(ROOT.'/'.$path);Database::query('DELETE FROM rh6_media WHERE id=?',[$id]);flash('Medya silindi.');
                }else{
                    $kind=text_input('media_kind',10,true);if(!in_array($kind,['image','video','document'],true))throw new InvalidArgumentException('Geçerli dosya türü seçin.');$path=$kind==='video'?upload_video('media_file'):($kind==='document'?upload_pdf('media_file'):upload_image('media_file'));if(!$path)throw new InvalidArgumentException('Önce bir dosya seçin.');flash('Dosya medya kütüphanesine eklendi.');
                }redirect('/panel/medya');
            }elseif($module==='botlar'){
                if($action==='ai-test'){flash(openai_connection_test());redirect('/panel/botlar');}
                if($action==='ayarlar'){save_ai_configuration();foreach(['bot_enabled','bot_ai_enabled'] as $key)put_setting($key,(string)checked_input($key));flash('Bot ve ortak AI ayarları kaydedildi.');redirect('/panel/botlar');}
                if($action==='yenile-token'){put_setting('cron_token',bin2hex(random_bytes(24)));flash('Görev bağlantısı yenilendi.');redirect('/panel/botlar');}
                if($action==='test'){if(!$id)throw new InvalidArgumentException('Önce kaynağı kaydedin.');$items=fetch_source_items($record);flash(count($items).' haber başlığı bulundu. İlk başlık: '.mb_substr($items[0]['title']??'Kaynak boş',0,180));redirect('/panel/botlar',['id'=>$id]);}
                if($action==='calistir'){
                    if(!$id)throw new InvalidArgumentException('Kaynak seçin.');$count=import_source($record);flash($count.' yeni haber alındı.');redirect('/panel/botlar');
                }
                if($action==='sil'){
                    if(!$id)throw new InvalidArgumentException('Kaynak seçin.');Database::query('UPDATE rh6_news SET source_id=NULL WHERE source_id=?',[$id]);Database::query('DELETE FROM rh6_feed_items WHERE source_id=?',[$id]);Database::query('DELETE FROM rh6_source_runs WHERE source_id=?',[$id]);Database::query('DELETE FROM rh6_news_sources WHERE id=?',[$id]);flash('Kaynak silindi. Alınmış haberler korundu.');redirect('/panel/botlar');
                }
                $url=url_input('feed_url');if(!$url)throw new InvalidArgumentException('Haber kaynağı URL’sini girin.');public_url_target($url);
                $interval=integer_input('interval_minutes',60);$max=integer_input('max_items',5);if($interval<5||$interval>10080||$max<1||$max>20)throw new InvalidArgumentException('Çalışma aralığı 5–10080 dakika, haber limiti 1–20 olmalı.');
                $status=text_input('import_status',20,true);if(!in_array($status,['draft','published'],true))throw new InvalidArgumentException('Geçerli yayın durumu seçin.');
                $category=integer_input('category_id')?:null;$author=integer_input('author_id')?:null;
                if($category&&!Database::scalar('SELECT id FROM rh6_categories WHERE id=?',[$category]))throw new InvalidArgumentException('Kategori bulunamadı.');if($author&&!Database::scalar('SELECT id FROM rh6_users WHERE id=? AND active=1',[$author]))throw new InvalidArgumentException('Yazar bulunamadı.');
                $sourceKind=text_input('source_kind',20)?:'auto';if(!in_array($sourceKind,['auto','rss','page'],true))throw new InvalidArgumentException('Geçerli kaynak biçimi seçin.');
                $data=['name'=>text_input('name',150,true),'feed_url'=>$url,'source_kind'=>$sourceKind,'fetch_full'=>checked_input('fetch_full'),'category_id'=>$category,'author_id'=>$author,'interval_minutes'=>$interval,'max_items'=>$max,'import_status'=>$status,'active'=>checked_input('active'),'agenda_enabled'=>checked_input('agenda_enabled'),'ai_seo'=>checked_input('ai_seo'),'next_run_at'=>date_input('next_run_at')??date('Y-m-d H:i:s')];$mode=text_input('schedule_mode',12)?:'interval';if(!in_array($mode,['interval','daily'],true))throw new InvalidArgumentException('Geçerli çalışma takvimi seçin.');$clock=text_input('daily_time',5);if($mode==='daily'&&!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D',$clock))throw new InvalidArgumentException('Geçerli günlük çalışma saati seçin.');$data['schedule_mode']=$mode;$data['daily_time']=$mode==='daily'?$clock:null;if($mode==='daily')$data['next_run_at']=source_next_run($data);Database::save('news_sources',$data,$id?:null);flash('Kaynak ve çalışma zamanı kaydedildi.');redirect('/panel/botlar');
            }
        }catch(InvalidArgumentException|RuntimeException $ex){$error=$ex instanceof PDOException?'İşlem kaydedilemedi. Sunucu günlüğünü kontrol edin.':$ex->getMessage();if($ex instanceof PDOException)log_failure($ex);$record=array_merge($record,$_POST);http_response_code(422);}
    }
    if($module==='botlar'){$rows=Database::rows('SELECT s.*,c.name AS category_name FROM rh6_news_sources s LEFT JOIN rh6_categories c ON c.id=s.category_id ORDER BY s.id DESC');$logs=Database::rows('SELECT r.*,s.name FROM rh6_source_runs r LEFT JOIN rh6_news_sources s ON s.id=r.source_id ORDER BY r.id DESC LIMIT 15');}
    if($module==='medya')$rows=Database::rows('SELECT * FROM rh6_media ORDER BY id DESC LIMIT 120');
    if($module==='seo'){$seoItems=Database::rows('SELECT * FROM rh6_news ORDER BY id DESC LIMIT 200');foreach($seoItems as &$news)$news['seo']=seo_evaluate($news);unset($news);usort($seoItems,fn($a,$b)=>$a['seo']['score']<=>$b['seo']['score']);$dashboard=dashboard_data();}
    view('admin/header',compact('title','module','currentUser','error'));view('admin/'.$screen,get_defined_vars());view('admin/footer');return true;
}
