<?php
$_GET['route'] = '/panel';
require __DIR__ . '/index.php';
