<?php
declare(strict_types=1);
require __DIR__.'/app/core.php';require __DIR__.'/app/pro.php';require __DIR__.'/app/integrations.php';
date_default_timezone_set('Europe/Istanbul');
if(!is_file(ROOT.'/storage/site.php')){if(PHP_SAPI==='cli'){fwrite(STDERR,"Önce kurulum yapın.\n");exit(1);}http_response_code(503);exit;}
try{
    Database::connection();migrate_pro_schema();
    if(PHP_SAPI!=='cli'){
        $token=$_GET['token']??'';if(!is_string($token)||!hash_equals(setting('cron_token'),$token)){http_response_code(403);exit;}
        header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');
    }
    Database::query("UPDATE rh6_news SET status='published' WHERE status='scheduled' AND published_at<=?",[date('Y-m-d H:i:s')]);
    echo json_encode(['ok'=>true,'sources'=>run_due_sources()],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable $ex){log_failure($ex);if(PHP_SAPI!=='cli')http_response_code(500);echo '{"ok":false}'.PHP_EOL;exit(1);}
