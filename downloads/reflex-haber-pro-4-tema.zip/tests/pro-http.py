"""Pro feature acceptance tests. Disposable localhost install only."""
from pathlib import Path
exec((Path(__file__).with_name('smoke.py').read_text()).split("status,body,_=request('kurulum.php')")[0])
import xml.etree.ElementTree as ET,time
assert urllib.parse.urlsplit(BASE).hostname in ['127.0.0.1','localhost']
login=get('/panel/giris');status,body,_=request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login));check(status==200 and 'admin-sidebar' in body,'Pro admin login')
for p in ['/panel/tema','/panel/ogeler','/panel/ozel-kodlar','/panel/botlar','/panel/seo','/panel/ai','/panel/medya','/panel/guvenlik']:check('<div class="box"><h1>İşlem tamamlanamadı' not in get(p),'Tool page body '+p)
check(True,'All Pro tools render')
# XML documents must contain only eligible public, non-demo articles.
for p in ['/sitemap.xml','/news-sitemap.xml','/rss.xml']:
 content=get(p);ET.fromstring(content);check('Örnek haber içeriği' not in content,'Valid XML '+p)
check('Sitemap:' in get('/robots.txt'),'robots.txt advertises sitemap')
check(request('cron.php')[0]==403,'Cron HTTP endpoint requires secret token')
api=route('/panel/api/seo-score');status,body,_=request(api,{'title':'Test'},'bad');check(status==419,'SEO API rejects invalid CSRF')
form=get('/panel/haberler/yeni');status,body,_=request(api,{'title':'İstanbul ulaşım planı ayrıntıları açıklandı','summary':'Özet '*25,'body':'<h2>İstanbul gündemi</h2><p>'+('İstanbul haber metni '*60)+'</p>','slug':'istanbul','focus_keyword':'İstanbul','has_image':'1'},csrf(form));data=json.loads(body);check(status==200 and data['data']['score']>=70,'Live SEO JSON evaluates actual fields')
# Admin-only raw code fields apply on front end, never to the panel.
codes={'code_head':'<meta name="reflex-test-head" content="1">','code_body_start':'<div data-reflex-test="start"></div>','code_body_end':'<div data-reflex-test="end"></div>','code_footer':'<div data-reflex-test="footer"></div>'}
form=get('/panel/ozel-kodlar');request(route('/panel/ozel-kodlar'),codes,csrf(form));home=get('/');check('reflex-test-head' in home and 'data-reflex-test="footer"' in home,'Custom head, body and footer code is applied');check('reflex-test-head' not in get('/panel'),'Custom code cannot execute inside admin');request(route('/panel/ozel-kodlar'),{k:'' for k in codes},csrf(get('/panel/ozel-kodlar')))
# Theme and separate footer logo persist; uploaded logo uses the same MIME protections.
theme={'theme_style':'2','theme_primary':'#e91c3a','theme_accent':'#06b6be','theme_width':'1180','theme_density':'comfortable','theme_header':'classic','slider_interval':'5','slider_autoplay':'1','breaking_animation':'1','theme_footer_text':'Test footer açıklaması','footer_phone':'+90 555 000 00 00','footer_address':'Test adres'}
image=Path(__file__).parents[1]/'assets/v6/demo/bogaz-5-2.jpg'
status,_,_=request(route('/panel/tema'),theme,csrf(get('/panel/tema')),file=('theme_logo_dark','footer-test.jpg',image.read_bytes()));check(status==200 and 'theme-2' in get('/') and 'Test footer açıklaması' in get('/'),'Theme 2 and footer settings save');check('site-logo-image' in get('/'),'Separate footer logo displays')
# Section enable flags and order affect actual rendering.
elements={'home_show_top':'1','home_show_headline':'1','home_show_sidebar':'1','active_latest':'1','active_categories':'1','active_gallery':'1','active_authors':'1','position[latest]':'2','position[categories]':'3','position[video]':'4','position[gallery]':'1','position[authors]':'5'}
request(route('/panel/ogeler'),elements,csrf(get('/panel/ogeler')));home=get('/');check('data-section="video"' not in home and home.index('data-section="gallery"')<home.index('data-section="latest"'),'Home section visibility and order work')
elements['active_video']='1';elements['position[latest]']='1';elements['position[gallery]']='4';request(route('/panel/ogeler'),elements,csrf(get('/panel/ogeler')))
theme['theme_style']='1';theme['remove_theme_logo_dark']='1';request(route('/panel/tema'),theme,csrf(get('/panel/tema')))
# Upload validation must inspect bytes, not a disguised extension.
form=get('/panel/haberler/yeni');news={'title':'Reject upload test','kind':'article','status':'draft'}
status,body,_=request(route('/panel/haberler/yeni'),news,csrf(form),file=('video_file','attack.mp4',b'<?php echo 1; ?>'));check(status==422 and 'MP4' in body,'Executable disguised as video is rejected')
status,body,_=request(route('/panel/haberler/yeni'),news,csrf(get('/panel/haberler/yeni')),file=('image_file','attack.jpg',b'<?php echo 1; ?>'));check(status==422,'Executable disguised as image is rejected')
# Editor may edit news and use SEO, but cannot modify API secrets or custom scripts.
form=get('/panel/yazarlar/yeni');editor={'name':'Test Editör','email':'test-editor@example.invalid','slug':'test-editor','role':'editor','active':'1','new_password':PASSWORD}
request(route('/panel/yazarlar/yeni'),editor,csrf(form));editor_client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));login=request(route('/panel/giris'),opener=editor_client)[1];request(route('/panel/giris'),{'email':editor['email'],'password':PASSWORD},csrf(login),opener=editor_client)
for p in ['/panel/ozel-kodlar','/panel/ai','/panel/tema','/panel/reklamlar','/panel/botlar']:check(request(route(p),opener=editor_client)[0]==403,'Editor denied '+p)
check(request(route('/panel/seo'),opener=editor_client)[0]==200,'Editor may use SEO center')
# Visitor cannot see secrets or admin JSON, and panels disallow indexing/caching.
guest=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));status,_,loc=request(route('/panel/api/metrics'),opener=guest);check('/panel/giris' in urllib.parse.unquote(loc),'Public visitors cannot fetch live admin metrics')
print('Pro HTTP acceptance tests completed.')
