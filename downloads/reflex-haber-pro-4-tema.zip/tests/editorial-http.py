"""3.1 attachment, metadata and source configuration checks; disposable localhost only."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
import time
assert urllib.parse.urlsplit(BASE).hostname in ['127.0.0.1','localhost']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
form=get('/panel/haberler/yeni');token=csrf(form)
cat=re.search(r'name="category_id">.*?value="(\d+)"',form,re.S).group(1)
slug='editorial-belge-'+str(time.time_ns());record={'title':'Haber belgesi ve SEO tamamlama kabul testi','slug':slug,'body':'<h2>Belgenin ayrıntıları</h2><p>'+('Doğrulanmış mevcut haber metni. '*25)+'</p>','summary':'','seo_title':'Elle yazılan özel SEO başlığı','seo_description':'','status':'published','kind':'article','category_id':cat,'seo_autofill':'1','embed_code':'<iframe src="https://www.youtube.com/embed/abcdefghijk" onload="bad()"></iframe>'}
pdf=b'%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Count 0 /Kids [] >>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF\n'
status,body,_=request(route('/panel/haberler/yeni'),record,token,file=('pdf_file','haber.pdf',pdf));check(status==200 and 'Kayıt kaydedildi' in body,'News PDF and trusted embed save with SEO autofill')
article=get('/haber/'+slug);check('article-document' in article and 'article-embed' in article and 'youtube-nocookie.com/embed/abcdefghijk' in article and 'onload="bad()"' not in article,'Public article renders PDF and sanitized embed')
path=re.search(r'href="([^"]+\.pdf)"',article).group(1)
with client.open(BASE+path) as response:check(response.read()==pdf and response.headers.get_content_type()=='application/pdf','Uploaded PDF downloads with correct MIME')
nid=re.search(r'id=(\d+)',urllib.parse.unquote(re.search(r'href="([^"]+)"[^>]*>Haberi düzenle',body).group(1))).group(1) if 'Haberi düzenle' in body else None
# The edit URL is present in the list returned after saving.
if not nid:
 for match in re.finditer(r'<tr[^>]*>(.*?)</tr>',body,re.S):
  if record['title'] in match.group(1):nid=re.search(r'(?:id=|id%3D)(\d+)',match.group(1)).group(1);break
check(bool(nid),'Saved news is addressable in editor')
edit=request(route('/panel/haberler/duzenle',id=nid))[1];check('Elle yazılan özel SEO başlığı' in edit and re.search(r'name="seo_description"[^>]*>[^<]+</textarea>',edit) is not None,'Autofill preserves manual title and persists generated description')
fill=request(route('/panel/api/seo-fill'),{'title':'Otomatik SEO doldurma test başlığı','body':'<p>'+('Mevcut metinden özet çıkarılır. '*15)+'</p>'},csrf(edit));payload=json.loads(fill[1]);check(fill[0]==200 and payload['data']['seo_description']!='' and payload['data']['slug']!='','SEO fill API returns usable metadata')
check(request(route('/panel/api/seo-fill'),{},'bad')[0]==419,'Autofill endpoint enforces CSRF')
check(request(route('/panel/haberler/duzenle',id=nid),{**record,'embed_code':'<iframe src="https://evil.example/steal"></iframe>'},csrf(edit))[0]==422,'Editor rejects untrusted embed provider')
check(request(route('/panel/haberler/duzenle',id=nid),record,csrf(edit),file=('pdf_file','fake.pdf',b'<?php echo "malicious"; ?>'))[0]==422,'Disguised executable cannot upload as PDF')
media=get('/panel/medya');mid=None
for match in re.finditer(r'<article class="media-tile">(.*?)</article>',media,re.S):
 if path in match.group(1):mid=re.search(r'id=(\d+)',match.group(1)).group(1);break
check(bool(mid),'PDF belongs to media library')
check(request(route('/panel/medya/sil',id=mid),{},csrf(media))[0]==422,'PDF referenced by a news item cannot be deleted')
source={'name':'Fixture URL kaynağı','feed_url':'https://93.184.215.14/gundem','source_kind':'page','fetch_full':'1','interval_minutes':'15','max_items':'3','import_status':'draft','active':'1','agenda_enabled':'1'}
form=get('/panel/botlar');status,body,_=request(route('/panel/botlar/duzenle'),source,csrf(form));check(status==200 and source['feed_url'] in body,'Bot stores custom category source URL and schedule')
rows=re.findall(r'<div class="source-card">(.*?)</div></div>',body,re.S)
match=re.search(r'route=%2Fpanel%2Fbotlar&amp;id=(\d+)',body);check(match is not None,'Source exposes edit and connection-test actions');sid=match.group(1)
form=request(route('/panel/botlar',id=sid))[1];check('<option value="page" selected>' in form and 'name="fetch_full" checked' in form,'Source kind and full-article option persist')
check(request(route('/panel/botlar/test',id=sid),{},'bad')[0]==419,'Source test enforces CSRF before network')
agenda=get('/panel/gundem');check(all(name in agenda for name in ['TRT Haber','NTV','CNN Türk','Sözcü']),'Agenda offers all four requested source selections')
check(request(route('/panel/gundem/kaynaklar'),{'agenda_sources[]':sid},csrf(agenda))[0]==200,'Agenda source selection saves')
form=get('/panel/header');header={'header_city':'İstanbul','weather_mode':'manual','weather_value':'21','weather_enabled':'1','ticker_speed':'130','ticker_color':'#73b914','ticker_enabled':'1','ticker_pulse':'1','home_authors_middle':'1','slider_autoplay':'1','breaking_animation':'1','slider_interval':'3'}
check(request(route('/panel/header'),header,csrf(form))[0]==200 and 'data-interval="3"' in get('/'),'Shorter headline interval saved and rendered')
print('Editorial HTTP checks completed:',DRIVER)
