"""3.0 acceptance tests; disposable localhost installations only."""
from pathlib import Path
exec(Path(__file__).with_name('smoke.py').read_text().split("status,body,_=request('kurulum.php')")[0])
import xml.etree.ElementTree as ET, time
assert urllib.parse.urlsplit(BASE).hostname in ['127.0.0.1','localhost']
login=get('/panel/giris');request(route('/panel/giris'),{'email':'test-admin@example.invalid','password':PASSWORD},csrf(login))
def post(path,data,query=None):
    query=query or {};form=request(route(path,**query))[1]
    return request(route(path,**query),data,csrf(form))
for name in ['header','ajanslar','api-merkezi','ai-yazar','gundem','moduller','performans','google','sitemap','gelen-kutusu','uyeler','spor','piyasalar','makaleler','makaleler/yeni']:
    body=get('/panel/'+name);check('<div class="box"><h1>İşlem tamamlanamadı' not in body,'New admin screen '+name)
header={'header_city':'İzmir','weather_mode':'manual','weather_value':'24.5','weather_enabled':'1','ticker_speed':'130','ticker_color':'#73b914','ticker_enabled':'1','ticker_pulse':'1','home_authors_middle':'1','slider_autoplay':'1','breaking_animation':'1','slider_interval':'5'}
status,body,_=post('/panel/header',header);check(status==200 and 'İZMİR' in get('/') and 'data-speed="130"' in get('/'),'Configured city and moving ticker render')
status,_,_=post('/panel/header',{**header,'slider_interval':'1'});check(status==422,'Invalid headline interval rejected')
markets={'market_mode':'manual','market_enabled':'1','market_usd':'49,06','market_eur':'55,18','market_gold':'6.574','market_bist':'12.270','market_btc':'4.139','market_usd_change':'0.05','market_eur_change':'-0.39'}
status,_,_=post('/panel/piyasalar',markets);check(status==200 and all(x in get('/') for x in ['49,06','55,18','12.270','BITCOIN']),'Five market instruments render with configured values')
league={'sports_enabled':'1','sports_league':'Trendyol Süper Lig','sports_season':'2026–2027','sports_api_season':'2026','standings_csv':'Test Takım A;2;1;1;0;3;1;4\nTest Takım B;2;1;0;1;2;2;3'}
status,_,_=post('/panel/spor',league);check(status==200 and 'Test Takım A' in get('/'),'Actual configured league standings render')
check(post('/panel/spor',{**league,'standings_csv':'Hatalı;2;3;0;0;2;1;9'})[0]==422,'Inconsistent league table rejected')
form=get('/panel/makaleler/yeni');cat=re.search(r'name="category_id">.*?value="(\d+)"',form,re.S).group(1);author=re.search(r'name="author_id">.*?value="(\d+)"',form,re.S).group(1)
slug='command-makale-'+str(time.time_ns());article={'title':'Yeni makale ve köşe yazısı testi','slug':slug,'summary':'Yazarın değerlendirmesi ve makale test özeti.','body':'<h2>Değerlendirme</h2><p>Makale metni.</p>','status':'published','category_id':cat,'author_id':author,'kind':'article'}
status,body,_=request(route('/panel/makaleler/yeni'),article,csrf(form));check(status==200 and 'Kayıt kaydedildi' in body,'Dedicated article editor saves')
check('Yeni makale ve köşe yazısı testi' in get('/makaleler') and 'OpinionNewsArticle' in get('/haber/'+slug),'Article is opinion content and appears in public article list')
guest=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
form=request(route('/iletisim'),opener=guest)[1];message={'name':'Okuyucu <script>','email':'reader@example.invalid','subject':'Panel mesaj testi','message':'İletişim formundan yayın ekibine gönderilen mesaj.','consent':'1','website':''}
check(request(route('/iletisim'),message,'invalid',opener=guest)[0]==419,'Contact rejects invalid CSRF')
status,body,_=request(route('/iletisim'),message,csrf(form),opener=guest);check(status==200 and 'Mesajınız yayın ekibine ulaştı' in body,'Contact form delivers to inbox')
inbox=get('/panel/gelen-kutusu');check('Panel mesaj testi' in inbox and '&lt;script&gt;' in inbox,'Inbox escapes reader data')
check('reader@example.invalid' not in request(route('/iletisim'),opener=guest)[1],'Reader messages are private')
check('Panel mesaj testi' not in request(route('/panel/gelen-kutusu'),opener=guest)[1],'Guests cannot read admin inbox')
pollslug='command-anket-'+str(time.time_ns());poll={'module_type':'anket','title':'Okuyucu anketi','slug':pollslug,'summary':'En çok hangi bölümü okuyorsunuz?','body':'<p>Oyunuzu seçin.</p><script>alert(1)</script>','options':'Spor\nEkonomi','status':'published'}
status,body,_=post('/panel/moduller/kaydet',poll,{'type':'anket'});check(status==200 and 'Modül kaydı güncellendi' in body,'Poll editor saves')
pollpage=request(route('/modul/anket/'+pollslug),opener=guest)[1];pid=re.search(r'name="item_id" value="(\d+)"',pollpage).group(1)
check('<script>alert(1)</script>' not in pollpage,'Module article HTML is sanitized')
check(request(route('/anket/oy'),{'item_id':pid},csrf(pollpage),opener=guest)[0]>=400,'Poll requires selected option')
status,body,_=request(route('/anket/oy'),{'item_id':pid,'choice':'0'},csrf(pollpage),opener=guest);check(status==200 and 'Oyunuz kaydedildi' in body,'Reader poll vote saves')
status,body,_=request(route('/anket/oy'),{'item_id':pid,'choice':'1'},csrf(body),opener=guest);check(status==200 and 'Okuyucu sonuçları · 1 oy' in body,'Changing vote does not duplicate a reader')
check(post('/panel/moduller/kaydet',{**poll,'options':'Başka\nSeçenek'},{'type':'anket','id':pid})[0]==422,'Voted poll options cannot be changed')
for typ in ['fal','biyografi','resmi-ilanlar','roportaj','seri-ilan','vefat','e-dergi','firma-rehberi']:
    slug2='command-'+typ+'-'+str(time.time_ns());data={'module_type':typ,'title':'Modül testi '+typ,'slug':slug2,'body':'<p>Yayımlanan içerik</p>','status':'published'}
    check(post('/panel/moduller/kaydet',data,{'type':typ})[0]==200 and 'Yayımlanan içerik' in get('/modul/'+typ+'/'+slug2),'Publish module '+typ)
draft={**poll,'slug':pollslug+'-draft','status':'draft'};post('/panel/moduller/kaydet',draft,{'type':'anket'});check(request(route('/modul/anket/'+draft['slug']),opener=guest)[0]==404,'Draft module remains private')
status,_,_=post('/panel/google',{'google_ga4':'G-TEST12345','google_verification':'test-verification-token','google_adsense':'ca-pub-1234567890123456','google_custom_head':'<meta name="command-google-test" content="yes">'})
check(status==200 and 'command-google-test' in get('/') and '<meta name="command-google-test"' not in get('/panel'),'Google tags apply only to public pages')
post('/panel/google',{'google_ga4':'','google_verification':'','google_adsense':'','google_custom_head':''})
ns={'s':'http://www.sitemaps.org/schemas/sitemap/0.9'};index=ET.fromstring(get('/sitemap.xml'));locs=[node.text for node in index.findall('s:sitemap/s:loc',ns)];check(len(locs)>=4,'Sitemap index exposes child maps')
for loc in locs:status,xml,_=request(loc);check(status==200 and ET.fromstring(xml).tag.endswith('urlset'),'Sitemap child parses')
mods=get('/sitemap-moduller.xml');check(pollslug in mods and draft['slug'] not in mods,'Module sitemap excludes drafts')
status,body,_=post('/panel/api-merkezi/test',{});check(status==422 and 'OpenAI anahtarını' in body,'Missing API key fails safely without claiming connection')
print('Command HTTP tests completed:',DRIVER)
