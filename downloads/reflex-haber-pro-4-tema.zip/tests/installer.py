"""Installer failure/recovery checks, ONLY for a fresh disposable loopback install.
Usage: DEMO6_TEST_PASSWORD=... DEMO6_TEST_DB_PASSWORD=... python3 tests/installer.py BASE DRIVER ROOT
MySQL requires a disposable reflex_installer_fix_test DB and permission-test user.
"""
import fcntl
import http.cookiejar
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request

BASE, DRIVER, ROOT = sys.argv[1].rstrip('/'), sys.argv[2], Path(sys.argv[3]).resolve()
assert urllib.parse.urlsplit(BASE).hostname in ('127.0.0.1', 'localhost')
assert ROOT.name.startswith('reflex-install-fix-'), 'Use a disposable test directory'
assert not (ROOT/'storage/site.php').exists(), 'Start with a fresh installation'
PASSWORD = os.environ['DEMO6_TEST_PASSWORD']
PHP = os.environ.get('DEMO6_TEST_PHP', 'php')
client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

def request(data=None):
    payload = urllib.parse.urlencode(data).encode() if data is not None else None
    try:
        with client.open(BASE+'/kurulum.php', data=payload, timeout=30) as response:
            return response.status, response.read().decode()
    except urllib.error.HTTPError as response:
        return response.code, response.read().decode()

def post(data):
    status, form = request()
    token = re.search(r'name="csrf" value="([a-f0-9]+)"', form).group(1)
    return request(dict(data, csrf=token))

def check(ok, label):
    assert ok, label
    print('PASS:', label)

data = dict(driver=DRIVER, site_url=BASE, admin_name='Test Yönetici', admin_email='test-admin@example.invalid', admin_password=PASSWORD, demo='1')
if DRIVER == 'mysql':
    data.update(db_host='127.0.0.1', db_port='3307', db_name='reflex_installer_fix_test', db_user='reflex_test', db_password=os.environ['DEMO6_TEST_DB_PASSWORD'])
    cases = [
        (dict(db_password='Definitely-wrong-local-password'), '1045', 'giriş bilgilerini reddetti'),
        (dict(db_name='reflex_installer_denied_test', db_user='reflex_installer_denied', db_password='Local-denied-test-2026!'), '1044', 'erişim yetkisi yok'),
        (dict(db_port='3399'), '2002', 'sunucusuna ulaşılamadı'),
    ]
    for overrides, code, message in cases:
        status, body = post(dict(data, action='test', **overrides))
        check(status == 200 and message in body and 'Hata kodu: '+code in body, 'Actual MySQL failure diagnosed: '+code)
        check('Local-denied-test-2026!' not in body and 'Definitely-wrong-local-password' not in body, 'No secret reflected in failure page')
    limited = dict(data, db_user='reflex_installer_denied', db_password='Local-denied-test-2026!')
    status, body = post(limited)
    check(status == 200 and 'gerekli işlem yetkisi yok' in body and '1142' in body, 'CREATE permission error is distinguished from login failure')

status, body = post(dict(data, action='test', admin_name='', admin_email='', admin_password=''))
check(status == 200 and ('bağlantısı başarılı' in body or 'SQLite sürücüsü hazır' in body), 'Connection check does not require an admin account')
check(not (ROOT/'storage/site.php').exists() and not (ROOT/'storage/site.sqlite').exists(), 'Connection check creates no configuration or SQLite file')

snapshot_code = r'''
require getcwd().'/app/core.php';
$driver=getenv('INSTALLER_TEST_DRIVER');
$config=$driver==='sqlite'?['driver'=>'sqlite','path'=>ROOT.'/storage/site.sqlite']:['driver'=>'mysql','host'=>'127.0.0.1','port'=>3307,'database'=>'reflex_installer_fix_test','username'=>'reflex_test','password'=>getenv('DEMO6_TEST_DB_PASSWORD')];
$pdo=Database::connect($config);
$tables=$driver==='sqlite'?$pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'rh6_%' ORDER BY name")->fetchAll(PDO::FETCH_COLUMN):$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
$rows=[];foreach($tables as $table)if(str_starts_with($table,'rh6_'))$rows[$table]=$pdo->query('SELECT * FROM '.$table.' ORDER BY id')->fetchAll();
echo json_encode($rows,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
'''

def snapshot():
    return json.loads(subprocess.check_output([PHP, '-r', snapshot_code], cwd=ROOT, env=dict(os.environ, INSTALLER_TEST_DRIVER=DRIVER)))

# A directory blocks final config publication even when storage is writable.
(ROOT/'storage/site.php').mkdir()
status, body = post(data)
check(status == 200 and 'Ayar dosyası storage/site.php' in body, 'Configuration publication failure is diagnosed')
check(snapshot()['rh6_users'] == [], 'Failed config publication rolls back created accounts')
check(not list((ROOT/'storage').glob('.config-*')), 'Failed installation leaves no temporary credential file')
(ROOT/'storage/site.php').rmdir()
status, body = post(data)
check(status == 200 and 'Kurulum tamamlandı' in body, 'Retry after file failure completes with demo content')
check((ROOT/'storage/site.php').stat().st_mode & 0o777 == 0o600, 'Credential configuration has private permissions')
before = snapshot()
check(len(before['rh6_news']) >= 30, 'Demo installation is complete')
(ROOT/'storage/site.php').unlink()
status, body = post(data)
check('daha önce kurulmuş Reflex Haber hesapları var' in body, 'Existing installation is detected without resetting data')
status, body = post(dict(data, action='reconnect', admin_password='Wrong-existing-password!'))
check('Mevcut yönetici hesabı doğrulanamadı' in body and not (ROOT/'storage/site.php').exists(), 'Reconnect requires the existing administrator password')
check(snapshot() == before, 'Rejected reconnect changes no records')
status, body = post(dict(data, action='reconnect'))
check(status == 200 and 'Kurulum tamamlandı' in body, 'Authenticated reconnect repairs missing configuration')
check(snapshot() == before, 'Reconnect preserves every table, account, password hash and news item')
log = (ROOT/'storage/logs/app.log').read_text()
check(PASSWORD not in log and os.environ.get('DEMO6_TEST_DB_PASSWORD', 'absent-password') not in log, 'Installer logs contain no passwords')
status, body = request()
check('name="admin_password"' not in body, 'Completed installer is locked')
with (ROOT/'storage/install.lock').open('r') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        client.open(BASE+'/index.php', timeout=10)
        raise AssertionError('Installation lock was ignored')
    except urllib.error.HTTPError as response:
        check(response.code == 503 and response.headers.get('Retry-After') == '5', 'Public requests wait until installer transaction finishes')
with client.open(BASE+'/index.php', timeout=10) as response:
    check(response.status == 200, 'Public site opens once installation lock is released')
print('Installer failure/recovery test completed:', DRIVER)
