<?php
// Disposable localhost only. All provider responses below are fixtures.
declare(strict_types=1);
require __DIR__.'/../app/core.php';require __DIR__.'/../app/pro.php';require __DIR__.'/../app/install.php';require __DIR__.'/../app/integrations.php';
$config=is_file(ROOT.'/storage/site.php')?require ROOT.'/storage/site.php':[];
if(!in_array(parse_url($config['site_url']??'',PHP_URL_HOST),['127.0.0.1','localhost'],true))exit(1);
date_default_timezone_set('Europe/Istanbul');$_SESSION=[];
function check(bool $ok,string $name):void{if(!$ok)throw new RuntimeException('FAIL '.$name);echo 'PASS '.$name.PHP_EOL;}
function rejects(callable $callback,string $name):void{try{$callback();}catch(InvalidArgumentException|RuntimeException $ex){check(true,$name);return;}throw new RuntimeException('FAIL '.$name);}
$pdo=new PDO('sqlite::memory:');$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);Database::use($pdo);create_schema($pdo,'sqlite');seed_site('Test','test@example.invalid','Local-test-password-2026!',false);
$private=ROOT.'/storage/integrations.php';$original=is_file($private)?file_get_contents($private):null;
try{
    save_private_integrations(['football_key'=>'local-football-key','market_token'=>'local-market-token','agencies'=>['1'=>['username'=>'fixture-user','password'=>'fixture-password']]]);save_integration_key('local-openai-key');
    check(integration_config()['football_key']==='local-football-key'&&agency_credentials(1)['password']==='fixture-password','Saving central OpenAI key preserves other credentials');
    $agencyId=Database::save('agencies',['provider'=>'aa','name'=>'Fixture agency','endpoint'=>'https://example.org/subscription','format'=>'json','auth'=>'basic','items_path'=>'data.items','mapping'=>json_encode(['title'=>'heading','summary'=>'summary','body'=>'text','url'=>'public_url','guid'=>'id','image'=>'photo']),'import_status'=>'draft','max_items'=>5,'interval_minutes'=>15,'active'=>1]);
    $source=Database::row('SELECT * FROM rh6_agencies WHERE id=?',[$agencyId]);
    $doc=json_encode(['data'=>['items'=>[['heading'=>'İstanbul ulaşım yatırımları başladı','summary'=>'Yayımlanabilir kaynak özeti.','text'=>'<p>Haber metni <a href="https://example.org/private?token=secret">abonelik</a></p><script>bad()</script>','public_url'=>'https://example.org/secret?api_key=secret','id'=>'a-1','photo'=>'https://user:secret@example.org/private.jpg']]]]);
    $fetch=function($url,$headers)use($doc){check($headers===['Authorization: Basic '.base64_encode('fixture-user:fixture-password')],'Agency sends configured Basic authentication');return $doc;};
    $items=fetch_agency_items($source,$fetch);check(count($items)===1&&$items[0]['url']===''&&$items[0]['image']===''&&!str_contains($items[0]['body'],'secret')&&!str_contains($items[0]['body'],'script'),'Agency strips credential links and unsafe HTML');
    check(import_agency($source,fn()=>$doc)===1&&import_agency($source,fn()=>$doc)===0,'Agency imports draft once and deduplicates');
    $news=Database::row('SELECT * FROM rh6_news WHERE id=(SELECT news_id FROM rh6_agency_items LIMIT 1)');check($news['status']==='draft'&&str_contains($news['body'],'Fixture agency'),'Agency retains selected state and source attribution');
    $fresh=Database::row('SELECT * FROM rh6_agencies WHERE id=?',[$agencyId]);$called=false;check(import_agency($source,function()use(&$called,$doc){$called=true;return $doc;},true)===0&&!$called,'Agency rechecks future schedule before fetch');
    rejects(fn()=>fetch_agency_items(array_replace($source,['endpoint'=>'http://example.org/subscription']),fn()=>$doc),'Authenticated agency refuses plaintext HTTP');
    $rss=function($title,$guid){return '<rss version="2.0"><channel><item><title>'.$title.'</title><link>https://example.org/news/'.$guid.'</link><guid>'.$guid.'</guid><description>İstanbul ulaşım yatırımlarıyla ilgili doğrulanmış kaynak metni.</description></item></channel></rss>';};
    Database::query('DELETE FROM rh6_news_sources'); // Isolate fixture sources from installed provider presets.
    foreach(['One','Two','Unavailable'] as $name)Database::save('news_sources',['name'=>$name,'feed_url'=>'https://example.org/'.$name,'active'=>1,'agenda_enabled'=>1]);
    $scan=scan_agenda(function($url)use($rss){if(str_ends_with($url,'Unavailable'))throw new RuntimeException('Fixture unavailable');return $rss(str_ends_with($url,'One')?'İstanbul ulaşım yatırımları başladı':'İstanbul ulaşım yatırımları için çalışmalar başladı',basename($url));});
    check($scan===['healthy'=>2,'total'=>2,'common'=>1]&&(int)Database::scalar('SELECT source_count FROM rh6_agenda_items LIMIT 1')===2,'Agenda finds common topic across two independent sources');
    check(Database::scalar("SELECT status FROM rh6_agenda_health WHERE name='Unavailable'")==='error','Agenda reports real source failure');
    scan_agenda(fn($url)=>$rss('İstanbul ulaşım yatırımları çalışmaları başladı',basename($url)));check((int)Database::scalar('SELECT COUNT(*) FROM rh6_agenda_items')===1,'Agenda refresh does not duplicate similar topic');
    $suggestion=['title'=>'İstanbul ulaşım yatırımları değerlendirildi','summary'=>str_repeat('Kaynak özeti. ',10),'seo_title'=>'İstanbul ulaşım yatırımları değerlendirildi','seo_description'=>str_repeat('Kaynak özeti. ',10),'focus_keyword'=>'İstanbul','body'=>'<h2>Ulaşım yatırımları</h2><p>'.str_repeat('Yalnızca verilen kaynak bilgilerini değerlendiriyoruz. ',6).'</p><script>bad()</script>'];
    $result=openai_article(['facts'=>str_repeat('İstanbul ulaşım yatırımları başladı. ',4),'kind'=>'opinion','words'=>700],function($payload)use($suggestion){check($payload['text']['format']['strict']===true&&str_contains($payload['instructions'],'uydurma'),'AI article uses strict schema and factual instructions');return ['output'=>[['content'=>[['type'=>'output_text','text'=>json_encode($suggestion)]]]]];});
    check($result['title']===$suggestion['title']&&!str_contains($result['body'],'script'),'Shared AI article response is validated and sanitized');
    rejects(fn()=>openai_article(['facts'=>str_repeat('Facts ',20),'kind'=>'article'],fn()=>['output'=>[]]),'AI empty output rejected');
    check(str_contains(openai_connection_test(fn()=>['output'=>[['content'=>[['type'=>'output_text','text'=>'Bağlantı başarılı']]]]]),'başarılı'),'Central API test requires actual model output');
    rejects(fn()=>openai_connection_test(fn()=>['output'=>[]]),'API test does not claim success for empty model output');
    $teams=parse_league_csv('A;2;1;1;0;4;2;4' . "\n" . 'B;2;0;1;1;1;3;1');check($teams[0]['points']===4&&count($teams)===2,'League CSV parses actual standings');
    rejects(fn()=>parse_league_csv('A;2;3;0;0;4;2;9'),'League rejects inconsistent match totals');
    $remote=['response'=>[['league'=>['standings'=>[[['team'=>['name'=>'Fixture A'],'all'=>['played'=>2,'win'=>1,'draw'=>1,'lose'=>0,'goals'=>['for'=>4,'against'=>2]],'points'=>4]]]]]]];
    check(count(refresh_standings(function($url,$headers)use($remote){check(str_contains($url,'league=203')&&$headers===['x-apisports-key: local-football-key'],'Süper Lig API request uses private central key');return json_encode($remote);}))===1,'Provider standings update stores returned data');
    put_setting('market_mode','tcmb');$result=refresh_markets(true,function($url){if(str_contains($url,'tcmb'))return '<Tarih_Date><Currency Kod="USD"><ForexSelling>49.0600</ForexSelling></Currency><Currency Kod="EUR"><ForexSelling>55.1800</ForexSelling></Currency></Tarih_Date>';return '{"bitcoin":{"try":4139,"try_24h_change":-0.2}}';});check($result['ok']&&Database::scalar("SELECT value FROM rh6_settings WHERE name='market_usd'")==='49,0600','TCMB and Bitcoin fixture data update market values');
    $previous=Database::scalar("SELECT value FROM rh6_settings WHERE name='market_usd'");$result=refresh_markets(true,fn()=>'<html>Unavailable</html>');check(!$result['ok']&&Database::scalar("SELECT value FROM rh6_settings WHERE name='market_usd'")===$previous,'Market failure preserves previous successful values');
}finally{if($original===null)@unlink($private);else file_put_contents($private,$original,LOCK_EX);}
echo "Command provider tests completed; local fixtures, no live paid API requests.\n";
