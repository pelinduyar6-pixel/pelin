/* Disposable local install; no live API calls. */
const {chromium}=require('playwright'),fs=require('fs'),path=require('path');
(async()=>{
 const base=process.argv[2],out=process.env.REFLEX_SCREENSHOTS||'/workspace/outputs/reflex-command';fs.mkdirSync(out,{recursive:true});
 const route=(p,q={})=>base+'/index.php?'+new URLSearchParams({route:p,...q});
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 const check=(ok,label)=>{if(!ok)throw Error(label);console.log('PASS',label);};
 await page.goto(route('/panel/giris'));await page.locator('[name=email]').fill('test-admin@example.invalid');await page.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD);await page.getByRole('button',{name:'Giriş yap'}).click();await page.waitForURL(/route=%2Fpanel$/);
 const screens=['header','ajanslar','api-merkezi','ai-yazar','gundem','moduller','performans','google','sitemap','gelen-kutusu','uyeler','spor','piyasalar'];
 for(const width of [1440,320]){await page.setViewportSize({width,height:1000});for(const screen of screens){const response=await page.goto(route('/panel/'+screen));check(response.status()===200&&await page.locator('.box').count()===0&&await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),screen+' renders within '+width+'px');if(width===1440)await page.screenshot({path:path.join(out,'panel-'+screen+'.png')});}}
 await page.setViewportSize({width:1440,height:1000});await page.goto(route('/panel/reklamlar/yeni'));await page.locator('[data-ad-template]').first().click();check((await page.locator('[name=code]').inputValue()).length>20,'Ad custom-code generator fills editor');
 const reader=await browser.newPage({viewport:{width:1440,height:1000}});reader.on('pageerror',e=>errors.push(e.message));
 for(const theme of [1,2,3,4]){
  await page.goto(route('/panel/tema'));await page.locator('[name=theme_style][value="'+theme+'"]').check();await page.getByRole('button',{name:'Tema ayarlarını kaydet'}).click();
  await reader.goto(base,{waitUntil:'networkidle'});await reader.evaluate(()=>document.fonts.ready);
  check(await reader.locator('.markets-pro>div').count()===5,'Theme '+theme+' displays all five markets');check(await reader.locator('.authors-middle').count()===1,'Theme '+theme+' has one centered authors section');check(await reader.locator('.category-spor .league-table').count()===1,'Theme '+theme+' displays league beside sports');
  check(await reader.locator('.sports-lead').evaluate(e=>e.getBoundingClientRect().height<=400&&e.getBoundingClientRect().height>=200),'Sports lead stays within intended size');check(await reader.locator('.sports-pair').evaluate(e=>e.getBoundingClientRect().bottom<=e.closest('.category-spor').getBoundingClientRect().bottom),'Sports cards stay inside their section');check(await reader.locator('.category-magazin .picture-card').count()>=6,'Theme '+theme+' has filled magazine grid');
  const track=reader.locator('.ticker-track'),before=await track.evaluate(e=>getComputedStyle(e).transform);await reader.waitForTimeout(350);const after=await track.evaluate(e=>getComputedStyle(e).transform);check(before!==after,'Theme '+theme+' ticker moves continuously');
  await reader.locator('.ticker-toggle').click();check(await reader.locator('.ticker-toggle').getAttribute('aria-pressed')==='true'&&await track.evaluate(e=>getComputedStyle(e).animationPlayState)==='paused','Ticker pause control works');await reader.locator('.ticker-toggle').click();
  await reader.screenshot({path:path.join(out,'tema-'+theme+'-1440.png')});
  if(theme===1){for(const [selector,name] of [['.authors-middle','yazarlar-orta'],['.category-spor','spor-puan'],['.category-magazin','magazin'],['.category-saglik','saglik'],['.site-footer','footer-1']]){const element=reader.locator(selector);if(await element.count())await element.screenshot({path:path.join(out,name+'.png')});}}
  await reader.setViewportSize({width:320,height:844});await reader.reload({waitUntil:'networkidle'});check(await reader.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Theme '+theme+' updated content fits mobile');await reader.screenshot({path:path.join(out,'tema-'+theme+'-320.png')});await reader.setViewportSize({width:1440,height:1000});
 }
 await page.goto(route('/panel/tema'));await page.locator('[name=theme_style][value="1"]').check();await page.getByRole('button',{name:'Tema ayarlarını kaydet'}).click();
 await reader.goto(route('/son-haberler'));const href=await reader.locator('.listing-card a,.news-card a,a.picture-card').first().getAttribute('href').catch(()=>null);if(href){await reader.goto(new URL(href,base).href);await reader.evaluate(()=>scrollTo(0,0));await reader.screenshot({path:path.join(out,'haber-top.png')});}
 const editor=await browser.newPage();await editor.goto(route('/panel/giris'));await editor.locator('[name=email]').fill('test-editor@example.invalid');await editor.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD);await editor.getByRole('button',{name:'Giriş yap'}).click();
 for(const screen of ['makaleler/yeni','ai-yazar','performans'])check((await editor.goto(route('/panel/'+screen))).status()===200,'Editor can use '+screen);
 for(const screen of ['gelen-kutusu','api-merkezi','ajanslar','google','moduller'])check((await editor.goto(route('/panel/'+screen))).status()===403,'Editor cannot use '+screen);
 check(errors.length===0,'No new-screen JavaScript errors: '+errors.join('; '));await browser.close();
})().catch(error=>{console.error(error);process.exit(1);});
