<?php
// Run on a disposable local installation. Network documents below are fixtures.
declare(strict_types=1);
require __DIR__.'/../app/core.php';require __DIR__.'/../app/pro.php';require __DIR__.'/../app/install.php';require __DIR__.'/../app/integrations.php';
$config=is_file(ROOT.'/storage/site.php')?require ROOT.'/storage/site.php':[];if(!in_array(parse_url($config['site_url']??'',PHP_URL_HOST),['127.0.0.1','localhost'],true))exit(1);
function check(bool $ok,string $label):void{if(!$ok)throw new RuntimeException('FAIL '.$label);echo 'PASS '.$label.PHP_EOL;}
function rejects(callable $f,string $label):void{try{$f();}catch(InvalidArgumentException|RuntimeException $ex){check(true,$label);return;}throw new RuntimeException('FAIL '.$label);}
$pdo=new PDO('sqlite::memory:');$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);Database::use($pdo);create_schema($pdo,'sqlite');seed_site('Test','test@example.invalid','Local-test-password-2026!',false);
check((int)Database::scalar('SELECT COUNT(*) FROM rh6_news_sources')===4,'Four editable TRT/NTV/CNN/Sözcü presets installed');
$ids=array_column(Database::rows('SELECT id FROM rh6_news_sources'),'id');put_setting('app_schema','3.0.0');migrate_pro_schema();check(array_column(Database::rows('SELECT id FROM rh6_news_sources'),'id')===$ids,'Schema upgrade and presets are idempotent');
check(editorial_plain_text('<h2>Başlık</h2><p>Haber &amp; bilgi</p>')==='Başlık Haber & bilgi','SEO extracts readable text with paragraph and entity boundaries');
$filled=seo_autofill(['title'=>'İstanbul ulaşım yatırımlarının ayrıntıları açıklandı','summary'=>'','body'=>'<p>'.str_repeat('Mevcut haber metni kullanılır. ',10).'</p>','seo_title'=>'Elle yazılan başlık','seo_description'=>'','slug'=>'']);
check($filled['seo_title']==='Elle yazılan başlık'&&mb_strlen($filled['seo_description'])<=160&&$filled['slug']!=='','Autofill preserves manual SEO and generates bounded metadata');
check(!str_contains($filled['summary'],'<p>')&&str_starts_with($filled['summary'],'Mevcut haber'),'Autofill uses existing content without invented facts');
$embed=validated_embed('<iframe src="https://www.youtube.com/embed/abcdefghijk?autoplay=1" onload="evil()" title="Haber"></iframe><script>evil()</script>');check(str_contains($embed,'youtube-nocookie.com/embed/abcdefghijk')&&!str_contains($embed,'evil')&&!str_contains($embed,'autoplay'),'Embed rebuilds trusted video iframe and strips executable attributes');
check(str_contains(validated_embed('<iframe src="https://player.vimeo.com/video/1234?h=abcdef1234"></iframe>'),'h=abcdef1234'),'Vimeo private video hash retained');
foreach(['javascript:alert(1)','https://evil.example/embed','https://www.youtube.com.evil.example/embed/abcdefghijk','http://www.youtube.com/embed/abcdefghijk','https://user:secret@www.youtube.com/embed/abcdefghijk','https://www.youtube.com/evil.js'] as $src)rejects(fn()=>validated_embed('<iframe src="'.$src.'"></iframe>'),'Embed rejects '.$src);
$article='<html><head><meta property="og:type" content="article"><meta property="og:title" content="İstanbul ulaşım yatırımlarının ayrıntıları açıklandı"><meta property="og:description" content="Doğrulanmış kaynak özeti"><meta property="og:image" content="/foto.jpg"></head><body><article><h1>Başlık</h1><p>'.str_repeat('Kaynakta bulunan gerçek haber metni. ',4).'</p><script>evil()</script></article></body></html>';
$parsed=source_page_items($article,'https://example.org/news/1');check(count($parsed)===1&&$parsed[0]['image']==='https://example.org/foto.jpg'&&!str_contains($parsed[0]['body'],'evil'),'Article page extracts metadata and safe paragraph content');
$list='<h2><a href="/news/1">İstanbul ulaşım yatırımlarının ayrıntıları açıklandı</a></h2><h3><a href="/news/2">Spor kulüplerinin yeni sezon hazırlıkları sürüyor</a></h3><h2><a href="https://evil.example/news">Başka alan adından haber gelmez</a></h2>';
check(count(source_page_items($list,'https://example.org/gundem'))===2,'Category URL parses headline links and excludes foreign navigation');
check(count(source_page_items('<a href="/baslik-p12345"><img src="/image.jpg" alt="Kategori sayfasındaki haberin gerçek başlığı"></a>','https://example.org/gundem'))===1,'Category reader recognizes numeric article URLs and image captions');
$rss='<rss><channel><item><title>İstanbul ulaşım yatırımlarının ayrıntıları açıklandı</title><link>https://example.org/news/1</link><description>Kaynağın haber özeti.</description></item></channel></rss>';
$discovery='<link rel="alternate" type="application/rss+xml" href="/rss.xml">'.$list;
$calls=[];$items=fetch_source_items(['feed_url'=>'https://example.org/gundem','source_kind'=>'auto','fetch_full'=>1,'max_items'=>5],function($url)use(&$calls,$discovery,$rss,$article){$calls[]=$url;return str_ends_with($url,'rss.xml')?$rss:(str_ends_with($url,'news/1')?$article:$discovery);});check(count($items)===1&&count($calls)===3&&str_contains($items[0]['body'],'gerçek haber'),'Automatic URL discovers RSS and enriches selected article content');
rejects(fn()=>fetch_source_items(['feed_url'=>'https://example.org/gundem','source_kind'=>'rss'],fn()=>$list),'Explicit RSS mode rejects HTML');
Database::query('DELETE FROM rh6_news_sources');Database::save('news_sources',['name'=>'Tek kaynak','feed_url'=>'https://example.org/gundem','source_kind'=>'page','agenda_enabled'=>1,'active'=>0]);$result=scan_agenda(fn()=>$list);
check($result===['healthy'=>1,'total'=>2,'common'=>0]&&(int)Database::scalar('SELECT COUNT(*) FROM rh6_agenda_items')===2,'Agenda includes single-source news independently of automatic bot switch');
scan_agenda(fn()=>$list);check((int)Database::scalar('SELECT COUNT(*) FROM rh6_agenda_items')===2,'Single-source agenda rescan deduplicates');
rejects(fn()=>public_url_target(source_absolute_url('http://169.254.169.254/latest','https://example.org')),'Discovered feeds retain private-network protection');
echo 'Editorial integrations completed; fixture documents, no paid requests.'.PHP_EOL;
