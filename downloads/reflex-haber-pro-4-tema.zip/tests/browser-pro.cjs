/* Run against a disposable local install with the smoke-test admin only. */
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
(async()=>{
 const base=process.argv[2]||'http://127.0.0.1:8113',out=process.env.REFLEX_SCREENSHOTS||'/workspace/outputs/reflex-pro';fs.mkdirSync(out,{recursive:true});
 const testSlug='tarayici-pro-'+Date.now();
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const route=(p,q={})=>base+'/index.php?'+new URLSearchParams({route:p,...q});
 const check=(ok,msg)=>{if(!ok)throw Error(msg);console.log('PASS',msg);};
 await page.goto(route('/panel/giris'));await page.locator('[name=email]').fill('test-admin@example.invalid');await page.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD);await page.getByRole('button',{name:'Giriş yap'}).click();await page.waitForURL(/route=%2Fpanel$/);
 await page.screenshot({path:path.join(out,'panel-desktop.png')});
 for(const module of ['tema','ogeler','ozel-kodlar','botlar','seo','ai','medya','guvenlik','reklamlar','haberler']){const response=await page.goto(route('/panel/'+module));check(response.status()===200&&await page.locator('.box').count()===0,'Panel module '+module);}
 for(const theme of [1,2,3,4]){
  await page.goto(route('/panel/tema'));await page.locator('[name=theme_style][value="'+theme+'"]').check();await page.getByRole('button',{name:'Tema ayarlarını kaydet'}).click();await page.waitForLoadState('networkidle');
  for(const width of [1440,390,320]){
   await page.setViewportSize({width,height:width<500?844:1000});await page.goto(base,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
   const state=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,width:innerWidth,broken:[...document.images].filter(i=>i.complete&&!i.naturalWidth).map(i=>i.src),slides:document.querySelector('.headline-carousel')?.querySelectorAll('.hero-slide').length}));
   check(state.scroll<=width,'Theme '+theme+' width '+width+' no overflow');check(!state.broken.length,'Theme '+theme+' images load');check(state.slides>1,'Theme '+theme+' headlines available');
   await page.screenshot({path:path.join(out,'tema-'+theme+'-'+width+'.png')});
   if(width===1440)await page.screenshot({path:path.join(out,'tema-'+theme+'-full.png'),fullPage:true});
  }
  await page.setViewportSize({width:1440,height:1000});await page.goto(base,{waitUntil:'networkidle'});await page.mouse.move(2,2);
  const before=await page.locator('.headline-carousel').first().locator('.hero-slide:not([hidden])').getAttribute('href');await page.waitForTimeout(5600);const after=await page.locator('.headline-carousel').first().locator('.hero-slide:not([hidden])').getAttribute('href');
  check(before!==after,'Theme '+theme+' automatically advances');
 }
 await page.goto(route('/panel/tema'));await page.locator('[name=theme_style][value="1"]').check();await page.getByRole('button',{name:'Tema ayarlarını kaydet'}).click();
 for(const width of [1440,768,390,320]){
  await page.setViewportSize({width,height:width<500?844:1000});await page.goto(route('/panel'),{waitUntil:'networkidle'});check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Dashboard width '+width);await page.screenshot({path:path.join(out,'panel-'+width+'.png')});
  await page.goto(route('/panel/haberler/yeni'),{waitUntil:'networkidle'});check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'News editor width '+width);await page.screenshot({path:path.join(out,'editor-'+width+'.png')});
  if(width<1100){await page.locator('.admin-menu').click();check(await page.locator('.admin-menu').getAttribute('aria-expanded')==='true','Panel mobile menu opens');await page.locator('.sidebar-backdrop').click({position:{x:width-10,y:250}});}
 }
 await page.setViewportSize({width:1440,height:1000});await page.goto(route('/panel/haberler/yeni'));
 await page.locator('[name=title]').fill('Tarayıcı testi: İstanbul için yeni ulaşım planı');await page.locator('[name=slug]').fill(testSlug);await page.locator('[name=summary]').fill('İstanbul ulaşım gündeminde yer alan yeni planın ayrıntılarını ve uygulama sürecini bu haberimizde inceliyoruz.');
 await page.locator('.rich-editor').fill('İstanbul ulaşım için örnek test metni. '.repeat(70));await page.locator('[name=focus_keyword]').fill('İstanbul');await page.locator('[name=kind]').selectOption('video');await page.locator('[name=video_file]').setInputFiles(path.join(__dirname,'../assets/v6/demo/reflex-video-demo.mp4'));await page.locator('[name=image_file]').setInputFiles(path.join(__dirname,'../assets/v6/demo/bogaz-5-2.jpg'));await page.locator('[name=status]').selectOption('published');
 await page.waitForTimeout(900);check(Number(await page.locator('[data-live-score]').textContent())>=70,'Live SEO score updates');await page.locator('.save-btn').click();await page.waitForURL(/route=%2Fpanel%2Fhaberler$/);check(await page.getByText('Kayıt kaydedildi.').isVisible(),'Uploaded video news saved');
 const guest=await browser.newContext({viewport:{width:1440,height:1000}}),reader=await guest.newPage();reader.on('pageerror',e=>errors.push(e.message));await reader.goto(route('/haber/'+testSlug),{waitUntil:'networkidle'});check(await reader.locator('.article-video video').count()===1,'Uploaded video appears in article');
 const videoOK=await reader.locator('.article-video video').evaluate(video=>new Promise(resolve=>{if(video.readyState>=1)return resolve(video.duration>0);video.addEventListener('loadedmetadata',()=>resolve(video.duration>0),{once:true});video.addEventListener('error',()=>resolve(false),{once:true});setTimeout(()=>resolve(false),5000);}));check(videoOK,'MP4 video metadata loads');
 await reader.locator('[data-kind=like]').click();await reader.getByText('Tepkiniz kaydedildi.').waitFor();check(await reader.locator('[data-kind=like] .reaction-count').textContent()==='1','Reaction saves actual count');await reader.waitForTimeout(800);await reader.locator('[data-kind=love]').click();await reader.waitForTimeout(400);check(await reader.locator('[data-kind=like] .reaction-count').textContent()==='0'&&await reader.locator('[data-kind=love] .reaction-count').textContent()==='1','One reader can change reaction without duplicate');
 await reader.screenshot({path:path.join(out,'haber-desktop.png')});await reader.setViewportSize({width:390,height:844});await reader.reload({waitUntil:'networkidle'});check(await reader.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Article mobile no overflow');await reader.screenshot({path:path.join(out,'haber-mobile.png')});
 for(const width of [1440,390,320]){await reader.setViewportSize({width,height:width<500?844:1000});await reader.goto(route('/kategori/gundem'),{waitUntil:'networkidle'});check(await reader.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Category width '+width);check(await reader.locator('.category-page-hero').count()===1,'Category includes headline carousel');await reader.screenshot({path:path.join(out,'kategori-'+width+'.png')});}
 check(errors.length===0,'No JavaScript errors: '+errors.join('; '));await browser.close();
})().catch(e=>{console.error(e);process.exit(1);});
