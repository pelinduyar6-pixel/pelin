/* Run against the disposable local smoke installation only. */
const {chromium}=require('playwright');
const fs=require('fs');
const path=require('path');
(async()=>{
 const base=process.argv[2]||'http://127.0.0.1:8110';
 const output=process.env.DEMO6_SCREENSHOTS||'/workspace/outputs/demo6-yeni';fs.mkdirSync(output,{recursive:true});
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:1440,height:1000}});const page=await context.newPage();
 const problems=[];page.on('pageerror',e=>problems.push('JS '+e.message));page.on('response',r=>{if(r.status()>=400)problems.push(r.status()+' '+r.url());});
 const route=p=>base+'/index.php?'+new URLSearchParams({route:p});
 for(const width of [1440,768,390,320]){
  await page.setViewportSize({width,height:width<500?844:1000});await page.goto(base,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
  const state=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,broken:[...document.images].filter(i=>i.complete&&!i.naturalWidth).map(i=>i.src),top:document.querySelector('.top-stories').getBoundingClientRect().toJSON(),hero:document.querySelector('.headline-carousel').getBoundingClientRect().toJSON()}));
  if(state.scroll>width)throw Error('Frontend overflow at '+width+': '+state.scroll);
  if(state.broken.length)throw Error('Broken images '+JSON.stringify(state.broken));
  await page.screenshot({path:path.join(output,'ana-sayfa-'+width+'.png')});console.log('PASS home viewport',width,JSON.stringify(state));
  await page.locator('.headline-carousel .carousel-dots button').nth(1).click();
  if(await page.locator('.headline-carousel .hero-slide').nth(1).isHidden())throw Error('Slider did not change');
  if(width<850){await page.locator('.menu-button').click();if(!await page.locator('.main-nav').isVisible())throw Error('Mobile menu');await page.locator('.menu-button').click();}
 }
 await page.setViewportSize({width:1440,height:1000});await page.goto(base,{waitUntil:'networkidle'});await page.evaluate(()=>window.scrollTo(0,850));await page.waitForTimeout(300);await page.screenshot({path:path.join(output,'ana-sayfa-alt.png')});
 await page.goto(route('/panel/giris'));await page.locator('[name=email]').fill('test-admin@example.invalid');await page.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD);await page.getByRole('button',{name:'Giriş yap'}).click();await page.waitForURL(/route=%2Fpanel$/);await page.screenshot({path:path.join(output,'panel-dashboard.png')});
 for(const width of [1440,1024,768,390,320]){
  await page.setViewportSize({width,height:width<500?844:1000});await page.goto(route('/panel/haberler/yeni'),{waitUntil:'networkidle'});
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);if(overflow)throw Error('Admin form overflow at '+width);
  const editor=await page.locator('.editor-grid').boundingBox(),publish=await page.locator('.publish-column').boundingBox();if(publish.x<0||publish.x+publish.width>width)throw Error('Publish panel outside viewport');
  await page.screenshot({path:path.join(output,'panel-haber-'+width+'.png')});console.log('PASS admin viewport',width,JSON.stringify({editor,publish}));
 }
 await page.setViewportSize({width:1440,height:1000});await page.goto(route('/panel/haberler/yeni'));
 await page.locator('[name=title]').fill('Tarayıcı testi haber');await page.locator('[name=summary]').fill('Tarayıcı üzerinden düzenlendi.');await page.locator('.rich-editor').fill('Editörden girilen içerik');
 await page.locator('[name=kind]').selectOption('gallery');await page.locator('[name=image_file]').setInputFiles(path.join(__dirname,'../assets/v6/demo/bogaz-5-2-400x225.jpg'));
 await page.locator('[name="gallery_images[]"]').setInputFiles([path.join(__dirname,'../assets/v6/demo/tarla-5-2.jpg'),path.join(__dirname,'../assets/v6/demo/bogaz-5-2.jpg')]);
 await page.locator('.save-btn').click();await page.waitForURL(/route=%2Fpanel%2Fhaberler$/);if(!await page.getByText('Kayıt kaydedildi.').isVisible())throw Error('Browser save failed');
 const row=page.locator('tr').filter({hasText:'Tarayıcı testi haber'});await row.getByText('Düzenle').click();
 if(await page.locator('.gallery-previews img').count()!==2)throw Error('Gallery photos not persisted');if(!(await page.locator('.rich-editor').innerText()).includes('Editörden girilen içerik'))throw Error('Editor content not saved');
 await page.locator('[name=status]').selectOption('published');await page.locator('.save-btn').click();await page.waitForURL(/route=%2Fpanel%2Fhaberler$/);
 await page.goto(route('/haber/tarayici-testi-haber'));if(await page.locator('.article-image').count()!==3)throw Error('Gallery detail images missing');console.log('PASS rich editor, multi-image gallery and publish through browser');
 await page.goto(route('/panel/haberler'));page.once('dialog',dialog=>dialog.accept());await page.locator('tr').filter({hasText:'Tarayıcı testi haber'}).getByRole('button',{name:'Sil',exact:true}).click();await page.waitForLoadState('networkidle');
 if(problems.length)throw Error('Browser problems: '+JSON.stringify(problems));console.log('PASS no missing resources or JavaScript errors');await browser.close();
})().catch(e=>{console.error(e);process.exit(1);});
