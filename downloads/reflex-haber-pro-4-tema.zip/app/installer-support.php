<?php
declare(strict_types=1);

function installer_error(Throwable $exception, string $stage): array {
    $sqlState = $exception instanceof PDOException ? (string)($exception->errorInfo[0] ?? '') : '';
    $code = $exception instanceof PDOException ? (int)($exception->errorInfo[1] ?? $exception->getCode()) : 0;
    $message = match ($code) {
        1045 => 'MySQL giriş bilgilerini reddetti. Hosting panelinden veritabanı kullanıcısının şifresini kontrol edin veya yeniden belirleyin. Kullanıcı adını hesap ön ekiyle birlikte tam yazın.',
        1044 => 'Veritabanı kullanıcısının seçilen veritabanına erişim yetkisi yok. Hosting panelinde kullanıcıyı bu veritabanına ekleyip tüm veritabanı yetkilerini verin.',
        1049 => 'Belirtilen veritabanı bulunamadı. Hosting panelindeki tam veritabanı adını, hesap ön eki dahil kullanın.',
        1142, 1143, 1227 => 'Veritabanına bağlantı var ancak gerekli işlem yetkisi yok. Kullanıcıya bu veritabanı için CREATE, ALTER, INDEX, SELECT, INSERT, UPDATE ve DELETE yetkilerini verin.',
        2002, 2003 => 'MySQL sunucusuna ulaşılamadı. Hosting sağlayıcısının verdiği veritabanı sunucusu ve portunu kullanın; localhost için sunucunun MySQL soket ayarını da kontrol ettirin.',
        2005 => 'Veritabanı sunucusunun adresi çözümlenemedi. Hosting sağlayıcısının verdiği sunucu adını kontrol edin.',
        2006, 2013 => 'MySQL bağlantısı işlem sırasında kesildi. Sunucunun durumunu kontrol edip tekrar deneyin.',
        1054, 1146 => 'Mevcut Reflex Haber tablolarının yapısı bu sürümle uyumlu değil. Veritabanını silmeyin; yedeğinizi koruyarak hata koduyla destek alın.',
        1062 => 'Veritabanında aynı isimli kayıt zaten var. Mevcut kurulumu yeniden bağlama seçeneğini kullanın; tabloları silmeyin.',
        1071 => 'MySQL indeks uzunluğu sınırı bu tablo yapısını desteklemiyor. Hosting sağlayıcısından güncel MySQL/MariaDB ve InnoDB ayarlarını kontrol etmesini isteyin.',
        1290 => 'MySQL sunucusu bu yazma işlemini kısıtlıyor. Hosting sağlayıcısından veritabanının yazılabilir olduğunu doğrulamasını isteyin.',
        default => match ($stage) {
            'configuration' => 'Ayar dosyası storage/site.php olarak kaydedilemedi. storage klasörünün sahipliğini, PHP yazma iznini ve hosting disk kotasını kontrol edin. Veritabanı kayıtlarını silmeyin.',
            'schema' => 'Veritabanı bağlantısı kuruldu ancak tablolar hazırlanamadı. Veritabanı yetkilerini ve aşağıdaki hata kodunu kontrol edin.',
            'content', 'commit' => 'Veritabanı bağlantısı kuruldu ancak kurulum kayıtları tamamlanamadı. Tabloları silmeden aşağıdaki hata koduyla destek alın.',
            default => 'Veritabanı bağlantısı kurulamadı. Seçilen PDO sürücüsünü, sunucu adresini ve hosting veritabanı bilgilerini kontrol edin.'
        }
    };
    if ($exception instanceof InvalidArgumentException || http_response_code() === 419) $message = $exception->getMessage();
    return ['message'=>$message, 'code'=>$code, 'sqlstate'=>preg_match('/^[A-Z0-9]{5}$/', $sqlState) ? $sqlState : '', 'stage'=>$stage];
}

function installer_has_users(PDO $pdo, string $driver): bool {
    $statement = $pdo->prepare($driver === 'sqlite'
        ? "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
        : 'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');
    $statement->execute(['rh6_users']);
    return (bool)$statement->fetchColumn() && (int)$pdo->query('SELECT COUNT(*) FROM rh6_users')->fetchColumn() > 0;
}

function installer_verify_owner(PDO $pdo, string $email, string $password): void {
    $statement = $pdo->prepare("SELECT password FROM rh6_users WHERE email=? AND role='admin' AND active=1 LIMIT 1");
    $statement->execute([$email]);
    $hash = $statement->fetchColumn();
    if (!is_string($hash) || !password_verify($password, $hash)) {
        throw new InvalidArgumentException('Mevcut yönetici hesabı doğrulanamadı. Daha önce bu sitede kullandığınız yönetici e-postasını ve şifresini girin. Hesaplar ve haberler değiştirilmedi.');
    }
}

function installer_prepare_config(array $config): string {
    $temporary = ROOT.'/storage/.config-'.bin2hex(random_bytes(8)).'.php';
    $contents = '<?php return '.var_export($config, true).';'.PHP_EOL;
    try {
        if (@file_put_contents($temporary, $contents, LOCK_EX) !== strlen($contents) || !@chmod($temporary, 0600)) {
            throw new RuntimeException('Configuration write failed');
        }
        // Check rename permission before inserting installation records.
        $staged = $temporary.'.ready';
        if (!@rename($temporary, $staged)) throw new RuntimeException('Configuration staging failed');
        return $staged;
    } catch (Throwable $exception) {
        @unlink($temporary);
        throw $exception;
    }
}
