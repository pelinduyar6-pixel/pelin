<?php
declare(strict_types=1);
require_once __DIR__.'/public-services.php';
if(public_service($route))return;
$categories=Database::rows('SELECT * FROM rh6_categories ORDER BY sort_order,id');
$ticker=news_rows('AND n.is_breaking = 1',[],8);
$authors=Database::rows('SELECT id,name,slug,image,bio FROM rh6_users WHERE active=1 AND public_profile=1 ORDER BY id LIMIT 8');
$pageTitle=setting('site_name'); $description=setting('description'); $ogImage='';
$screen='listing'; $items=[]; $heading='';$listingFilter='';$listingParams=[];$pageNumber=max(1,min(100000,(int)(is_scalar($_GET['page']??null)?$_GET['page']:1)));$pages=1;$total=0;
if ($route==='/') {
    $screen='home';
    $top=news_rows('AND n.is_top=1',[],4); $headlines=news_rows('AND n.is_headline=1',[],17);
    if(!$headlines) $headlines=news_rows('',[],8);
    if(!$top) $top=news_rows('',[],4);
    $boxes=news_rows('AND n.is_box=1',[],8); if(!$boxes) $boxes=news_rows('',[],8);
    $featured=news_rows('AND n.is_featured=1',[],9); if(!$featured) $featured=news_rows('',[],9);
    $latest=news_rows('',[],6);$topFeature=array_values(array_column(array_merge($top,$latest),null,'id'));$topFeature=array_slice($topFeature,0,5);if(setting('theme_style','1')!=='1')$screen='home-theme';
} elseif (preg_match('~^/haber/([^/]+)$~',$route,$match)) {
    $items=news_rows('AND n.slug=?',[$match[1]],1); $article=$items[0]??null;
    if(!$article) { http_response_code(404); view('error',['message'=>'Haber bulunamadı veya henüz yayımlanmadı.']); return; }
    if(is_post()) {
        verify_csrf();
        if(!$article['allow_comments']) throw new InvalidArgumentException('Bu haber yorumlara kapalı.');
        if(!empty($_POST['website'])) throw new InvalidArgumentException('Yorum gönderilemedi.');
        if(time()-(int)($_SESSION['last_comment']??0)<60) throw new InvalidArgumentException('Yeni yorum için bir dakika bekleyin.');
        Database::save('comments',['news_id'=>$article['id'],'name'=>text_input('name',100,true),'body'=>text_input('body',2000,true),'status'=>'pending','created_at'=>date('Y-m-d H:i:s')]);
        $_SESSION['last_comment']=time(); flash('Yorumunuz alındı. Editör onayından sonra yayımlanacak.'); redirect($route);
    }
    if(($_SERVER['REQUEST_METHOD']??'GET')==='GET'&&!user()){Database::query('UPDATE rh6_news SET views=views+1 WHERE id=?',[$article['id']]);track_view((int)$article['id']);}
    $visitor=visitor_hash();$reactionCounts=reaction_counts((int)$article['id']);$selectedReaction=Database::scalar('SELECT kind FROM rh6_reactions WHERE news_id=? AND visitor_hash=?',[$article['id'],$visitor]);$nextStory=news_rows('AND n.id<>?',[$article['id']],1)[0]??null;
    $screen='article'; $pageTitle=($article['seo_title']?:$article['title']).' · '.setting('site_name');
    $description=$article['seo_description']?:$article['summary']; $ogImage=media($article['image']);
    $related=news_rows('AND n.category_id=? AND n.id<>?',[$article['category_id'],$article['id']],4);
    $comments=Database::rows("SELECT name,body,created_at FROM rh6_comments WHERE news_id=? AND status='approved' ORDER BY id DESC",[$article['id']]);
} elseif (preg_match('~^/kategori/([^/]+)$~',$route,$match)) {
    $category=Database::row('SELECT * FROM rh6_categories WHERE slug=?',[$match[1]]);
    if(!$category) { http_response_code(404); view('error',['message'=>'Kategori bulunamadı.']); return; }
    $heading=$category['name'];$listingFilter='AND n.category_id=?';$listingParams=[$category['id']];
} elseif (preg_match('~^/yazar/([^/]+)$~',$route,$match)) {
    $author=Database::row('SELECT name,slug,bio,image,id FROM rh6_users WHERE slug=? AND active=1 AND public_profile=1',[$match[1]]);
    if(!$author) { http_response_code(404); view('error',['message'=>'Yazar bulunamadı.']); return; }
    $heading=$author['name'];$listingFilter='AND n.author_id=?';$listingParams=[$author['id']];
} elseif ($route==='/yazarlar') { $screen='authors'; $heading='Yazarlar'; }
elseif ($route==='/arama') {
    $q=trim(is_string($_GET['q']??null)?$_GET['q']:''); $q=function_exists('mb_substr')?mb_substr($q,0,100):substr($q,0,100);
    $heading=$q?'Arama: '.$q:'Haber ara';
    if($q){$listingFilter='AND (n.title LIKE ? OR n.summary LIKE ?)';$listingParams=['%'.$q.'%','%'.$q.'%'];}else $listingFilter='AND 1=0';
} elseif ($route==='/foto-galeri'||$route==='/video-galeri') { $heading=$route==='/foto-galeri'?'Foto Galeri':'Video Galeri'; $listingFilter='AND n.kind=?';$listingParams=[$route==='/foto-galeri'?'gallery':'video']; }
elseif ($route==='/son-haberler') { $heading='Son Haberler'; }
elseif (preg_match('~^/sayfa/([^/]+)$~',$route,$match)) {
    $page=Database::row('SELECT * FROM rh6_pages WHERE slug=? AND active=1',[$match[1]]);
    if(!$page) { http_response_code(404); view('error',['message'=>'Sayfa bulunamadı.']); return; }
    $screen='page'; $heading=$page['title'];
} else { http_response_code(404); view('error',['message'=>'Sayfa bulunamadı.']); return; }
if($screen==='listing'){
    $total=(int)Database::scalar('SELECT COUNT(*) FROM rh6_news n WHERE '.published_condition().' '.$listingFilter,[date('Y-m-d H:i:s'),...$listingParams]);$pages=max(1,(int)ceil($total/12));
    if($pageNumber>$pages){http_response_code(404);view('error',['message'=>'Bu sayfada haber bulunmuyor.']);return;}
    $items=news_rows($listingFilter,$listingParams,12,($pageNumber-1)*12);$categoryHero=$pageNumber===1?news_rows($listingFilter,$listingParams,5):[];$sidebarLatest=news_rows('',[],8);
}
if($screen!=='article')track_view();
if($heading) $pageTitle=$heading.' · '.setting('site_name');
$canonical=(require ROOT.'/storage/site.php')['site_url'].'/index.php?'.http_build_query(['route'=>$route]+($route==='/arama'?['q'=>$q]:[])+($pageNumber>1?['page'=>$pageNumber]:[]));
if($ogImage&&!preg_match('~^https?://~i',$ogImage)) { $siteUrl=parse_url((require ROOT.'/storage/site.php')['site_url']); $ogImage=$siteUrl['scheme'].'://'.$siteUrl['host'].(isset($siteUrl['port'])?':'.$siteUrl['port']:'').$ogImage; }
$isArticle=$screen==='article';if(!$ogImage)$ogImage=absolute_url(media(setting('seo_default_image')?:setting('theme_logo')?:($items[0]['image']??'')));
if($route==='/arama')header('X-Robots-Tag: noindex,follow');
view('site-header',compact('categories','ticker','pageTitle','description','ogImage','canonical','isArticle'));
view($screen,get_defined_vars());
view('site-footer');
