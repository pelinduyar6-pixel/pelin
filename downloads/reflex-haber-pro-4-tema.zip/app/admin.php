<?php
declare(strict_types=1);
function login_throttle(bool $failed=false, bool $reset=false): bool {
    $file=ROOT.'/storage/login-'.hash('sha256',$_SERVER['REMOTE_ADDR']??'local').'.json';
    $handle=fopen($file,'c+'); if(!$handle) throw new RuntimeException('Login storage unavailable');
    flock($handle,LOCK_EX); $state=json_decode(stream_get_contents($handle),true)?:['start'=>time(),'count'=>0];
    if(time()-(int)$state['start']>900||$reset) $state=['start'=>time(),'count'=>0];
    if($failed) $state['count']++;
    ftruncate($handle,0); rewind($handle); fwrite($handle,json_encode($state)); flock($handle,LOCK_UN); fclose($handle);
    return $state['count']>=20;
}
if($route==='/panel/giris') {
    if(user()&&in_array(user()['role'],['admin','editor'],true)&&user()['active']) redirect('/panel');
    $error='';
    if(is_post()) {
        verify_csrf();
        if(login_throttle()) { $error='Çok sayıda giriş denemesi yapıldı. 15 dakika sonra tekrar deneyin.'; http_response_code(429); }
        else {
            $email=text_input('email',190,true); $password=password_input('password',true);
            $account=Database::row('SELECT * FROM rh6_users WHERE email=?',[$email]);
            $valid=password_verify($password,$account['password']??'$2y$10$CjINIBVB26ntQiAYitp1N.bxkFUH1elVs3gxs8zQjcV4MT.tPf3uu');
            if($account&&$valid&&$account['active']&&in_array($account['role'],['admin','editor'],true)) {
                session_regenerate_id(true); $_SESSION['user_id']=$account['id']; $_SESSION['last_activity']=time(); unset($_SESSION['csrf']); login_throttle(false,true); redirect('/panel');
            }
            login_throttle(true); $error='E-posta veya şifre hatalı.';
        }
    }
    view('admin/login',compact('error')); return;
}
$currentUser=require_admin();
if($route==='/panel/cikis') { if(!is_post()){http_response_code(405);throw new InvalidArgumentException('Çıkış için paneldeki düğmeyi kullanın.');} verify_csrf(); $_SESSION=[];session_regenerate_id(true);redirect('/panel/giris'); }
$parts=explode('/',trim($route,'/'));$module=$parts[1]??'dashboard';$action=$parts[2]??'list';
$modules=['haberler'=>['table'=>'news','title'=>'Haber Yönetimi'],'yazarlar'=>['table'=>'users','title'=>'Yazarlar ve Kullanıcılar'],'kategoriler'=>['table'=>'categories','title'=>'Kategoriler'],'reklamlar'=>['table'=>'ads','title'=>'Reklam Yönetimi'],'sayfalar'=>['table'=>'pages','title'=>'Sayfalar'],'yorumlar'=>['table'=>'comments','title'=>'Yorumlar']];
if($currentUser['role']!=='admin'&&!in_array($module,['dashboard','haberler','yorumlar','hesabim','seo','api','medya','foto-galeri','videolar'],true)) {http_response_code(403);view('error',['message'=>'Bu işlem için yönetici yetkisi gerekiyor.']);return;}
$title='Haber Merkezi';$screen='dashboard';$error='';$record=[];$rows=[];
$statuses=['draft'=>'Taslak','published'=>'Yayında','scheduled'=>'Planlandı'];
$categories=Database::rows('SELECT * FROM rh6_categories ORDER BY sort_order,id');
$allAuthors=Database::rows('SELECT id,name FROM rh6_users WHERE active=1 ORDER BY name');
require_once __DIR__.'/admin-pro.php';
require_once __DIR__.'/public-services.php';
if(pro_admin_dispatch($module,$action,$currentUser,$categories,$allAuthors))return;
if($module==='ayarlar') {
    $title='Genel Ayarlar';$screen='settings';
    if(is_post()) { verify_csrf();
        $values=[];
        foreach(['site_name'=>100,'tagline'=>150,'description'=>500,'weather_city'=>50,'weather_value'=>50,'market_usd'=>50,'market_eur'=>50,'market_gold'=>50,'contact_email'=>190,'footer_text'=>500] as $key=>$length) {
            $value=text_input($key,$length,in_array($key,['site_name','contact_email']));
            if($key==='contact_email'&&!filter_var($value,FILTER_VALIDATE_EMAIL))throw new InvalidArgumentException('Geçerli iletişim e-postası girin.');
            $values[$key]=$value;
        }
        foreach(['facebook','instagram','youtube','google_news_url'] as $key) $values[$key]=url_input($key);
        foreach(['weather_enabled','market_enabled'] as $key) $values[$key]=(string)checked_input($key);
        $pdo=Database::connection();$pdo->beginTransaction();
        try{foreach($values as $key=>$value)put_setting($key,$value);$pdo->commit();}catch(Throwable $ex){$pdo->rollBack();throw $ex;}
        flash('Ayarlar kaydedildi.');redirect('/panel/ayarlar');
    }
} elseif($module==='hesabim') {
    $title='Hesabım';$screen='account';
    if(is_post()){verify_csrf();$old=password_input('old_password',true);$new=password_input('new_password',true);$account=Database::row('SELECT * FROM rh6_users WHERE id=?',[$currentUser['id']]);
        if(!password_verify($old,$account['password']))throw new InvalidArgumentException('Mevcut şifre hatalı.');
        if(strlen($new)<12||strlen($new)>72)throw new InvalidArgumentException('Yeni şifre 12–72 bayt uzunluğunda olmalı.');
        Database::save('users',['password'=>password_hash($new,PASSWORD_DEFAULT)],(int)$currentUser['id']);session_regenerate_id(true);flash('Şifreniz değiştirildi.');redirect('/panel/hesabim');
    }
} elseif($module==='demo-sil') {
    if(!is_post()){http_response_code(405);throw new InvalidArgumentException('Paneldeki örnek içerik kaldırma düğmesini kullanın.');}
    verify_csrf();$pdo=Database::connection();$pdo->beginTransaction();
    try {Database::query('DELETE FROM rh6_comments WHERE news_id IN (SELECT id FROM rh6_news WHERE is_demo=1)');Database::query('DELETE FROM rh6_news WHERE is_demo=1');Database::query('UPDATE rh6_news SET author_id=NULL WHERE author_id IN (SELECT id FROM rh6_users WHERE is_demo=1)');Database::query('DELETE FROM rh6_users WHERE is_demo=1');Database::query("UPDATE rh6_settings SET value='0' WHERE name='demo_notice'");$pdo->commit();}catch(Throwable $ex){$pdo->rollBack();throw $ex;}
    flash('Örnek haber ve yazarlar kaldırıldı. Sizin eklediğiniz içerikler korundu.');redirect('/panel');
} elseif(isset($modules[$module])) {
    $definition=$modules[$module];$table=$definition['table'];$title=$definition['title'];$screen='records';
    $id=isset($_GET['id'])&&is_scalar($_GET['id'])?(int)$_GET['id']:0;
    if(!$id&&$table==='news'&&in_array($_GET['kind']??'', ['gallery','video'],true))$record['kind']=$_GET['kind'];
    if($id){$record=Database::row('SELECT * FROM rh6_'.$table.' WHERE id=?',[$id]);if(!$record){http_response_code(404);view('error',['message'=>'Kayıt bulunamadı.']);return;}}
    if(is_post()) {
        verify_csrf();
        if($action==='sil') {
            if(!$id)throw new InvalidArgumentException('Silinecek kayıt bulunamadı.');
            if($table==='users'&&($id===$currentUser['id']||($record['role']==='admin'&&$record['active']&&(int)Database::scalar("SELECT COUNT(*) FROM rh6_users WHERE role='admin' AND active=1")<=1)))throw new InvalidArgumentException('Kendi hesabınızı veya son yöneticiyi silemezsiniz.');
            $pdo=Database::connection();$pdo->beginTransaction();
            try {
                if($table==='news'){Database::query('DELETE FROM rh6_comments WHERE news_id=?',[$id]);Database::query('DELETE FROM rh6_reactions WHERE news_id=?',[$id]);}
                if($table==='categories')Database::query('UPDATE rh6_news SET category_id=NULL WHERE category_id=?',[$id]);
                if($table==='users')Database::query('UPDATE rh6_news SET author_id=NULL WHERE author_id=?',[$id]);
                Database::query('DELETE FROM rh6_'.$table.' WHERE id=?',[$id]);$pdo->commit();
            }catch(Throwable $ex){$pdo->rollBack();throw $ex;}
            flash('Kayıt silindi.');redirect('/panel/'.$module);
        }
        if($table==='comments') {
            $status=text_input('status',20,true);if(!in_array($status,['pending','approved','rejected'],true)||!$id)throw new InvalidArgumentException('Geçersiz yorum işlemi.');
            Database::save('comments',compact('status'),$id);flash('Yorum durumu güncellendi.');redirect('/panel/yorumlar');
        }
        if(!in_array($action,['yeni','duzenle'],true))throw new InvalidArgumentException('Geçersiz işlem.');
        try {
            if($table==='news') {
                $headline=text_input('title',255,true);$status=text_input('status',20,true);$kind=text_input('kind',20,true);
                if(!isset($statuses[$status])||!in_array($kind,['article','gallery','video'],true))throw new InvalidArgumentException('Geçersiz yayın durumu veya içerik türü.');
                $categoryId=integer_input('category_id')?:null;$authorId=integer_input('author_id')?:null;
                if($categoryId&&!Database::scalar('SELECT id FROM rh6_categories WHERE id=?',[$categoryId]))throw new InvalidArgumentException('Kategori bulunamadı.');
                if($authorId&&!Database::scalar('SELECT id FROM rh6_users WHERE id=? AND active=1',[$authorId]))throw new InvalidArgumentException('Yazar bulunamadı.');
                $date=date_input('published_at');if($status==='scheduled'&&(!$date||$date<=date('Y-m-d H:i:s')))throw new InvalidArgumentException('Planlı yayın için gelecekte bir tarih seçin.');
                if($status==='published'&&$date&&$date>date('Y-m-d H:i:s'))$status='scheduled';
                if($status==='published'&&!$date)$date=date('Y-m-d H:i:s');
                $gallery=json_decode($record['gallery']??'[]',true)?:[];
                $remove=is_array($_POST['remove_gallery']??null)?array_map('intval',$_POST['remove_gallery']):[];
                $gallery=array_values(array_filter($gallery,fn($key)=>!in_array($key,$remove,true),ARRAY_FILTER_USE_KEY));
                if(isset($_FILES['gallery_images']['name'])&&is_array($_FILES['gallery_images']['name'])) {
                    $uploadCount=count(array_filter($_FILES['gallery_images']['error'],fn($code)=>$code!==UPLOAD_ERR_NO_FILE));
                    if($uploadCount+count($gallery)>20)throw new InvalidArgumentException('Bir galeride en fazla 20 görsel olabilir.');
                    foreach($_FILES['gallery_images']['name'] as $key=>$name){foreach(['name','type','tmp_name','error','size'] as $property)$_FILES['gallery_one'][$property]=$_FILES['gallery_images'][$property][$key];$photo=upload_image('gallery_one');if($photo)$gallery[]=$photo;}
                }
                $libraryId=integer_input('image_existing');$existingImage=$libraryId?Database::row("SELECT path FROM rh6_media WHERE id=? AND kind='image'",[$libraryId]):null;if($libraryId&&!$existingImage)throw new InvalidArgumentException('Kütüphane görseli bulunamadı.');
                $videoLibraryId=integer_input('video_existing');$videoLibrary=$videoLibraryId?Database::row("SELECT path FROM rh6_media WHERE id=? AND kind='video'",[$videoLibraryId]):null;if($videoLibraryId&&!$videoLibrary)throw new InvalidArgumentException('Kütüphane videosu bulunamadı.');
                $data=['title'=>$headline,'slug'=>unique_slug('news',text_input('slug',190)?:$headline,$id?:null),'summary'=>text_input('summary',1000),'body'=>safe_html(text_input('body',200000)),'image'=>upload_image('image_file',$existingImage['path']??$record['image']??null),'category_id'=>$categoryId,'author_id'=>$authorId,'status'=>$status,'kind'=>$kind,'video_url'=>url_input('video_url'),'video_file'=>isset($_POST['remove_video'])?null:upload_video('video_file',$videoLibrary['path']??$record['video_file']??null),'focus_keyword'=>text_input('focus_keyword',150),'gallery'=>json_encode($gallery),'published_at'=>$date,'updated_at'=>date('Y-m-d H:i:s'),'seo_title'=>text_input('seo_title',255),'seo_description'=>text_input('seo_description',500),'allow_comments'=>checked_input('allow_comments'),'is_demo'=>0];
                foreach(['is_breaking','is_headline','is_top','is_featured','is_box'] as $flag)$data[$flag]=checked_input($flag);
                if(!$id)$data['created_at']=date('Y-m-d H:i:s');
            } elseif($table==='users') {
                $name=text_input('name',150,true);$email=text_input('email',190,true);$role=text_input('role',20,true);
                if(!filter_var($email,FILTER_VALIDATE_EMAIL)||!in_array($role,['admin','editor','author'],true))throw new InvalidArgumentException('E-posta veya yetki geçersiz.');
                if(Database::scalar('SELECT COUNT(*) FROM rh6_users WHERE email=? AND id<>?',[$email,$id]))throw new InvalidArgumentException('Bu e-posta başka bir hesapta kullanılıyor.');
                $active=checked_input('active');
                if($id===$currentUser['id']&&($role!=='admin'||!$active))throw new InvalidArgumentException('Kendi yönetici yetkinizi kaldıramazsınız.');
                if($id&&$record['role']==='admin'&&$record['active']&&($role!=='admin'||!$active)&&(int)Database::scalar("SELECT COUNT(*) FROM rh6_users WHERE role='admin' AND active=1")<=1)throw new InvalidArgumentException('En az bir aktif yönetici kalmalı.');
                $data=['name'=>$name,'email'=>$email,'slug'=>unique_slug('users',text_input('slug',190)?:$name,$id?:null),'role'=>$role,'active'=>$active,'public_profile'=>checked_input('public_profile'),'is_demo'=>0,'bio'=>text_input('bio',5000),'image'=>upload_image('image_file',$record['image']??null)];
                $password=password_input('new_password');
                if($password!==''||!$id){if(strlen($password)<12||strlen($password)>72)throw new InvalidArgumentException('Yeni hesap şifresi 12–72 bayt uzunluğunda olmalı.');$data['password']=password_hash($password,PASSWORD_DEFAULT);}
            } elseif($table==='categories') {
                $name=text_input('name',100,true);$data=['name'=>$name,'slug'=>unique_slug('categories',text_input('slug',190)?:$name,$id?:null),'sort_order'=>integer_input('sort_order')];
            } elseif($table==='ads') {
                $placement=text_input('placement',30,true);if(!array_key_exists($placement,ad_slots()))throw new InvalidArgumentException('Geçersiz reklam konumu.');
                $data=['name'=>text_input('name',150,true),'placement'=>$placement,'code'=>text_input('code',100000),'device'=>text_input('device',20)?:'all','priority'=>integer_input('priority'),'starts_at'=>date_input('starts_at'),'ends_at'=>date_input('ends_at'),'target_url'=>url_input('target_url'),'active'=>checked_input('active'),'image'=>upload_image('image_file',$record['image']??null)];if(!$data['image']&&!$data['code'])throw new InvalidArgumentException('Reklam görseli veya reklam kodu girin.');if(!in_array($data['device'],['all','mobile','desktop'],true))throw new InvalidArgumentException('Cihaz seçimi geçersiz.');if($data['starts_at']&&$data['ends_at']&&$data['ends_at']<=$data['starts_at'])throw new InvalidArgumentException('Reklam bitiş tarihi başlangıçtan sonra olmalı.');
            } else {
                $pageTitle=text_input('title',150,true);$data=['title'=>$pageTitle,'slug'=>unique_slug('pages',text_input('slug',190)?:$pageTitle,$id?:null),'body'=>safe_html(text_input('body',200000)),'active'=>checked_input('active')];
            }
            Database::save($table,$data,$id?:null);flash('Kayıt kaydedildi.');redirect('/panel/'.$module);
        }catch(InvalidArgumentException $ex){$error=$ex->getMessage();$record=array_merge($record,$_POST);foreach(['is_breaking','is_headline','is_top','is_featured','is_box','allow_comments','active','public_profile'] as $flag)$record[$flag]=checked_input($flag);http_response_code(422);}
    }
    if(in_array($action,['yeni','duzenle'],true)&&$table!=='comments')$screen='form';
    elseif(!in_array($action,['list','sil'],true)){http_response_code(404);view('error',['message'=>'Panel sayfası bulunamadı.']);return;}
    else {
        $filter='';$params=[];
        if($table==='news'&&isset($_GET['q'])&&is_string($_GET['q'])&&$_GET['q']!==''){$filter=' WHERE title LIKE ?';$params=['%'.substr($_GET['q'],0,100).'%'];}
        if($table==='news'&&in_array($_GET['kind']??'', ['gallery','video'],true)){$filter.=($filter?' AND':' WHERE').' kind=?';$params[]=$_GET['kind'];}
        if($table==='news'&&isset($_GET['status'])&&isset($statuses[$_GET['status']])){$filter.=($filter?' AND':' WHERE').' status=?';$params[]=$_GET['status'];}
        $recordPage=max(1,min(100000,(int)(is_scalar($_GET['page']??null)?$_GET['page']:1)));$recordTotal=(int)Database::scalar('SELECT COUNT(*) FROM rh6_'.$table.$filter,$params);$recordPages=max(1,(int)ceil($recordTotal/25));$recordPage=min($recordPage,$recordPages);$rows=Database::rows('SELECT * FROM rh6_'.$table.$filter.' ORDER BY id DESC LIMIT 25 OFFSET '.(($recordPage-1)*25),$params);
    }
} elseif($module!=='dashboard') {http_response_code(404);view('error',['message'=>'Panel sayfası bulunamadı.']);return;}
if($module==='dashboard')$dashboard=dashboard_data();
view('admin/header',compact('title','module','currentUser','error'));
view('admin/'.$screen,get_defined_vars());
view('admin/footer');
