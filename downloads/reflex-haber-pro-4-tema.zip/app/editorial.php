<?php
declare(strict_types=1);
function editorial_source_presets():array{return [
    'trt'=>['name'=>'TRT Haber','url'=>'https://www.trthaber.com/sondakika.rss'],
    'ntv'=>['name'=>'NTV','url'=>'https://www.ntv.com.tr/son-dakika.rss'],
    'cnn'=>['name'=>'CNN Türk','url'=>'https://www.cnnturk.com/feed/rss/all/news'],
    'sozcu'=>['name'=>'Sözcü','url'=>'https://www.sozcu.com.tr/feeds-rss-category-gundem']
];}
function editorial_schema(callable $add):void{
    $add('news',['pdf_file'=>'VARCHAR(1000)','embed_code'=>'TEXT','seo_autofill'=>'INTEGER NOT NULL DEFAULT 1']);
    $add('news_sources',['source_kind'=>"VARCHAR(20) NOT NULL DEFAULT 'auto'",'fetch_full'=>'INTEGER NOT NULL DEFAULT 0']);
    if(!Database::scalar("SELECT id FROM rh6_settings WHERE name='editorial_v31_initialized'")){
        if(setting('slider_interval','5')==='5')put_setting('slider_interval','3');
        put_setting('breaking_animation','1');put_setting('ticker_pulse','1');
        $category=Database::scalar("SELECT id FROM rh6_categories WHERE slug='gundem'")?:null;
        foreach(editorial_source_presets() as $preset)if(!Database::scalar('SELECT id FROM rh6_news_sources WHERE feed_url=?',[$preset['url']]))Database::save('news_sources',['name'=>$preset['name'],'feed_url'=>$preset['url'],'category_id'=>$category,'source_kind'=>'auto','active'=>1,'agenda_enabled'=>1,'interval_minutes'=>30,'max_items'=>5,'import_status'=>'draft']);
        put_setting('editorial_v31_initialized','1');
    }
}
function editorial_plain_text(string $html):string{
    $html=preg_replace('~</(?:p|h[1-6]|div|li|blockquote)>|<br\s*/?>~i',' ',$html)??$html;
    return trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($html),ENT_QUOTES|ENT_HTML5,'UTF-8'))??'');
}
function seo_autofill(array $news):array{
    $plain=editorial_plain_text((string)($news['body']??''));
    $cut=static function(string $value,int $max):string{$value=trim($value);if(mb_strlen($value)<=$max)return $value;$short=mb_substr($value,0,$max);$space=mb_strrpos($short,' ');return $space!==false&&$space>$max*.6?mb_substr($short,0,$space):$short;};
    if(trim((string)($news['summary']??''))==='')$news['summary']=$cut($plain,300);
    if(trim((string)($news['seo_title']??''))==='')$news['seo_title']=$cut((string)($news['title']??''),65);
    if(trim((string)($news['seo_description']??''))==='')$news['seo_description']=$cut(trim((string)($news['summary']??''))?:$plain,160);
    if(trim((string)($news['slug']??''))==='')$news['slug']=slugify((string)($news['title']??''));
    return $news;
}
function upload_pdf(string $field,?string $current=null):?string{
    $file=$_FILES[$field]??null;if(!$file||$file['error']===UPLOAD_ERR_NO_FILE)return $current;
    if($file['error']!==UPLOAD_ERR_OK||$file['size']>20*1024*1024)throw new InvalidArgumentException('PDF yüklenemedi. En fazla 20 MB ve sunucu yükleme sınırı içinde bir dosya seçin.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);$head=file_get_contents($file['tmp_name'],false,null,0,5);
    if($mime!=='application/pdf'||$head!=='%PDF-')throw new InvalidArgumentException('Geçerli bir PDF belgesi seçin.');
    $name=bin2hex(random_bytes(16)).'.pdf';if(!move_uploaded_file($file['tmp_name'],ROOT.'/uploads/'.$name))throw new RuntimeException('PDF kaydedilemedi. uploads izinlerini kontrol edin.');
    Database::save('media',['path'=>'uploads/'.$name,'name'=>mb_substr(basename((string)$file['name']),0,255),'kind'=>'document','created_at'=>date('Y-m-d H:i:s')]);return 'uploads/'.$name;
}
function validated_embed(string $code):string{
    if(trim($code)==='')return '';
    if(mb_strlen($code)>5000||stripos($code,'<!ENTITY')!==false)throw new InvalidArgumentException('Tek bir YouTube, Vimeo veya Dailymotion iframe kodu girin.');
    $old=libxml_use_internal_errors(true);$dom=new DOMDocument();$dom->loadHTML('<?xml encoding="utf-8" ?>'.$code,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($old);
    $frames=$dom->getElementsByTagName('iframe');if($frames->length!==1)throw new InvalidArgumentException('Tek bir YouTube, Vimeo veya Dailymotion iframe kodu girin.');
    $frame=$frames->item(0);$src=$frame->getAttribute('src');$p=parse_url($src);$host=strtolower($p['host']??'');$path=$p['path']??'';$url='';
    if(($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['port']))throw new InvalidArgumentException('Embed adresi HTTPS olmalı.');
    if(in_array($host,['youtube.com','www.youtube.com','youtube-nocookie.com','www.youtube-nocookie.com'],true)&&preg_match('~^/embed/([A-Za-z0-9_-]{11})/?$~',$path,$m))$url='https://www.youtube-nocookie.com/embed/'.$m[1];
    elseif($host==='player.vimeo.com'&&preg_match('~^/video/([0-9]{1,12})/?$~',$path,$m)){$url='https://player.vimeo.com/video/'.$m[1];parse_str($p['query']??'',$query);if(is_string($query['h']??null)&&preg_match('/^[a-f0-9]{6,32}$/',$query['h']))$url.='?h='.$query['h'];}
    elseif(in_array($host,['www.dailymotion.com','dailymotion.com'],true)&&preg_match('~^/embed/video/([A-Za-z0-9]{1,20})/?$~',$path,$m))$url='https://www.dailymotion.com/embed/video/'.$m[1];
    if(!$url)throw new InvalidArgumentException('YouTube, Vimeo veya Dailymotion video iframe kodu desteklenir.');
    $title=mb_substr($frame->getAttribute('title')?:'Habere eklenen video',0,150);
    return '<iframe src="'.e($url).'" title="'.e($title).'" loading="lazy" sandbox="allow-scripts allow-same-origin allow-presentation" allow="fullscreen; encrypted-media; picture-in-picture" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>';
}
function editorial_demo_opinions():void{
    if(setting('demo_notice')!=='1')return;$authors=Database::rows('SELECT id FROM rh6_users WHERE is_demo=1 AND public_profile=1 ORDER BY id LIMIT 5');
    $titles=['Bu yaz kültür ve sanatın izinde','Kentlerin geleceğini birlikte düşünmek','Günlük yaşamda küçük ama değerli alışkanlıklar','Sporda yeni sezonun heyecanı','Dijital dünyada doğru bilgiye ulaşmak'];
    foreach($authors as $i=>$author){if(Database::scalar("SELECT id FROM rh6_news WHERE author_id=? AND kind='opinion'",[$author['id']]))continue;$now=date('Y-m-d H:i:s');Database::save('news',['title'=>$titles[$i],'slug'=>unique_slug('news',$titles[$i]),'summary'=>'Örnek köşe yazısı · Yazar vitrinini tanımak için hazırlanmıştır.','body'=>'<p><strong>Örnek köşe yazısı.</strong> Yazarın görüşleri ve değerlendirmeleri burada yer alır. Kendi makalelerinizi panelde Makaleler ve Köşe Yazıları bölümünden ekleyebilirsiniz.</p>','author_id'=>$author['id'],'kind'=>'opinion','status'=>'published','gallery'=>'[]','published_at'=>$now,'created_at'=>$now,'updated_at'=>$now,'is_demo'=>1]);}
}
