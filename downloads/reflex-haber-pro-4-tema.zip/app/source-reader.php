<?php
declare(strict_types=1);
/* All network requests use the existing public-IP, DNS-pinned, bounded fetcher. */
function source_absolute_url(string $reference,string $base):string{
    if(trim($reference)==='')return '';
    $reference=trim(html_entity_decode($reference,ENT_QUOTES|ENT_HTML5,'UTF-8'));$p=parse_url($base);
    if(!$p||!isset($p['host']))return '';
    if(str_starts_with($reference,'//'))$reference=$p['scheme'].':'.$reference;
    elseif(str_starts_with($reference,'/'))$reference=$p['scheme'].'://'.$p['host'].(isset($p['port'])?':'.$p['port']:'').$reference;
    elseif(!preg_match('~^[a-z][a-z0-9+.-]*:~i',$reference))$reference=$p['scheme'].'://'.$p['host'].(isset($p['port'])?':'.$p['port']:'').rtrim(dirname($p['path']??'/'),'/').'/'.$reference;
    $candidate=parse_url($reference);if(!filter_var($reference,FILTER_VALIDATE_URL)||!in_array($candidate['scheme']??'',['http','https'],true)||isset($candidate['user'])||isset($candidate['pass']))return '';
    return explode('#',$reference,2)[0];
}
function source_html_document(string $html):DOMDocument{
    if(strlen($html)>2*1024*1024||stripos($html,'<!ENTITY')!==false)throw new InvalidArgumentException('Kaynak belge boyutu veya biçimi desteklenmiyor.');
    $old=libxml_use_internal_errors(true);$dom=new DOMDocument();$dom->loadHTML('<?xml encoding="utf-8" ?>'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($old);return $dom;
}
function source_page_items(string $html,string $url,int $limit=20):array{
    $dom=source_html_document($html);$xp=new DOMXPath($dom);$items=[];$seen=[];$limit=max(1,min(20,$limit));
    $add=function(array $item)use(&$items,&$seen,$limit,$url):void{
        $link=source_absolute_url((string)($item['url']??''),$url);$title=mb_substr(trim(strip_tags((string)($item['title']??''))),0,255);
        if(!$link||mb_strlen($title)<12||isset($seen[$link])||count($items)>=$limit)return;$seen[$link]=true;
        $body=safe_html(mb_substr((string)($item['body']??''),0,100000));$summary=mb_substr(trim(strip_tags((string)($item['summary']??$body))),0,700);
        $items[]=['title'=>$title,'url'=>$link,'guid'=>$link,'summary'=>$summary,'body'=>$body?:($summary?'<p>'.e($summary).'</p>':''),'image'=>source_absolute_url((string)($item['image']??''),$url)];
    };
    $walk=function(mixed $node,int $depth=0)use(&$walk,$add):void{
        if(!is_array($node)||$depth>12)return;$types=(array)($node['@type']??[]);
        if(array_intersect($types,['NewsArticle','Article','ReportageNewsArticle','BlogPosting'])){
            $image=$node['image']??'';if(is_array($image))$image=$image['url']??$image[0]??'';if(is_array($image))$image=$image['url']??'';
            $link=$node['url']??$node['mainEntityOfPage']??'';if(is_array($link))$link=$link['@id']??$link['url']??'';
            $add(['title'=>$node['headline']??$node['name']??'','url'=>$link,'summary'=>$node['description']??'','body'=>isset($node['articleBody'])?'<p>'.nl2br(e((string)$node['articleBody'])).'</p>':'','image'=>$image]);
        }
        foreach($node as $value)if(is_array($value))$walk($value,$depth+1);
    };
    foreach($xp->query('//script[@type="application/ld+json"]') as $script){$json=json_decode($script->textContent,true,24);if(is_array($json))$walk($json);}
    $meta=function(string $name)use($xp):string{foreach($xp->query('//meta') as $m)if($m->getAttribute('property')===$name||$m->getAttribute('name')===$name)return $m->getAttribute('content');return '';};
    if(!$items&&($meta('og:type')==='article'||$xp->query('//article//h1')->length)){
        $title=$meta('og:title')?:($xp->query('//h1')->item(0)?->textContent??'');$body='';
        foreach($xp->query('//article//p | //*[@itemprop="articleBody"]//p') as $paragraph){if(mb_strlen(trim($paragraph->textContent))>35)$body.='<p>'.e(trim($paragraph->textContent)).'</p>';if(strlen($body)>100000)break;}
        $add(['title'=>$title,'url'=>$meta('og:url')?:$url,'body'=>$body,'summary'=>$meta('og:description')?:$meta('description'),'image'=>$meta('og:image')]);
    }
    if(!$items){
        foreach($xp->query('//article//a[@href] | //h2//a[@href] | //h3//a[@href] | //a[@href][.//h2 or .//h3]') as $a){
            $link=source_absolute_url($a->getAttribute('href'),$url);if(strtolower(parse_url($link,PHP_URL_HOST)??'')!==strtolower(parse_url($url,PHP_URL_HOST)??''))continue;
            $title=$a->getAttribute('title')?:$a->textContent;$heading=(new DOMXPath($dom))->query('.//h2 | .//h3',$a)->item(0);if($heading)$title=$heading->textContent;
            $img=$a->getElementsByTagName('img')->item(0);$add(['title'=>$title,'url'=>$link,'image'=>$img?->getAttribute('src')?:$img?->getAttribute('data-src')?:'']);
        }
    }
    if(!$items){
        foreach($xp->query('//a[@href]') as $a){
            $link=source_absolute_url($a->getAttribute('href'),$url);$path=parse_url($link,PHP_URL_PATH)??'';
            if(strtolower(parse_url($link,PHP_URL_HOST)??'')!==strtolower(parse_url($url,PHP_URL_HOST)??'')||!preg_match('~(?:[-/]p?\d{4,}|/\d{4}/\d{1,2}/|\.html)(?:[/?]|$)~i',$path))continue;
            $img=$a->getElementsByTagName('img')->item(0);$heading=$xp->query('.//h2 | .//h3 | .//strong | .//span[contains(@class,"fw-bold") or contains(@class,"title")]',$a)->item(0);
            $title=$heading?->textContent?:($img?->getAttribute('alt')?:$a->getAttribute('title')?:$a->textContent);
            $add(['title'=>$title,'url'=>$link,'image'=>$img?->getAttribute('src')?:$img?->getAttribute('data-src')?:'']);
        }
    }
    if(!$items)throw new InvalidArgumentException('Bu sayfada haber başlığı bulunamadı. Kaynağın RSS adresini veya haber/kategori sayfasını girin. JavaScript ile yüklenen veya giriş isteyen sayfalar desteklenmez.');return $items;
}
function fetch_source_items(array $source,?callable $fetcher=null,?int $limit=null):array{
    $fetcher??='fetch_public_feed';$url=$source['feed_url'];$document=$fetcher($url);$limit??=(int)($source['max_items']??5);$kind=$source['source_kind']??'rss';
    try{$items=parse_feed($document,$limit);}catch(InvalidArgumentException $exception){
        if($kind==='rss')throw $exception;
        $items=null;if($kind==='auto'){
            $dom=source_html_document($document);$xp=new DOMXPath($dom);$attempts=0;
            foreach($xp->query('//link[@rel="alternate"]') as $link){if(!in_array($link->getAttribute('type'),['application/rss+xml','application/atom+xml'],true))continue;$feed=source_absolute_url($link->getAttribute('href'),$url);if(!$feed||$feed===$url)continue;
                try{$items=parse_feed($fetcher($feed),$limit);if($items)break;}catch(Throwable $ex){}if(++$attempts>=2)break;
            }
        }
        if(!$items)$items=source_page_items($document,$url,$limit);
    }
    if(!empty($source['fetch_full']))foreach(array_slice(array_keys($items),0,5) as $i){try{$full=source_page_items($fetcher($items[$i]['url']),$items[$i]['url'],1)[0];if(mb_strlen(strip_tags($full['body']))>mb_strlen(strip_tags($items[$i]['body']))){$items[$i]['body']=$full['body'];if($full['summary'])$items[$i]['summary']=$full['summary'];if($full['image'])$items[$i]['image']=$full['image'];}}catch(Throwable $ex){/* Keep successfully fetched feed facts if the article is unavailable. */}}
    return $items;
}
