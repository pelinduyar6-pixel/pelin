<?php
declare(strict_types=1);
require_once __DIR__ . '/core.php';
require_once __DIR__.'/pro.php';
date_default_timezone_set('Europe/Istanbul');
if (!is_file(ROOT . '/storage/site.php')) { header('Location: ' . base_path() . '/kurulum.php'); exit; }
$config = require ROOT . '/storage/site.php';
if (!is_dir(ROOT . '/storage/sessions')) @mkdir(ROOT . '/storage/sessions', 0775, true);
session_save_path(ROOT . '/storage/sessions');
session_name('reflex6_session');
session_set_cookie_params(['lifetime'=>0,'path'=>base_path() . '/','secure'=>strtolower((string)parse_url($config['site_url'],PHP_URL_SCHEME))==='https','httponly'=>true,'samesite'=>'Lax']);
ini_set('session.use_strict_mode','1');
ini_set('display_errors','0');
session_start();
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');
header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
if(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')header('Strict-Transport-Security: max-age=31536000');
if(is_post()&&empty($_POST)&&isset($_SERVER['CONTENT_LENGTH'])&&(int)$_SERVER['CONTENT_LENGTH']>0){$limit=trim(ini_get('post_max_size'));$bytes=(float)$limit;$suffix=strtolower(substr($limit,-1));$bytes*=match($suffix){'g'=>1073741824,'m'=>1048576,'k'=>1024,default=>1};if($bytes>0&&(int)$_SERVER['CONTENT_LENGTH']>$bytes){http_response_code(413);echo 'Dosya sunucunun yükleme sınırını aşıyor. Hosting post_max_size ve upload_max_filesize ayarlarını kontrol edin.';exit;}}
try {
    Database::connection();
    migrate_pro_schema();
    Database::query("UPDATE rh6_news SET status = 'published' WHERE status = 'scheduled' AND published_at IS NOT NULL AND published_at <= ?", [date('Y-m-d H:i:s')]);
} catch (Throwable $exception) {
    log_failure($exception); http_response_code(503);
    echo '<!doctype html><html lang="tr"><meta charset="utf-8"><title>Reflex Haber</title><body><h1>Siteye şu anda ulaşılamıyor</h1><p>Veritabanı bağlantısı doğrulanamadı. Hosting veritabanı ayarlarını kontrol edin.</p></body></html>'; exit;
}
