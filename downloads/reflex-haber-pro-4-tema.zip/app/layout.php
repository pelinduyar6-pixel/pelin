<?php
declare(strict_types=1);
function category_layouts():array{return ['auto'=>'Temaya göre otomatik','editorial'=>'Büyük haber + dört kart','showcase'=>'İki büyük + dört küçük','mosaic'=>'Asimetrik vitrin','compact'=>'Kompakt haber akışı'];}
function homepage_categories(array $categories):array{
    $config=json_decode(setting('home_categories','{}'),true)?:[];
    foreach($categories as &$category){$entry=$config[(string)$category['id']]??[];$category['home_enabled']=$entry['enabled']??1;$category['home_position']=$entry['position']??($category['sort_order']?:$category['id']);$category['home_layout']=$entry['layout']??'auto';}unset($category);
    usort($categories,fn($a,$b)=>($a['home_position']<=>$b['home_position'])?:($a['id']<=>$b['id']));return $categories;
}
function save_home_categories(array $categories):void{
    if(!isset($_POST['categories_present']))return; // Older clients keep their category selections.
    $config=[];foreach($categories as $category){$id=(int)$category['id'];$entry=$_POST['home_category'][$id]??[];if(!is_array($entry))throw new InvalidArgumentException('Kategori ayarı geçersiz.');$position=$entry['position']??50;$layout=$entry['layout']??'auto';if(!is_scalar($position)||filter_var($position,FILTER_VALIDATE_INT)===false||(int)$position<1||(int)$position>99||!is_string($layout)||!isset(category_layouts()[$layout]))throw new InvalidArgumentException('Kategori sırası 1–99 olmalı; geçerli görünüm seçin.');$config[$id]=['enabled'=>isset($entry['enabled'])?1:0,'position'=>(int)$position,'layout'=>$layout];}put_setting('home_categories',json_encode($config));
}
function layout_schema():void{
    foreach(['home_categories'=>'{}','market_refresh_minutes'=>'10','sports_refresh_minutes'=>'15','sports_mode'=>'ntv','market_attempt'=>'','sports_attempt'=>'','market_status'=>'','sports_status'=>'','market_btc_unit'=>'TRY','market_field_times'=>'{}','footer_highlights'=>'1','app_google_play'=>'','app_app_store'=>'','app_gallery'=>''] as $key=>$value)if(!Database::scalar('SELECT id FROM rh6_settings WHERE name=?',[$key]))put_setting($key,$value);
    if(!setting('layout_v32_initialized')){
        // Enable complete automatic feeds only if no manual values were entered.
        $manual=false;foreach(array_keys(market_fields()) as $key)if(setting($key)!=='')$manual=true;
        if(setting('market_mode','manual')==='manual'&&!$manual)put_setting('market_mode','public');
        put_setting('layout_v32_initialized','1');
    }
}
