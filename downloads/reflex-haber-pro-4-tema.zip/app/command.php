<?php
declare(strict_types=1);
function command_defaults():array{return ['ticker_enabled'=>'1','ticker_speed'=>'90','ticker_color'=>'#73b914','ticker_pulse'=>'1','header_city'=>'İstanbul','weather_mode'=>'manual','weather_icon'=>'sun','weather_temperature'=>'21','weather_updated'=>'','twitter'=>'','google_ga4'=>'','google_verification'=>'','google_adsense'=>'','google_custom_head'=>'','bot_enabled'=>'1','bot_ai_enabled'=>'0','ai_target_words'=>'700','agenda_auto'=>'1','agenda_last_scan'=>'','agenda_status'=>'Henüz taranmadı','contact_enabled'=>'1','home_authors_middle'=>'1','sports_enabled'=>'1','sports_league'=>'Trendyol Süper Lig','sports_season'=>'2026–2027','sports_standings'=>'[]','sports_updated'=>'','sports_api_season'=>'2026','market_mode'=>'manual','market_updated'=>'','market_bist'=>'','market_btc'=>'','market_feed_url'=>'','market_mapping'=>'{}','market_usd_change'=>'','market_eur_change'=>'','market_gold_change'=>'','market_bist_change'=>'','market_btc_change'=>'','modules_enabled'=>json_encode(array_fill_keys(array_keys(module_definitions()),1))];}
function module_definitions():array{return ['anket'=>['Anket','Aktif sorular ve okuyucu oyları','poll'],'fal'=>['Fal ve Burçlar','Editörün hazırladığı günlük burç yorumları','content'],'biyografi'=>['Biyografi','Kişiler ve yaşam öyküleri','content'],'resmi-ilanlar'=>['Resmi İlanlar','Duyurular ve resmi ilan arşivi','content'],'roportaj'=>['Röportaj','Görüşmeler ve özel dosyalar','content'],'seri-ilan'=>['Seri İlan','Kategorili ilanlar ve iletişim bilgileri','content'],'vefat'=>['Vefat','Vefat ve taziye duyuruları','content'],'e-dergi'=>['E-Dergi','PDF ve çevrimiçi dergi arşivi','content'],'firma-rehberi'=>['Firma Rehberi','İşletmeler, adresler ve iletişim','content']];}
function command_schema(PDO $pdo,string $driver):void{
    $add=function(string $table,array $columns)use($driver,$pdo){$existing=$driver==='sqlite'?array_column(Database::rows('PRAGMA table_info(rh6_'.$table.')'),'name'):array_column(Database::rows('SHOW COLUMNS FROM rh6_'.$table),'Field');foreach($columns as $name=>$definition)if(!in_array($name,$existing,true))$pdo->exec('ALTER TABLE rh6_'.$table.' ADD COLUMN '.$name.' '.$definition);};
    $add('news',['editor_id'=>'INTEGER']);$add('news_sources',['agenda_enabled'=>'INTEGER NOT NULL DEFAULT 1','ai_seo'=>'INTEGER NOT NULL DEFAULT 0']);
    $id=$driver==='sqlite'?'INTEGER PRIMARY KEY AUTOINCREMENT':'INT UNSIGNED AUTO_INCREMENT PRIMARY KEY';$tail=$driver==='sqlite'?'':' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $tables=[
      'contacts'=>"id $id,name VARCHAR(100) NOT NULL,email VARCHAR(190) NOT NULL,subject VARCHAR(150) NOT NULL,message TEXT NOT NULL,status VARCHAR(20) NOT NULL DEFAULT 'new',note TEXT,created_at VARCHAR(19) NOT NULL",
      'module_items'=>"id $id,module VARCHAR(30) NOT NULL,title VARCHAR(255) NOT NULL,slug VARCHAR(190) NOT NULL UNIQUE,summary TEXT,body TEXT,image VARCHAR(1000),data TEXT,status VARCHAR(20) NOT NULL DEFAULT 'draft',created_at VARCHAR(19) NOT NULL,updated_at VARCHAR(19) NOT NULL,ends_at VARCHAR(19)",
      'poll_votes'=>"id $id,item_id INTEGER NOT NULL,visitor_hash VARCHAR(64) NOT NULL,choice INTEGER NOT NULL,created_at VARCHAR(19) NOT NULL,UNIQUE(item_id,visitor_hash)",
      'members'=>"id $id,name VARCHAR(150) NOT NULL,email VARCHAR(190) NOT NULL UNIQUE,phone VARCHAR(40),active INTEGER NOT NULL DEFAULT 1,note TEXT,created_at VARCHAR(19) NOT NULL",
      'agencies'=>"id $id,provider VARCHAR(20) NOT NULL,name VARCHAR(150) NOT NULL,endpoint VARCHAR(1000) NOT NULL,format VARCHAR(10) NOT NULL DEFAULT 'rss',auth VARCHAR(10) NOT NULL DEFAULT 'none',items_path VARCHAR(150),mapping TEXT,category_id INTEGER,author_id INTEGER,interval_minutes INTEGER NOT NULL DEFAULT 30,next_run_at VARCHAR(19),last_run_at VARCHAR(19),active INTEGER NOT NULL DEFAULT 0,import_status VARCHAR(20) NOT NULL DEFAULT 'draft',max_items INTEGER NOT NULL DEFAULT 5,ai_seo INTEGER NOT NULL DEFAULT 0,last_message VARCHAR(500)",
      'agency_items'=>"id $id,agency_id INTEGER NOT NULL,guid_hash VARCHAR(64) NOT NULL,news_id INTEGER NOT NULL,UNIQUE(agency_id,guid_hash)",
      'agency_runs'=>"id $id,agency_id INTEGER NOT NULL,created_at VARCHAR(19) NOT NULL,imported INTEGER NOT NULL DEFAULT 0,status VARCHAR(20) NOT NULL,message VARCHAR(500)",
      'agenda_items'=>"id $id,topic_hash VARCHAR(64) NOT NULL UNIQUE,title VARCHAR(255) NOT NULL,summary TEXT,body TEXT,sources TEXT NOT NULL,source_count INTEGER NOT NULL DEFAULT 1,first_seen VARCHAR(19) NOT NULL,last_seen VARCHAR(19) NOT NULL,news_id INTEGER",
      'agenda_health'=>"id $id,source_id INTEGER NOT NULL UNIQUE,name VARCHAR(150) NOT NULL,status VARCHAR(20) NOT NULL,total INTEGER NOT NULL DEFAULT 0,message VARCHAR(500),checked_at VARCHAR(19) NOT NULL"
    ];foreach($tables as $name=>$columns)$pdo->exec('CREATE TABLE IF NOT EXISTS rh6_'.$name.' ('.$columns.')'.$tail);
    if(!Database::scalar("SELECT id FROM rh6_settings WHERE name='market_strip_initialized'")){put_setting('market_enabled','1');put_setting('market_strip_initialized','1');}
    foreach(command_defaults() as $name=>$value)if(!Database::scalar('SELECT id FROM rh6_settings WHERE name=?',[$name]))Database::save('settings',compact('name','value'));
}
function save_private_integrations(array $changes):void{
    $lock=@fopen(ROOT.'/storage/integrations.lock','c');if(!$lock||!flock($lock,LOCK_EX))throw new RuntimeException('Bağlantı ayarları kilitlenemedi.');$temporary=null;
    try{$config=array_replace_recursive(integration_config(),$changes);$temporary=ROOT.'/storage/.integration-'.bin2hex(random_bytes(8)).'.php';$contents='<?php return '.var_export($config,true).';';if(@file_put_contents($temporary,$contents,LOCK_EX)!==strlen($contents)||!@chmod($temporary,0600)||!@rename($temporary,ROOT.'/storage/integrations.php'))throw new RuntimeException('Bağlantı ayarları kaydedilemedi. storage izinlerini kontrol edin.');}
    finally{if($temporary&&is_file($temporary))@unlink($temporary);flock($lock,LOCK_UN);fclose($lock);}
}
function module_enabled(string $module):bool{return !empty((json_decode(setting('modules_enabled'),true)?:[])[$module]);}
function turkey_cities():array{return ['Adana','Adıyaman','Afyonkarahisar','Ağrı','Amasya','Ankara','Antalya','Artvin','Aydın','Balıkesir','Bilecik','Bingöl','Bitlis','Bolu','Burdur','Bursa','Çanakkale','Çankırı','Çorum','Denizli','Diyarbakır','Edirne','Elazığ','Erzincan','Erzurum','Eskişehir','Gaziantep','Giresun','Gümüşhane','Hakkâri','Hatay','Isparta','Mersin','İstanbul','İzmir','Kars','Kastamonu','Kayseri','Kırklareli','Kırşehir','Kocaeli','Konya','Kütahya','Malatya','Manisa','Kahramanmaraş','Mardin','Muğla','Muş','Nevşehir','Niğde','Ordu','Rize','Sakarya','Samsun','Siirt','Sinop','Sivas','Tekirdağ','Tokat','Trabzon','Tunceli','Şanlıurfa','Uşak','Van','Yozgat','Zonguldak','Aksaray','Bayburt','Karaman','Kırıkkale','Batman','Şırnak','Bartın','Ardahan','Iğdır','Yalova','Karabük','Kilis','Osmaniye','Düzce'];}
function editor_performance(int $days):array{
    $days=in_array($days,[7,30,90,365],true)?$days:30;$since=date('Y-m-d H:i:s',strtotime('-'.($days-1).' days 00:00:00'));$until=date('Y-m-d H:i:s');
    return Database::rows("SELECT u.id,u.name,u.role,COUNT(n.id) AS published,COALESCE(SUM(n.views),0) AS views,MAX(n.published_at) AS last_publish FROM rh6_users u LEFT JOIN rh6_news n ON COALESCE(n.editor_id,n.author_id)=u.id AND n.status='published' AND n.published_at>=? AND n.published_at<=? WHERE u.role IN ('admin','editor') GROUP BY u.id,u.name,u.role ORDER BY published DESC,views DESC",[$since,$until]);
}
function google_head():void{
    $ga=setting('google_ga4');$verify=setting('google_verification');$ads=setting('google_adsense');
    if($verify)echo '<meta name="google-site-verification" content="'.e($verify).'">';
    if(preg_match('/^G-[A-Z0-9]{5,20}$/',$ga))echo '<script async src="https://www.googletagmanager.com/gtag/js?id='.e($ga).'"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config",'.json_encode($ga).');</script>';
    if(preg_match('/^ca-pub-[0-9]{16}$/',$ads))echo '<script async crossorigin="anonymous" src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='.e($ads).'"></script>';
    echo setting('google_custom_head');
}
function public_rate_limit(string $group,int $limit,int $window):void{
    $hash=hash('sha256',$group.'|'.($_SERVER['REMOTE_ADDR']??'unknown'));$handle=@fopen(ROOT.'/storage/rate-'.$hash.'.json','c+');if(!$handle||!flock($handle,LOCK_EX))throw new RuntimeException('İşlem şu anda tamamlanamıyor.');
    try{$state=json_decode(stream_get_contents($handle),true)?:['start'=>time(),'count'=>0];if(time()-(int)$state['start']>$window)$state=['start'=>time(),'count'=>0];if((int)$state['count']>=$limit){http_response_code(429);throw new InvalidArgumentException('Çok sayıda gönderim yapıldı. Biraz sonra tekrar deneyin.');}$state['count']++;ftruncate($handle,0);rewind($handle);fwrite($handle,json_encode($state));}finally{flock($handle,LOCK_UN);fclose($handle);}
}

function market_fields():array{return ['market_usd'=>'Dolar','market_eur'=>'Euro','market_gold'=>'Gram Altın','market_bist'=>'BIST 100','market_btc'=>'Bitcoin / TRY'];}

function turkish_upper(string $text):string{return mb_strtoupper(str_replace('i','İ',$text),'UTF-8');}
