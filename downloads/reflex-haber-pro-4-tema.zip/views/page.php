<article class="article static-page"><h1><?=e($page['title'])?></h1><div class="article-body"><?=safe_html($page['body']??'')?></div></article>
