<?php
declare(strict_types=1);
require __DIR__.'/app/core.php';
require __DIR__.'/app/pro.php';
require __DIR__.'/app/install.php';
require __DIR__.'/app/installer-support.php';
date_default_timezone_set('Europe/Istanbul');
ini_set('display_errors','0');
ini_set('session.use_strict_mode','1');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Cache-Control: no-store');
if (is_file(ROOT.'/storage/site.php')) { header('Location: '.url('/panel/giris'),true,303); exit; }
@mkdir(ROOT.'/storage/sessions',0750,true);
session_save_path(ROOT.'/storage/sessions');
session_name('reflex6_install');
session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Lax','cookie_path'=>base_path().'/','cookie_secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off']);
$checks=['PHP 8.1 veya üzeri'=>PHP_VERSION_ID>=80100,'PDO veritabanı sürücüsü'=>class_exists('PDO')&&(extension_loaded('pdo_mysql')||extension_loaded('pdo_sqlite')),'DOM, Fileinfo, Mbstring, cURL ve OpenSSL'=>extension_loaded('dom')&&extension_loaded('fileinfo')&&extension_loaded('mbstring')&&extension_loaded('curl')&&extension_loaded('openssl'),'storage klasörü yazılabilir'=>is_writable(ROOT.'/storage'),'uploads klasörü yazılabilir'=>is_writable(ROOT.'/uploads'),'Tasarım dosyaları mevcut'=>is_file(ROOT.'/assets/v6/site.css')&&is_file(ROOT.'/assets/v6/admin.css')];
$error=''; $notice=''; $diagnostic=[]; $done=false; $existing=false; $stage='validation';
if (is_post()) {
    $lock=null; $temporary=null; $published=false; $pdo=null;
    try {
        verify_csrf();
        if (in_array(false,$checks,true)) throw new InvalidArgumentException('Önce aşağıdaki sunucu kontrollerini tamamlayın.');
        $lock=fopen(ROOT.'/storage/install.lock','c');
        if (!$lock||!flock($lock,LOCK_EX|LOCK_NB)) throw new InvalidArgumentException('Kurulum devam ediyor. Biraz sonra tekrar deneyin.');
        if (is_file(ROOT.'/storage/site.php')) throw new InvalidArgumentException('Bu site zaten kurulmuş.');
        $driver=text_input('driver',10,true);
        if (!in_array($driver,['mysql','sqlite'],true)) throw new InvalidArgumentException('Geçerli veritabanı türünü seçin.');
        if (!extension_loaded('pdo_'.$driver)) throw new InvalidArgumentException('Seçtiğiniz veritabanı türü için pdo_'.$driver.' PHP uzantısı etkin değil. Hosting PHP ayarlarından etkinleştirin.');
        $dbPassword=$_POST['db_password']??'';
        if (!is_string($dbPassword)) throw new InvalidArgumentException('Geçerli bir veritabanı şifresi girin.');
        $db=$driver==='sqlite'?['driver'=>'sqlite','path'=>ROOT.'/storage/site.sqlite']:['driver'=>'mysql','host'=>text_input('db_host',150,true),'port'=>integer_input('db_port',3306),'database'=>text_input('db_name',100,true),'username'=>text_input('db_user',100,true),'password'=>$dbPassword];
        if ($driver==='mysql' && (!preg_match('/^[a-zA-Z0-9_.:-]+$/',$db['host']) || !preg_match('/^[a-zA-Z0-9_\-]+$/',$db['database']) || $db['port']<1 || $db['port']>65535)) throw new InvalidArgumentException('Veritabanı adresi, portu veya adı geçersiz.');
        $action=text_input('action',20)?:'install';
        if (!in_array($action,['install','test','reconnect'],true)) throw new InvalidArgumentException('Geçersiz kurulum işlemi.');
        $stage='connection';
        // SQLite's read-only test must not create a database on disk.
        $pdo=$action==='test'&&$driver==='sqlite'?new PDO('sqlite::memory:'):Database::connect($db);
        $pdo->query('SELECT 1');
        Database::use($pdo);
        if ($action==='test') {
            $notice=$driver==='mysql'?'Veritabanı bağlantısı başarılı. Tablo veya yönetici hesabı oluşturulmadı. Şifreleri tekrar girerek kurulumu tamamlayabilirsiniz.':'SQLite sürücüsü hazır. Diskte veritabanı veya yönetici hesabı oluşturulmadı.';
        } else {
        $siteUrl=rtrim(url_input('site_url'),'/');
        if (!$siteUrl||parse_url($siteUrl,PHP_URL_QUERY)||parse_url($siteUrl,PHP_URL_FRAGMENT)) throw new InvalidArgumentException('Site adresini klasör yolu dahil, sorgu parametresi olmadan girin.');
        $stage='validation';
        $name=text_input('admin_name',150,$action!=='reconnect'); $email=text_input('admin_email',190,true);
        $password=password_input('admin_password',true);
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Geçerli yönetici e-postası girin.');
        if (strlen($password)<12 || strlen($password)>72) throw new InvalidArgumentException('Yönetici şifresi 12–72 bayt uzunluğunda olmalı.');
        $existing=installer_has_users($pdo,$driver);
        if ($existing && $action!=='reconnect') throw new InvalidArgumentException('Bu veritabanında daha önce kurulmuş Reflex Haber hesapları var. Verilerinizi silmeyin. Mevcut yönetici e-postası ve şifresiyle aşağıdaki Mevcut kurulumu bağla düğmesini kullanın.');
        if ($action==='reconnect') {
            if (!$existing) throw new InvalidArgumentException('Bu veritabanında yeniden bağlanacak bir Reflex Haber hesabı bulunamadı. Yeni kurulum düğmesini kullanın.');
            installer_verify_owner($pdo,$email,$password);
        }
        $stage='schema'; create_schema($pdo,$driver);
        $stage='configuration'; $temporary=installer_prepare_config(['site_url'=>$siteUrl,'db'=>$db]);
        $pdo->beginTransaction();
        try {
            $stage='content';
            if (!$existing) seed_site($name,$email,$password,isset($_POST['demo']));
            $stage='configuration';
            if (!@rename($temporary,ROOT.'/storage/site.php')) throw new RuntimeException('Configuration save failed');
            $temporary=null; $published=true;
            $stage='commit';
            $pdo->commit();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            if ($published) { @unlink(ROOT.'/storage/site.php'); $published=false; }
            throw $exception;
        }
        $done=true; session_regenerate_id(true);
        }
    } catch (Throwable $exception) {
        log_failure($exception);
        $diagnostic=installer_error($exception,$stage); $error=$diagnostic['message'];
        @file_put_contents(ROOT.'/storage/logs/app.log',date('c').' installer stage='.$stage.' mysql_code='.$diagnostic['code'].' sqlstate='.$diagnostic['sqlstate'].PHP_EOL,FILE_APPEND|LOCK_EX);
    } finally { if ($temporary) @unlink($temporary); if ($published&&!$done) @unlink(ROOT.'/storage/site.php'); if (is_resource($lock)) { flock($lock,LOCK_UN); fclose($lock); } }
}
$defaultUrl=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost').base_path();
?><!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reflex Haber Kurulum</title><style> *{box-sizing:border-box}body{margin:0;background:#eef1f5;font:16px/1.5 system-ui;color:#172638}main{max-width:760px;margin:40px auto;background:white;border-radius:16px;padding:32px}h1{margin:0;color:#ed1735}h2{font-size:20px}.checks{padding:16px;background:#f5f7fa;border-radius:10px}.ok{color:#13764b}.bad,.error{color:#b31229}.error{padding:14px;background:#fff0f2}.success{padding:14px;background:#eaf9f0;color:#13764b}.secondary{background:#172638}.help{margin-top:20px;padding:15px;background:#f5f7fa;border-radius:8px}code{font-size:14px}label{display:block;font-weight:600;margin:16px 0 6px}input,select{width:100%;padding:12px;border:1px solid #c8d0dc;border-radius:7px;font:inherit}input[type=checkbox]{width:auto}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}button,.button{display:inline-block;margin-top:24px;background:#ed1735;color:white;padding:13px 22px;border:0;border-radius:7px;font:inherit;text-decoration:none;cursor:pointer}small{color:#5c6878}a{color:#bd1730}@media(max-width:600px){main{margin:12px;padding:20px}.grid{grid-template-columns:1fr}}</style><main><h1>REFLEX HABER</h1><h2>Haber Pro · Kurulum ve bağlantı kontrolü</h2>
<?php if ($done): ?><p>Kurulum tamamlandı. Yönetim paneline belirlediğiniz e-posta ve şifreyle girebilirsiniz.</p><a class="button" href="<?=e(url('/panel/giris'))?>">Panele giriş</a> <a href="<?=e(url('/'))?>">Siteyi aç</a>
<?php else: ?><p>Dosyaları yeni bir klasöre yükleyin. MySQL veritabanını hosting panelinden oluşturup kullanıcıya yetki verin. Kurulum, <strong>rh6_</strong> tablolarını oluşturur.</p><div class="checks"><?php foreach($checks as $label=>$ok): ?><div class="<?=$ok?'ok':'bad'?>"><?=$ok?'✓':'✕'?> <?=e($label)?></div><?php endforeach ?></div><?php if($error):?><div class="error" role="alert"><p><?=e($error)?></p><?php if($diagnostic['code']):?><p><strong>Hata kodu: <?=e($diagnostic['code'])?></strong><?php if($diagnostic['sqlstate']):?> · SQLSTATE <?=e($diagnostic['sqlstate'])?><?php endif ?></p><?php endif ?></div><?php endif ?><?php if($notice):?><p class="success" role="status"><?=e($notice)?></p><?php endif ?>
<form method="post" autocomplete="off"><?=csrf_field()?><label>Site adresi (varsa alt klasör dahil)</label><input name="site_url" type="url" value="<?=e($_POST['site_url']??$defaultUrl)?>" required>
<label>Veritabanı türü</label><select name="driver" id="driver"><option value="mysql">MySQL / MariaDB (hosting)</option><?php if(extension_loaded('pdo_sqlite')):?><option value="sqlite" <?=($_POST['driver']??'')==='sqlite'?'selected':''?>>SQLite (yerel deneme)</option><?php endif ?></select>
<div id="mysql-fields"><div class="grid"><div><label>Veritabanı sunucusu</label><input name="db_host" value="<?=e($_POST['db_host']??'localhost')?>"></div><div><label>Port</label><input name="db_port" type="number" value="<?=e($_POST['db_port']??3306)?>"></div></div><div class="grid"><div><label>Veritabanı adı</label><input name="db_name" value="<?=e($_POST['db_name']??'')?>"></div><div><label>Veritabanı kullanıcı adı</label><input name="db_user" value="<?=e($_POST['db_user']??'')?>"></div></div><label>Veritabanı şifresi</label><input name="db_password" type="password" autocomplete="new-password"></div>
<div class="help"><strong>Hosting bilgilerini kontrol edin</strong><p>Veritabanı adı ve kullanıcı adı hesap ön eki dahil tam yazılmalıdır (örnek: <code>hesap_haber</code>). Veritabanı kullanıcısını ilgili veritabanına ekleyip tüm yetkileri verin. Bu alanın şifresi panel yönetici şifresinden ayrıdır.</p><button class="secondary" name="action" value="test" formnovalidate>Veritabanı bağlantısını test et</button></div><h2>Yönetici hesabı</h2><label>Adınız</label><input name="admin_name" required maxlength="150" value="<?=e($_POST['admin_name']??'')?>"><label>E-posta</label><input type="email" name="admin_email" required value="<?=e($_POST['admin_email']??'')?>"><label>Şifre</label><input type="password" name="admin_password" minlength="12" maxlength="72" required autocomplete="new-password"><small>En az 12 karakter. Bu şifreyi panel girişinde kullanacaksınız.</small><label><input type="checkbox" name="demo" <?=!is_post()||isset($_POST['demo'])?'checked':''?>> Tasarımı göstermek için örnek haberleri ve görselleri ekle</label><small>Örnek içerikler panelden tek işlemle kaldırılabilir.</small><br><button name="action" value="install" <?=in_array(false,$checks,true)?'disabled':''?>>Kurulumu tamamla</button><div class="help"><strong>Veritabanında daha önce kurulmuş Reflex Haber var mı?</strong><p>Yeni kurulum yerine, o sitenin mevcut yönetici e-postasını ve şifresini girerek bağlantı ayarlarını yeniden oluşturabilirsiniz. Mevcut haberler, hesaplar ve parolalar korunur.</p><button class="secondary" name="action" value="reconnect" formnovalidate>Mevcut kurulumu bağla</button></div></form><script>const d=document.getElementById('driver');function toggle(){document.getElementById('mysql-fields').hidden=d.value==='sqlite'}d.addEventListener('change',toggle);toggle();</script><?php endif ?></main></html>
