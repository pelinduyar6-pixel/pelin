<?php
declare(strict_types=1);
const PRO_VERSION='3.3.4';
require_once __DIR__.'/command.php';
require_once __DIR__.'/editorial.php';
require_once __DIR__.'/layout.php';
require_once __DIR__.'/automation.php';
require_once __DIR__.'/migration.php';
require_once __DIR__.'/social.php';
require_once __DIR__.'/migration-stream.php';
require_once __DIR__.'/migration-zip.php';
require_once __DIR__.'/migration-transfer.php';
require_once __DIR__.'/live-data.php';
function pro_defaults(): array {
    return ['theme_style'=>'1','home_show_top'=>'1','home_show_headline'=>'1','home_show_sidebar'=>'1','footer_phone'=>'','footer_address'=>'','theme_primary'=>'#e91c3a','theme_accent'=>'#06b6be','theme_width'=>'1100','theme_density'=>'comfortable','theme_logo'=>'','theme_logo_dark'=>'','theme_favicon'=>'','theme_header'=>'classic','slider_autoplay'=>'1','slider_interval'=>'3','breaking_animation'=>'1','theme_dark'=>'0','theme_footer_text'=>'Haberin merkezinde, hayatın yanında.','home_sections'=>json_encode(['latest'=>1,'categories'=>1,'video'=>1,'gallery'=>1,'authors'=>1]),'home_order'=>json_encode(['latest','categories','video','gallery','authors']),'code_head'=>'','code_body_start'=>'','code_body_end'=>'','code_footer'=>'','ai_model'=>'gpt-5.6-sol','seo_robots'=>'index,follow','seo_default_image'=>'','cron_token'=>bin2hex(random_bytes(24))];
}
function migrate_pro_schema(): void {
    if(Database::scalar("SELECT value FROM rh6_settings WHERE name='app_schema'")===PRO_VERSION)return;
    $pdo=Database::connection();$driver=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    $lock=fopen(ROOT.'/storage/schema.lock','c');if(!$lock||!flock($lock,LOCK_EX))throw new RuntimeException('Schema lock unavailable');
    try{
        $add=function(string $table,array $columns)use($driver):void{
            $existing=$driver==='sqlite'?array_column(Database::rows('PRAGMA table_info(rh6_'.$table.')'),'name'):array_column(Database::rows('SHOW COLUMNS FROM rh6_'.$table),'Field');
            foreach($columns as $name=>$definition)if(!in_array($name,$existing,true))Database::query('ALTER TABLE rh6_'.$table.' ADD COLUMN '.$name.' '.$definition);
        };
        $add('news',['focus_keyword'=>"VARCHAR(150) NOT NULL DEFAULT ''",'video_file'=>'VARCHAR(1000)','source_url'=>'VARCHAR(1000)','source_id'=>'INTEGER']);
        $add('ads',['code'=>'TEXT','device'=>"VARCHAR(20) NOT NULL DEFAULT 'all'",'priority'=>'INTEGER NOT NULL DEFAULT 0','starts_at'=>'VARCHAR(19)','ends_at'=>'VARCHAR(19)']);
        $id=$driver==='sqlite'?'INTEGER PRIMARY KEY AUTOINCREMENT':'INT UNSIGNED AUTO_INCREMENT PRIMARY KEY';
        $tail=$driver==='sqlite'?'':' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
        $tables=[
            'news_sources'=>"id $id,name VARCHAR(150) NOT NULL,feed_url VARCHAR(1000) NOT NULL,category_id INTEGER,author_id INTEGER,interval_minutes INTEGER NOT NULL DEFAULT 60,next_run_at VARCHAR(19),last_run_at VARCHAR(19),import_status VARCHAR(20) NOT NULL DEFAULT 'draft',max_items INTEGER NOT NULL DEFAULT 5,active INTEGER NOT NULL DEFAULT 1,last_message VARCHAR(500)",
            'feed_items'=>"id $id,source_id INTEGER NOT NULL,guid_hash VARCHAR(64) NOT NULL,news_id INTEGER NOT NULL,UNIQUE(source_id,guid_hash)",
            'source_runs'=>"id $id,source_id INTEGER NOT NULL,created_at VARCHAR(19) NOT NULL,imported INTEGER NOT NULL DEFAULT 0,status VARCHAR(20) NOT NULL,message VARCHAR(500)",
            'daily_stats'=>"id $id,day VARCHAR(10) NOT NULL,news_id INTEGER NOT NULL DEFAULT 0,views INTEGER NOT NULL DEFAULT 0,UNIQUE(day,news_id)",
            'media'=>"id $id,path VARCHAR(1000) NOT NULL,name VARCHAR(255) NOT NULL,kind VARCHAR(20) NOT NULL,created_at VARCHAR(19) NOT NULL",
            'reactions'=>"id $id,news_id INTEGER NOT NULL,visitor_hash VARCHAR(64) NOT NULL,kind VARCHAR(20) NOT NULL,created_at VARCHAR(19) NOT NULL,UNIQUE(news_id,visitor_hash)"
        ];
        foreach($tables as $table=>$cols)$pdo->exec('CREATE TABLE IF NOT EXISTS rh6_'.$table.' ('.$cols.')'.$tail);
        foreach(pro_defaults()+['google_news_url'=>''] as $name=>$value)if(!Database::scalar('SELECT id FROM rh6_settings WHERE name=?',[$name]))Database::save('settings',compact('name','value'));
        $indexes=['rh6_news'=>['rh6_news_published'=>['status','published_at','id'],'rh6_news_category'=>['category_id','status','published_at'],'rh6_news_kind'=>['kind','status','published_at']],'rh6_comments'=>['rh6_comments_article'=>['news_id','status']],'rh6_news_sources'=>['rh6_sources_due'=>['active','next_run_at']]];
        foreach($indexes as $table=>$definitions){$existing=$driver==='sqlite'?array_column(Database::rows('PRAGMA index_list('.$table.')'),'name'):array_column(Database::rows('SHOW INDEX FROM '.$table),'Key_name');foreach($definitions as $name=>$columns)if(!in_array($name,$existing,true))Database::query('CREATE INDEX '.$name.' ON '.$table.' ('.implode(',',$columns).')');}
        command_schema($pdo,$driver);
        editorial_schema($add);
        $add('news_sources',['schedule_mode'=>"VARCHAR(12) NOT NULL DEFAULT 'interval'",'daily_time'=>'VARCHAR(5)']);
        $add('news',['migration_key'=>'VARCHAR(64)']);
        $migrationIndexes=$driver==='sqlite'?array_column(Database::rows('PRAGMA index_list(rh6_news)'),'name'):array_column(Database::rows('SHOW INDEX FROM rh6_news'),'Key_name');
        if(!in_array('rh6_news_migration',$migrationIndexes,true))Database::query('CREATE UNIQUE INDEX rh6_news_migration ON rh6_news (migration_key)');
        layout_schema();
        live_schema($pdo,$driver);
        social_schema($pdo,$driver);
        if(!Database::scalar("SELECT id FROM rh6_settings WHERE name='code_bik'"))put_setting('code_bik','');
        put_setting('app_schema',PRO_VERSION);
    }finally{flock($lock,LOCK_UN);fclose($lock);}
}
function put_setting(string $name,string $value):void{
    $id=Database::scalar('SELECT id FROM rh6_settings WHERE name=?',[$name]);Database::save('settings',compact('name','value'),$id?(int)$id:null);unset($GLOBALS['reflex_settings_cache']);
}
function absolute_url(string $path):string{
    if(preg_match('~^https?://~i',$path))return $path;
    $site=parse_url((require ROOT.'/storage/site.php')['site_url']);return $site['scheme'].'://'.$site['host'].(isset($site['port'])?':'.$site['port']:'').$path;
}
function site_logo(bool $dark=false):void{
    $logo=setting($dark?'theme_logo_dark':'theme_logo')?:setting('theme_logo');
    if($logo)echo '<img class="site-logo-image" src="'.e(media($logo)).'" alt="'.e(setting('site_name')).'">';
    elseif(setting('site_name')==='REFLEX HABER')echo 'REFLEX<span>HABER</span>';
    else echo e(setting('site_name'));
}
function ad_slots():array{return ['masthead'=>'Logo üstü geniş bant','header'=>'Menü altı geniş bant','home_top'=>'Üst manşet öncesi','content'=>'Manşet altı / haber kutuları sonrası','sidebar'=>'Sağ sütun üst','sidebar_mid'=>'Sağ sütun orta','sidebar_bottom'=>'Sağ sütun alt','home_section_1'=>'Ana sayfa ilk bölüm sonrası','home_section_2'=>'Kategori bölümleri arası','home_section_3'=>'Ana sayfa son bölüm öncesi','video_top'=>'Video galerisi üstü','gallery_top'=>'Foto galeri üstü','listing_top'=>'Kategori ve arama üstü','article_top'=>'Haber başlığı üstü','article_after_image'=>'Haber görseli altı','article_inline'=>'Haber metni içi · üçüncü paragraf sonrası','article_sidebar_top'=>'Haber sağ sütunu · üst','article_sidebar_mid'=>'Haber sağ sütunu · orta','article_sidebar_bottom'=>'Haber sağ sütunu · alt','article_body_end'=>'Haber metni altı','article_bottom'=>'Haber / yorumlar sonrası','footer'=>'Footer üstü','desktop_left'=>'Masaüstü sol dış alan','desktop_right'=>'Masaüstü sağ dış alan','mobile_sticky'=>'Mobil sabit alt bant'];}
function home_section_names():array{return ['latest'=>'Son haberler / editörün seçtikleri','categories'=>'Kategori haber blokları','video'=>'Video galeri','gallery'=>'Foto galeri','authors'=>'Yazar vitrin alanı'];}
function seo_evaluate(array $news):array{
    $title=trim((string)($news['seo_title']??'')?:($news['title']??''));$description=trim((string)($news['seo_description']??'')?:($news['summary']??''));
    $body=editorial_plain_text((string)($news['body']??''));$words=preg_split('/\s+/u',trim($body),-1,PREG_SPLIT_NO_EMPTY)?:[];$keyword=trim((string)($news['focus_keyword']??''));
    $length=mb_strlen($title);$dl=mb_strlen($description);$hasKeyword=$keyword!==''&&mb_stripos($title,$keyword)!==false&&mb_stripos($body,$keyword)!==false;
    $checks=[['label'=>'SEO başlığı 30–65 karakter','ok'=>$length>=30&&$length<=65,'weight'=>20],['label'=>'Meta açıklama 100–165 karakter','ok'=>$dl>=100&&$dl<=165,'weight'=>20],['label'=>'Haber metni en az 150 kelime','ok'=>count($words)>=150,'weight'=>15],['label'=>'İçerikte ara başlık kullanılmış','ok'=>(bool)preg_match('/<h[234][ >]/i',(string)($news['body']??'')),'weight'=>10],['label'=>'Kapak görseli eklenmiş','ok'=>!empty($news['image'])||!empty($news['has_image']),'weight'=>10],['label'=>'Odak kelime başlıkta ve içerikte yer alıyor','ok'=>$hasKeyword,'weight'=>15],['label'=>'Bağlantı adı belirlenmiş','ok'=>!empty($news['slug']),'weight'=>5],['label'=>'Haber özeti eklenmiş','ok'=>mb_strlen((string)($news['summary']??''))>=50,'weight'=>5]];
    $score=array_sum(array_map(fn($check)=>$check['ok']?$check['weight']:0,$checks));return ['score'=>$score,'checks'=>$checks,'words'=>count($words),'grade'=>$score>=90?'Mükemmel':($score>=70?'İyi':($score>=50?'Geliştirilmeli':'Düşük'))];
}
function integration_config():array{return is_file(ROOT.'/storage/integrations.php')?(require ROOT.'/storage/integrations.php'):[];}
function pro_demo_media():void{
    $category=Database::scalar('SELECT id FROM rh6_categories ORDER BY id LIMIT 1');$author=Database::scalar('SELECT id FROM rh6_users WHERE public_profile=1 AND is_demo=1 ORDER BY id LIMIT 1');if(!$category||!$author)return;
    Database::query("UPDATE rh6_news SET video_file='reflex-video-demo.mp4' WHERE is_demo=1 AND kind='video' AND (video_file IS NULL OR video_file='')");
    $fixtures=[['Boğazın iki yakasından fotoğraflar','gallery','bogaz-5-2.jpg',['bogaz-5-2.jpg','hava-5-2-400x225.jpg','yol-5-2-400x225.jpg']],['Doğanın renkleri ve yaşam','gallery','tarla-5-2.jpg',['tarla-5-2.jpg','okyanus-5-2.jpg']],['Şehir hayatından anlar','gallery','yol-5-2-400x225.jpg',['yol-5-2-400x225.jpg','tbmm-5-2-400x225.jpg']],['Sporun heyecanı karelere yansıdı','gallery','tribun-5-2.jpg',['tribun-5-2.jpg','futbol-5-2-400x225.jpg']],['Bilim ve teknoloji video vitrini','video','nasa-5-2.jpg',[]],['Şehirden video notları','video','bogaz-5-2.jpg',[]],['Spor gündemi video vitrini','video','basket-5-2-400x225.jpg',[]]];
    foreach($fixtures as $i=>[$title,$kind,$image,$gallery]){
        $slug=slugify($title);if(Database::scalar('SELECT id FROM rh6_news WHERE slug=?',[$slug]))continue;$date=date('Y-m-d H:i:s',time()-21600-$i*600);
        Database::save('news',['title'=>$title,'slug'=>$slug,'summary'=>'Görsellerin ve video alanının görünümünü tanımak için hazırlanmış örnek içerik.','body'=>'<p>Bu sayfa tasarım gösterimi için hazırlanmış örnek içeriktir. Videolarda yerel olarak oluşturulmuş Reflex Haber tanıtım klibi kullanılır.</p><h2>Haberinizi siz oluşturun</h2><p>Yönetim panelinden kendi fotoğraflarınızı ve videolarınızı ekleyebilirsiniz.</p>','image'=>$image,'category_id'=>(int)$category,'author_id'=>(int)$author,'kind'=>$kind,'gallery'=>json_encode($gallery),'video_file'=>$kind==='video'?'reflex-video-demo.mp4':null,'status'=>'published','created_at'=>$date,'updated_at'=>$date,'published_at'=>$date,'is_demo'=>1,'allow_comments'=>1]);
    }
    pro_demo_editorial();
    editorial_demo_opinions();
}
function pro_demo_editorial():void{
    $authors=Database::rows('SELECT id FROM rh6_users WHERE public_profile=1 AND is_demo=1 ORDER BY id LIMIT 5');if(!$authors)return;
    $examples=[
      ['magazin','Sahne dünyasında yeni sezon hazırlıkları','entertainment-5-2-400x225.jpg'],
      ['magazin','Yaz etkinliklerinden renkli kareler','swimming-pool-1-5-2-400x225.jpg'],
      ['magazin','Yeni yapımlarla kültür gündemi hareketleniyor','modavid-5-2-400x225.jpg'],
      ['magazin','Kamera arkasında bir gün','file-5-2-400x225.jpg'],
      ['magazin','Sanatçılarla keyifli buluşmalar','evv-5-2-400x225.jpg'],
      ['magazin','Haftanın eğlence rehberi','paraunlu-5-2-400x225.jpg'],
      ['saglik','Kahve molası ve günlük yaşam alışkanlıkları','kahve-5-2.jpg'],
      ['saglik','Kalp sağlığı için bilinçli yaşam','kalpkrizi-5-2.jpg'],
      ['saglik','Mevsim geçişlerinde sağlıklı beslenme','cay-5-2-400x225.jpg'],
      ['saglik','Günlük hareketin yaşamımızdaki yeri','kosu-5-2-400x225.jpg'],
      ['spor','Avrupa futbolundan haftanın değerlendirmesi','champ2-5-2-400x225.jpg'],
      ['teknoloji','Mobil teknolojide kullanıcı deneyimi','apple-5-2-400x225.jpg'],
      ['teknoloji','Dijital platformlarda yeni alışkanlıklar','tww-5-2-400x225.jpg'],
      ['politika','Meclis çalışmalarına yakından bakış','tbmm-5-2-400x225.jpg'],
      ['politika','Ekonomi politikalarının günlük yaşama etkileri','dolar-1-5-2-400x225.jpg'],
      ['politika','Kentlerin geleceği ve yerel yönetimler','ev-5-2-400x225.jpg'],
      ['politika','Ulaşım ve şehir planlamasında yeni yaklaşımlar','bogaz-5-2.jpg']
    ];
    foreach($examples as $i=>[$categorySlug,$title,$image]){
        $category=Database::scalar('SELECT id FROM rh6_categories WHERE slug=?',[$categorySlug]);if(!$category)continue;$slug=slugify($title);if(Database::scalar('SELECT id FROM rh6_news WHERE slug=?',[$slug]))continue;$now=date('Y-m-d H:i:s',time()-3600-$i*60);
        Database::save('news',['title'=>$title,'slug'=>$slug,'summary'=>'Tasarım gösterimi için hazırlanmış örnek başlık ve içeriktir; gerçek haber yayını değildir.','body'=>'<p><strong>Örnek içerik.</strong> Bu yazı kategori vitrinlerini göstermek için hazırlanmıştır. Yayına geçerken kendi haberlerinizle değiştirin.</p>','image'=>$image,'category_id'=>(int)$category,'author_id'=>(int)$authors[$i%count($authors)]['id'],'kind'=>'article','gallery'=>'[]','status'=>'published','created_at'=>$now,'updated_at'=>$now,'published_at'=>$now,'is_demo'=>1,'allow_comments'=>1]);
    }
}
function save_integration_key(string $key):void{
    save_private_integrations(['openai_key'=>$key]);
}
function upload_video(string $field,?string $current=null):?string{
    $file=$_FILES[$field]??null;if(!$file||$file['error']===UPLOAD_ERR_NO_FILE)return $current;
    if($file['error']!==UPLOAD_ERR_OK||$file['size']>100*1024*1024)throw new InvalidArgumentException('Video yüklenemedi. MP4 veya WebM seçin; dosya en fazla 100 MB ve sunucu yükleme sınırı içinde olmalı.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);$extensions=['video/mp4'=>'mp4','video/webm'=>'webm'];
    if(!isset($extensions[$mime]))throw new InvalidArgumentException('Geçerli MP4 veya WebM video seçin.');
    $name=bin2hex(random_bytes(16)).'.'.$extensions[$mime];if(!move_uploaded_file($file['tmp_name'],ROOT.'/uploads/'.$name))throw new RuntimeException('Video save failed');Database::save('media',['path'=>'uploads/'.$name,'name'=>mb_substr(basename((string)$file['name']),0,255),'kind'=>'video','created_at'=>date('Y-m-d H:i:s')]);return 'uploads/'.$name;
}
function youtube_id(string $url):?string{
    $parts=parse_url($url);$host=strtolower($parts['host']??'');$id='';
    if(in_array($host,['youtu.be','www.youtu.be'],true))$id=trim($parts['path']??'','/');
    elseif(in_array($host,['youtube.com','www.youtube.com','m.youtube.com','youtube-nocookie.com','www.youtube-nocookie.com'],true)){parse_str($parts['query']??'',$query);$id=is_string($query['v']??null)?$query['v']:'';if(preg_match('~^/(?:embed|shorts|live)/([a-zA-Z0-9_-]{11})~',$parts['path']??'',$m))$id=$m[1];}
    return preg_match('/^[a-zA-Z0-9_-]{11}$/',$id)?$id:null;
}
function track_view(int $newsId=0):void{
    if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'||user())return;
    $day=date('Y-m-d');$count=Database::query('UPDATE rh6_daily_stats SET views=views+1 WHERE day=? AND news_id=?',[$day,$newsId])->rowCount();
    if(!$count){try{Database::save('daily_stats',['day'=>$day,'news_id'=>$newsId,'views'=>1]);}catch(PDOException $ex){if(!in_array((string)$ex->getCode(),['23000','23505'],true))throw $ex;Database::query('UPDATE rh6_daily_stats SET views=views+1 WHERE day=? AND news_id=?',[$day,$newsId]);}}
}
