/* Real browser folder selection and bounded multipart uploads, disposable localhost only. */
const {chromium}=require('playwright'),fs=require('fs'),path=require('path');
(async()=>{
 const base=process.argv[2];if(!/^http:\/\/(localhost|127\.0\.0\.1):/.test(base))throw Error('Local installation required');
 const fixture=fs.mkdtempSync('/tmp/reflex-folder-browser-'),folder=path.join(fixture,'uploads');
 const photo=fs.readFileSync(path.join(__dirname,'../assets/v6/demo/bogaz-5-2-400x225.jpg'));
 fs.mkdirSync(path.join(folder,'archive'),{recursive:true});for(let i=0;i<12;i++)fs.writeFileSync(path.join(folder,'archive','cover-'+i+'.jpg'),photo);fs.writeFileSync(path.join(folder,'readme.txt'),'Ignored');
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),page=await browser.newPage({viewport:{width:1440,height:1000}});
 const route=p=>base+'/index.php?'+new URLSearchParams({route:p}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 const check=(ok,label)=>{if(!ok)throw Error(label);console.log('PASS',label)};
 let job=null,batches=0;page.on('request',r=>{if(r.method()==='POST'&&decodeURIComponent(r.url()).includes('/tasima/klasor'))batches++});
 try{
  await page.goto(route('/panel/giris'));await page.locator('[name=email]').fill('test-admin@example.invalid');await page.locator('[name=password]').fill(process.env.DEMO6_TEST_PASSWORD);await page.getByRole('button',{name:'Giriş yap'}).click();await page.waitForURL(/route=%2Fpanel$/);
  await page.goto(route('/panel/tasima'));
  for(const width of [1440,768,390,320]){await page.setViewportSize({width,height:1000});check(await page.locator('[name=image_zip]').isVisible()&&await page.locator('[data-migration-directory]').isVisible()&&await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'SQL, ZIP and folder visible and fit '+width+'px');}
  await page.setViewportSize({width:1440,height:1000});await page.screenshot({path:'/workspace/outputs/reflex-edition/veri-tasima-yukleme.png'});
  const sql="CREATE TABLE old_news (`title` VARCHAR(255),`body` TEXT,`image` VARCHAR(255)); INSERT INTO old_news VALUES ('Legacy uploads-folder browser fixture','<p>Folder image preview.</p><img src=\"https://old.invalid/uploads/archive/cover-1.jpg\">','uploads/archive/cover-0.jpg');";
  await page.locator('[name=sql_file]').setInputFiles({name:'legacy.sql',mimeType:'text/plain',buffer:Buffer.from(sql)});
  await page.locator('[data-migration-directory]').setInputFiles(folder);check((await page.locator('.migration-directory-status').textContent()).includes('12 görsel'),'Folder selection retains nested paths and ignores non-image files');
  await page.getByRole('button',{name:/SQL ve seçilen görselleri yükle/}).click();await page.waitForURL(/job=/);job=new URL(page.url()).searchParams.get('job');
  check(batches===2,'Twelve folder files are uploaded in two bounded batches');check((await page.locator('.migration-summary').textContent()).includes('12 görsel'),'Uploaded images are saved to the SQL migration job');
  await page.getByRole('button',{name:'Eşleştirmeyi kaydet ve önizle'}).click();await page.locator('.migration-preview-grid img').waitFor();check(await page.locator('.migration-preview-grid img').evaluate(e=>e.complete&&e.naturalWidth>0),'Legacy uploads cover matches in the preview');
  // Simulate a later batch failure; the saved job remains available for retry.
  await page.locator('[data-migration-directory]').setInputFiles(folder);let intercepted=0;
  await page.route('**/*',async route=>{if(route.request().method()==='POST'&&decodeURIComponent(route.request().url()).includes('/tasima/klasor')&&++intercepted===2)return route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({ok:false,message:'Simulated interrupted upload'})});return route.continue()});
  await page.getByRole('button',{name:'Klasörü yükle ve eşleştir'}).click();await page.locator('.migration-directory-status a').waitFor();
  check((await page.locator('.migration-directory-status').textContent()).includes('Simulated interrupted upload')&&await page.getByRole('button',{name:'Klasörü yükle ve eşleştir'}).isEnabled(),'Interrupted upload retains the job and enables retry');
  await page.unrouteAll();await page.getByRole('button',{name:'Klasörü yükle ve eşleştir'}).click();await page.waitForURL(url=>url.searchParams.get('job')===job);await page.waitForLoadState('networkidle');
  check((await page.locator('.migration-summary').textContent()).includes('12 görsel'),'Retry does not duplicate stored image paths');check(!errors.length,'Folder controls have no browser script errors');
 }finally{
  if(job){await page.goto(route('/panel/tasima')+'&job='+job);await page.getByRole('button',{name:'Aktarım dosyalarını temizle'}).click();}
  await browser.close();fs.rmSync(fixture,{recursive:true,force:true});
 }
})().catch(e=>{console.error(e);process.exit(1)});
