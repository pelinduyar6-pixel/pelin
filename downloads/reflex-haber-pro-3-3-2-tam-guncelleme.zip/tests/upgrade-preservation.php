<?php
// Snapshot/compare an authentic Pro 3.0 installation on disposable localhost only.
$base=$argv[1];$mode=$argv[2];require $base.'/app/core.php';require $base.'/app/pro.php';$config=require $base.'/storage/site.php';
if(!in_array(parse_url($config['site_url'],PHP_URL_HOST),['localhost','127.0.0.1'],true))exit(1);
if(($config['db']['driver']??'mysql')==='mysql'&&$config['db']['host']!=='127.0.0.1')exit(1);
$pdo=Database::connection();$file=$base.'/storage/upgrade-snapshot.json';
if($mode==='before'){
 if(PRO_VERSION!=='3.0.0')throw new RuntimeException('Not an authentic Pro 3.0 runtime');
 put_setting('upgrade_preservation','old-value');put_setting('market_usd','49,11');
 $snapshot=[];foreach(['news','users','categories','news_sources','ads'] as $table)$snapshot[$table]=Database::rows('SELECT * FROM rh6_'.$table.' ORDER BY id');
 file_put_contents($file,json_encode($snapshot));echo 'Pro 3.0 snapshot recorded; '.count($snapshot['news']).' stories, '.count($snapshot['users']).' accounts.'.PHP_EOL;
}else{
 if(PRO_VERSION!=='3.3.2'||setting('app_schema')!=='3.3.2')throw new RuntimeException('Wrong upgraded runtime/schema');
 foreach(json_decode(file_get_contents($file),true) as $table=>$rows){$actual=Database::rows('SELECT * FROM rh6_'.$table.' ORDER BY id');if($table==='news_sources'){$oldIds=array_column($rows,'id');foreach($actual as $source)if(!in_array($source['id'],$oldIds)&&!in_array($source['feed_url'],array_column(editorial_source_presets(),'url'),true))throw new RuntimeException('Unexpected source added');}elseif(count($actual)!==count($rows))throw new RuntimeException('Row count changed: '.$table);$byId=array_column($actual,null,'id');foreach($rows as $i=>$row)foreach($row as $key=>$value){if($table==='categories'&&$key==='name'&&$value==='Gündem')$value='Türkiye Gündemi';if(($byId[$row['id']][$key]??null)!=$value)throw new RuntimeException('Old value changed: '.$table.' '.$key);}}
 if(setting('upgrade_preservation')!=='old-value'||setting('market_usd')!=='49,11')throw new RuntimeException('Existing setting changed');
 echo 'PASS Pro 3.0 old rows/accounts/passwords/category IDs/URLs and manual settings preserved; schema 3.3.2'.PHP_EOL;
}
